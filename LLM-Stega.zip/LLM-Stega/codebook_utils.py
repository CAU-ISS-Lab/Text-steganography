import json
import math
from bisect import bisect_right


def load_codebook(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def normalized_probabilities(words):
    if not words:
        raise ValueError("The keyword list is empty")
    values = [float(entry["probability"]) for entry in words]
    if any(not math.isfinite(value) or value < 0 for value in values):
        raise ValueError("Probabilities must be finite and nonnegative")
    total = math.fsum(values)
    if total <= 0:
        raise ValueError("At least one probability must be positive")
    return [value / total for value in values]


def build_expanded_intervals(words, expanded_size):
    probabilities = normalized_probabilities(words)
    positive = [index for index, value in enumerate(probabilities) if value > 0]
    if not isinstance(expanded_size, int) or expanded_size < len(positive):
        raise ValueError("expanded_size must provide a slot for each positive probability")
    slots = [
        max(math.floor(value * expanded_size), 1) if value > 0 else 0
        for value in probabilities
    ]
    deficit = expanded_size - sum(slots)
    if deficit > 0:
        for index in range(deficit):
            slots[positive[index % len(positive)]] += 1
    elif deficit < 0:
        excess = -deficit
        for index in reversed(positive):
            removed = min(slots[index] - 1, excess)
            slots[index] -= removed
            excess -= removed
            if excess == 0:
                break
    intervals = []
    cursor = 0
    for entry, count in zip(words, slots):
        if count:
            intervals.append(
                {"word": entry["word"], "start": cursor, "end": cursor + count, "slots": count}
            )
            cursor += count
    if cursor != expanded_size:
        raise ValueError("Expanded intervals do not cover expanded_size")
    return intervals


def lookup_word(intervals, idx):
    if not intervals or idx < 0 or idx >= intervals[-1]["end"]:
        raise ValueError("Keyword index is outside the expanded intervals")
    starts = [interval["start"] for interval in intervals]
    return intervals[bisect_right(starts, idx) - 1]["word"]


def sample_word_by_probability(words, rng):
    probabilities = normalized_probabilities(words)
    cumulative = []
    acc = 0.0
    for value in probabilities:
        acc += value
        cumulative.append(acc)
    cumulative[-1] = 1.0
    idx = min(bisect_right(cumulative, rng.random()), len(words) - 1)
    return words[idx]["word"]


class FileBitstream:
    def __init__(self, filepath):
        with open(filepath, "rb") as handle:
            raw = handle.read()
        self._bits = "".join(format(value, "08b") for value in raw)
        self._pos = 0
        self._total = len(self._bits)

    def read_bits(self, n):
        if n < 0 or self._pos + n > self._total:
            raise ValueError(f"Bitstream has {self.remaining} bits remaining; {n} requested")
        bits = self._bits[self._pos:self._pos + n]
        self._pos += n
        return bits

    def read_int(self, n):
        return int(self.read_bits(n), 2)

    @property
    def consumed(self):
        return self._pos

    @property
    def remaining(self):
        return self._total - self._pos
