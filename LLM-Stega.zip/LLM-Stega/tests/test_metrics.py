import importlib.util
import json
import math
from pathlib import Path
import tempfile
import unittest
import numpy as np

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
HERE = Path(__file__).resolve().parent
quality = load_module('llm_quality', HERE.parent / 'evaluate.py')

def write_lines(path, lines):
    Path(path).write_text(''.join((line + '\n' for line in lines)), encoding='utf-8')

class MetricMathTests(unittest.TestCase):

    def test_shifted_gaussian_kld_and_identity(self):
        cover = np.array([[0.0, 2.0], [2.0, 4.0]])
        stego = cover + [1.0, -2.0]
        self.assertAlmostEqual(quality.compute_kld_gaussian(cover, stego), 2.499999950000001, places=12)
        self.assertEqual(quality.compute_kld_gaussian(cover, cover), 0.0)

    def test_cosines_and_rejected_broadcasting(self):
        cover = [[1.0, 0.0], [0.0, 1.0], [0.0, 0.0]]
        stego = [[1.0, 0.0], [0.0, -1.0], [1.0, 0.0]]
        np.testing.assert_allclose(quality.compute_pairwise_cosine_similarity(cover, stego), [1.0, -1.0, 0.0])
        with self.assertRaises(ValueError):
            quality.compute_pairwise_cosine_similarity([[1.0, 0.0]], stego)

    def test_ppl_is_mean_of_sentence_ppls_without_loss_clipping(self):
        losses = np.log([2.0, 8.0])
        ppls = quality.perplexities_from_mean_losses(losses)
        self.assertAlmostEqual(np.mean(ppls), 5.0)
        self.assertNotAlmostEqual(np.mean(ppls), np.exp(np.mean(losses)))
        self.assertGreater(quality.perplexities_from_mean_losses([101])[0], np.exp(100))
        self.assertEqual(quality.PPL_MAX_LENGTH, 1024)
        with self.assertRaises(ValueError):
            quality.perplexities_from_mean_losses([0.0, float('nan')])
        with self.assertRaises(ValueError):
            quality.perplexities_from_mean_losses([1000.0])

    def test_overall_kld_uses_pooled_features_and_sample_weighting(self):
        cover_parts = [np.array([[0.0], [2.0]]), np.array([[10.0]])]
        stego_parts = [np.array([[1.0], [3.0]]), np.array([[10.0]])]
        data = {'cover_bert': cover_parts, 'stego_bert': stego_parts, 'cover_sbert': [np.ones((2, 2)), np.ones((1, 2))], 'stego_sbert': [np.ones((2, 2)), np.ones((1, 2))], 'cover_ppls': [[10.0, 20.0], [90.0]], 'stego_ppls': [[10.0, 20.0], [90.0]]}
        result = quality.summarize_features(data)
        self.assertAlmostEqual(result['kld'], 0.028728954902286663, places=12)
        self.assertNotAlmostEqual(result['kld'], 0.2499999950000001)
        self.assertEqual(result['stego_ppl_mean'], 40.0)
        self.assertEqual(result['n_stego'], 3)

    def test_finite_feature_validation(self):
        with self.assertRaises(ValueError):
            quality.compute_kld_gaussian([[float('nan')]], [[0.0]])

class AlignmentTests(unittest.TestCase):

    def test_blank_caption_is_not_dropped(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / 'cover.txt'
            write_lines(path, ['first caption', '', 'third caption'])
            with self.assertRaisesRegex(ValueError, 'Blank caption'):
                quality.load_lines(path)

    def test_count_mismatch_is_an_error(self):
        with tempfile.TemporaryDirectory() as root:
            write_lines(Path(root) / 'cover.txt', ['one cover', 'two cover'])
            write_lines(Path(root) / 'stego.txt', ['one stego'])
            with self.assertRaisesRegex(ValueError, 'Unaligned'):
                quality.load_paired_lines(root)

class OfflineIntegrationTests(unittest.TestCase):

    def test_scene_evaluation_with_fake_features(self):
        features = {'cover one': [1.0, 2.0], 'cover two': [3.0, 4.0], 'stego one': [2.0, 2.0], 'stego two': [4.0, 4.0]}

        class FakePPL:

            def score_sentences(self, sentences):
                return [10.0, 20.0]

        class FakeEncoder:

            def encode(self, sentences):
                return np.array([features[sentence] for sentence in sentences])
        with tempfile.TemporaryDirectory() as root:
            scene = Path(root) / 'method'
            scene.mkdir()
            write_lines(scene / 'cover.txt', ['cover one', 'cover two'])
            write_lines(scene / 'stego.txt', ['stego one', 'stego two'])
            result = quality.evaluate_scene('method', scene, FakePPL(), FakeEncoder(), FakeEncoder())
            self.assertEqual(result['stego_ppl_mean'], 15.0)
            self.assertAlmostEqual(result['kld'], 0.4999999900000002, places=12)
            self.assertAlmostEqual(result['ss_mean'], (3 / math.sqrt(10) + 7 / (5 * math.sqrt(2))) / 2)
            self.assertEqual(result['n_stego'], 2)
if __name__ == '__main__':
    unittest.main()
