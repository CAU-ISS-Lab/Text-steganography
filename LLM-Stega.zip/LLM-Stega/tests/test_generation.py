import json
import os
import random
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import api
import codebook_utils
import run


class GenerationTests(unittest.TestCase):
    def setUp(self):
        self.cb = codebook_utils.load_codebook(ROOT / "codebooks/office_desk.json")
        self.keywords = {
            "subjects": "laptop",
            "predicates": "rest on",
            "objects": "desk",
            "emotions": "positive",
        }
        self.cfg = {
            "generation_model": "generation",
            "extraction_model": "extraction",
            "max_retries": 3,
            "backoff": 0,
            "text_min_len": 8,
            "text_max_len": 20,
        }
        for name in ("embedding", "extraction", "feedback"):
            self.cfg[f"{name}_template"] = (ROOT / "prompts" / f"{name}.txt").read_text(encoding="utf-8")
        self.sentence = "The laptop rests neatly on the desk and looks pleasantly organized."

    def test_prompt_includes_tone_and_length(self):
        prompt = run.build_prompt(self.cfg, self.cb, self.keywords)
        self.assertIn("positive tone", prompt)
        self.assertIn("8 to 20 words", prompt)
        self.assertNotRegex(prompt, r"\{[A-Za-z_]+\}")

    def test_extracts_from_all_candidates_and_accepts_inflected_predicate(self):
        with patch.object(run, "call_chat", side_effect=[self.sentence, json.dumps(self.keywords)]) as chat:
            result = run.generate_one(self.cfg, self.cb, self.keywords)
        self.assertEqual(result["text"], self.sentence)
        self.assertEqual(result["attempts"], 1)
        prompt = chat.call_args_list[1].args[2]
        for entries in self.cb["subsets"].values():
            for entry in entries["words"]:
                self.assertIn(json.dumps(entry["word"]), prompt)
        self.assertIn("Sentence: " + self.sentence, prompt)

    def test_wrong_emotion_triggers_feedback_and_another_extraction(self):
        wrong = dict(self.keywords, emotions="negative")
        with patch.object(
            run, "call_chat",
            side_effect=[self.sentence, json.dumps(wrong), self.sentence, json.dumps(self.keywords)],
        ) as chat:
            result = run.generate_one(self.cfg, self.cb, self.keywords)
        self.assertEqual(result["text"], self.sentence)
        self.assertEqual(result["attempts"], 2)
        self.assertIn("emotions: expected positive, extracted negative", chat.call_args_list[2].args[2])
        self.assertEqual(chat.call_count, 4)

    def test_wrong_predicate_is_rejected(self):
        wrong = dict(self.keywords, predicates="sit on")
        with patch.object(run, "call_chat", side_effect=[self.sentence, json.dumps(wrong)] * 3):
            result = run.generate_one(self.cfg, self.cb, self.keywords)
        self.assertEqual(result["text"], "")
        self.assertIn("predicates: expected rest on, extracted sit on", result["error"])

    def test_invalid_length_is_not_counted_as_success(self):
        with patch.object(run, "call_chat", return_value="The laptop rests on the desk.") as chat:
            result = run.generate_one(self.cfg, self.cb, self.keywords)
        self.assertEqual(result["text"], "")
        self.assertEqual(result["attempts"], 3)
        self.assertEqual(chat.call_count, 3)
        self.assertIn("received 6", result["error"])

    def test_invalid_extraction_retries_without_accepting_text(self):
        with patch.object(run, "call_chat", side_effect=[self.sentence, "invalid JSON"] * 3):
            result = run.generate_one(self.cfg, self.cb, self.keywords)
        self.assertEqual(result["text"], "")
        self.assertIn("JSONDecodeError", result["error"])

    def test_api_failure_retries(self):
        with patch.object(run, "call_chat", side_effect=[RuntimeError("Connection failed"), self.sentence, json.dumps(self.keywords)]):
            result = run.generate_one(self.cfg, self.cb, self.keywords)
        self.assertEqual(result["text"], self.sentence)
        self.assertEqual(result["attempts"], 2)

    def test_automatic_message_expands_and_preserves_prefix(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as directory:
            cfg = {"n_stego": 1, "seed": 42, "output_dir": directory, "secret_path": None}
            small = run.prepare_bitstream(cfg, [self.cb])
            first = small.read_bits(64)
            cfg["n_stego"] = 5000
            full = run.prepare_bitstream(cfg, [self.cb])
            self.assertEqual(full.remaining, 5000 * 64)
            self.assertEqual(full.read_bits(64), first)

    def test_explicit_message_is_not_overwritten(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "tests") as directory:
            path = Path(directory) / "user.bin"
            path.write_bytes(b"secret")
            cfg = {"n_stego": 1, "output_dir": directory, "secret_path": str(path)}
            with self.assertRaisesRegex(ValueError, "64 are required"):
                run.prepare_bitstream(cfg, [self.cb])
            self.assertEqual(path.read_bytes(), b"secret")


class ProbabilityTests(unittest.TestCase):
    def test_two_sampling_paths_normalize_the_same_weights(self):
        words = [{"word": "a", "probability": 1}, {"word": "b", "probability": 3}]
        intervals = codebook_utils.build_expanded_intervals(words, 16)
        self.assertEqual([entry["slots"] for entry in intervals], [4, 12])
        self.assertEqual(codebook_utils.sample_word_by_probability(words, Mock(random=lambda: 0.2)), "a")
        self.assertEqual(codebook_utils.sample_word_by_probability(words, Mock(random=lambda: 0.5)), "b")

    def test_kitchen_tail_words_have_their_normalized_mass(self):
        cb = codebook_utils.load_codebook(ROOT / "codebooks/kitchen_counter.json")
        subset = cb["subsets"]["objects"]
        values = codebook_utils.normalized_probabilities(subset["words"])
        self.assertAlmostEqual(sum(entry["probability"] for entry in subset["words"]), 1.0)
        intervals = codebook_utils.build_expanded_intervals(subset["words"], subset["expanded_size"])
        for entry, value in zip(intervals, values):
            self.assertLess(abs(entry["slots"] / subset["expanded_size"] - value), 1 / subset["expanded_size"])
        self.assertGreater(intervals[-1]["slots"], 4000)
        self.assertGreater(intervals[-2]["slots"], 4000)
        self.assertEqual(codebook_utils.sample_word_by_probability(subset["words"], Mock(random=lambda: 0.99)), "tile")
        self.assertEqual(codebook_utils.sample_word_by_probability(subset["words"], Mock(random=lambda: 0.97)), "rack")

    def test_codebook_intervals_cover_every_index(self):
        for path in (ROOT / "codebooks").glob("*.json"):
            cb = codebook_utils.load_codebook(path)
            for key, intervals in run.build_all_intervals(cb).items():
                self.assertEqual(intervals[0]["start"], 0)
                self.assertEqual(intervals[-1]["end"], cb["subsets"][key]["expanded_size"])
                for entry in intervals:
                    self.assertEqual(codebook_utils.lookup_word(intervals, entry["start"]), entry["word"])
                    self.assertEqual(codebook_utils.lookup_word(intervals, entry["end"] - 1), entry["word"])


class APITests(unittest.TestCase):
    def test_local_api_configuration_and_list_content(self):
        cfg = {
            "models": {"generation": {"provider": "local", "name": "test-model", "temperature": 1.0}},
            "providers": {"local": {"url": "https://example.invalid/chat", "api_key_env": "LLM_TEST_API_KEY", "url_env": "LLM_TEST_API_URL"}},
        }
        response = Mock()
        response.json.return_value = {"choices": [{"message": {"content": [{"type": "text", "text": "A test sentence."}]}}]}
        with patch.dict(os.environ, {"LLM_TEST_API_KEY": "test-key", "LLM_TEST_API_URL": "https://override.invalid/chat"}):
            with patch.object(api.requests, "post", return_value=response) as post:
                result = api.call_chat(cfg, "generation", "Write a sentence.")
        self.assertEqual(result, "A test sentence.")
        self.assertEqual(post.call_args.args[0], "https://override.invalid/chat")
        self.assertEqual(post.call_args.kwargs["json"]["model"], "test-model")
        self.assertEqual(post.call_args.kwargs["headers"]["Authorization"], "Bearer test-key")


if __name__ == "__main__":
    unittest.main()
