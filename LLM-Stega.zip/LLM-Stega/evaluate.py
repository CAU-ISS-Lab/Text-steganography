import argparse
import json
from pathlib import Path
import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = SCRIPT_DIR / "outputs"
BITS_PER_SENTENCE = 64
SBERT_MODEL = "sentence-transformers/roberta-base-nli-mean-tokens"
BERT_MODEL = "bert-base-uncased"
PPL_MODEL = "gpt2"
PPL_MAX_LENGTH = 1024
KLD_EPS = 1e-8
COSINE_EPS = 1e-12


def get_scene_dirs(output_dir):
    root = Path(output_dir)
    if not root.is_dir():
        raise FileNotFoundError(f"Output directory not found: {root}")
    scenes = []
    for scene in sorted(root.iterdir()):
        if not scene.is_dir() or scene.name.startswith("."):
            continue
        cover, stego = scene / "cover.txt", scene / "stego.txt"
        if cover.exists() or stego.exists():
            if not cover.is_file() or not stego.is_file():
                raise ValueError(f"Incomplete cover/stego pair in {scene}")
            scenes.append((scene.name, scene))
    return scenes


def load_lines(txt_path):

    with open(txt_path, encoding="utf-8") as stream:
        lines = [line.strip() for line in stream]
    if not lines:
        raise ValueError(f"Empty caption file: {txt_path}")
    for row, line in enumerate(lines, 1):
        if not line:
            raise ValueError(f"Blank caption at {txt_path}:{row}")
    return lines


def load_paired_lines(scene_path):
    scene_path = Path(scene_path)
    cover = load_lines(scene_path / "cover.txt")
    stego = load_lines(scene_path / "stego.txt")
    if len(cover) != len(stego):
        raise ValueError(f"Unaligned caption files in {scene_path}: cover={len(cover)}, stego={len(stego)}")
    return cover, stego


def _device_or_default(device):
    import torch
    return device or ("cuda" if torch.cuda.is_available() else "cpu")


def perplexities_from_mean_losses(losses):

    values = np.asarray(losses, dtype=np.float64)
    if values.ndim != 1 or not len(values) or not np.isfinite(values).all():
        raise ValueError("PPL requires finite mean losses for every sentence")
    with np.errstate(over="ignore"):
        ppls = np.exp(values)
    if not np.isfinite(ppls).all():
        raise ValueError("Non-finite PPL")
    return ppls.tolist()


class PPLScorer:
    def __init__(self, model_name=PPL_MODEL, device=None):
        import torch
        from transformers import GPT2LMHeadModel, GPT2TokenizerFast
        self.device = torch.device(_device_or_default(device))
        self.tokenizer = GPT2TokenizerFast.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "right"
        self.model = GPT2LMHeadModel.from_pretrained(model_name).to(self.device)
        self.model.config.pad_token_id = self.tokenizer.eos_token_id
        self.model.eval()

    def score_sentences(self, sentences, batch_size=16):
        import torch
        losses = []
        with torch.no_grad():
            for start in range(0, len(sentences), batch_size):
                enc = self.tokenizer(
                    sentences[start:start + batch_size], return_tensors="pt",
                    padding=True, truncation=True, max_length=PPL_MAX_LENGTH,
                ).to(self.device)
                logits = self.model(**enc).logits[:, :-1, :].contiguous()
                labels = enc["input_ids"][:, 1:].contiguous()
                mask = enc["attention_mask"][:, 1:].float()
                counts = mask.sum(dim=1)
                if (counts == 0).any():
                    raise ValueError("PPL is undefined for captions with fewer than two GPT-2 tokens")
                token_losses = torch.nn.functional.cross_entropy(
                    logits.view(-1, logits.size(-1)), labels.view(-1), reduction="none",
                ).view(labels.size())
                losses.extend(((token_losses * mask).sum(dim=1) / counts).cpu().tolist())
        return perplexities_from_mean_losses(losses)


class BertEncoder:

    def __init__(self, model_name=BERT_MODEL, device=None):
        import torch
        from transformers import BertModel, BertTokenizerFast
        self.device = torch.device(_device_or_default(device))
        self.tokenizer = BertTokenizerFast.from_pretrained(model_name)
        self.model = BertModel.from_pretrained(model_name).to(self.device)
        self.model.eval()

    def encode(self, sentences, batch_size=64):
        import torch
        embeddings = []
        with torch.no_grad():
            for start in range(0, len(sentences), batch_size):
                enc = self.tokenizer(
                    sentences[start:start + batch_size], return_tensors="pt",
                    padding=True, truncation=True, max_length=512,
                ).to(self.device)
                embeddings.append(self.model(**enc).last_hidden_state[:, 0, :].cpu().numpy())
        return np.concatenate(embeddings, axis=0)


class SBertEncoder:
    def __init__(self, model_name=SBERT_MODEL, device=None):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name, device=_device_or_default(device))

    def encode(self, sentences, batch_size=64):
        return self.model.encode(
            sentences, batch_size=batch_size, show_progress_bar=False, convert_to_numpy=True,
        )


def _feature_pair(cover, stego, paired=False):
    cover, stego = np.asarray(cover, dtype=np.float64), np.asarray(stego, dtype=np.float64)
    if cover.ndim != 2 or stego.ndim != 2 or not len(cover) or not len(stego):
        raise ValueError("Expected nonempty two-dimensional feature arrays")
    if cover.shape[1] != stego.shape[1] or (paired and cover.shape != stego.shape):
        raise ValueError(f"Feature shape mismatch: {cover.shape} vs {stego.shape}")
    if not np.isfinite(cover).all() or not np.isfinite(stego).all():
        raise ValueError("Features must be finite")
    return cover, stego


def compute_kld_gaussian(cover_embeds, stego_embeds):
    cover, stego = _feature_pair(cover_embeds, stego_embeds)
    mu_x, mu_y = cover.mean(axis=0), stego.mean(axis=0)
    sigma_x, sigma_y = cover.std(axis=0) + KLD_EPS, stego.std(axis=0) + KLD_EPS
    return float(np.sum(np.log(sigma_y / sigma_x) + (
        sigma_x ** 2 + (mu_x - mu_y) ** 2
    ) / (2.0 * sigma_y ** 2) - 0.5))


def compute_pairwise_cosine_similarity(a, b, eps=COSINE_EPS):
    a, b = _feature_pair(a, b, paired=True)
    a = a / np.maximum(np.linalg.norm(a, axis=1, keepdims=True), eps)
    b = b / np.maximum(np.linalg.norm(b, axis=1, keepdims=True), eps)
    return np.sum(a * b, axis=1)


def compute_ec(stego_lines):
    n = len(stego_lines)
    words = sum(len(line.split()) for line in stego_lines)
    if not n or not words:
        raise ValueError("EC requires nonempty text")
    return {
        "bits_per_sentence": BITS_PER_SENTENCE,
        "avg_length": words / n,
        "ec_bpw": BITS_PER_SENTENCE * n / words,
    }


def summarize_features(data):

    cover_bert = np.concatenate(data["cover_bert"], axis=0)
    stego_bert = np.concatenate(data["stego_bert"], axis=0)
    cover_sbert = np.concatenate(data["cover_sbert"], axis=0)
    stego_sbert = np.concatenate(data["stego_sbert"], axis=0)
    cover_ppls = np.concatenate(data["cover_ppls"])
    stego_ppls = np.concatenate(data["stego_ppls"])
    n = len(stego_ppls)
    if any(len(values) != n for values in [cover_ppls, cover_bert, stego_bert, cover_sbert, stego_sbert]):
        raise ValueError("Metric outputs do not preserve the input row count")
    if not np.isfinite(cover_ppls).all() or not np.isfinite(stego_ppls).all():
        raise ValueError("Every input caption must have a finite PPL")
    similarities = compute_pairwise_cosine_similarity(cover_sbert, stego_sbert)
    return {
        "n_cover": n, "n_stego": n,
        "cover_ppl_mean": float(np.mean(cover_ppls)),
        "cover_ppl_std": float(np.std(cover_ppls)),
        "stego_ppl_mean": float(np.mean(stego_ppls)),
        "stego_ppl_std": float(np.std(stego_ppls)),
        "kld": compute_kld_gaussian(cover_bert, stego_bert),
        "ss_mean": float(np.mean(similarities)), "ss_std": float(np.std(similarities)),
    }


def evaluate_scene(scene_name, scene_path, ppl_scorer, bert_encoder, sbert_encoder, collector=None):
    cover, stego = load_paired_lines(scene_path)
    data = {
        "cover_ppls": [ppl_scorer.score_sentences(cover)],
        "stego_ppls": [ppl_scorer.score_sentences(stego)],
        "cover_bert": [bert_encoder.encode(cover)], "stego_bert": [bert_encoder.encode(stego)],
        "cover_sbert": [sbert_encoder.encode(cover)], "stego_sbert": [sbert_encoder.encode(stego)],
    }
    result = {"scene": scene_name, **summarize_features(data), **compute_ec(stego)}
    if result["n_stego"] != len(stego):
        raise ValueError(f"Missing metric outputs for {scene_name}")
    if collector is not None:
        for key, values in data.items():
            collector.setdefault(key, []).extend(values)
    return result


def main():
    parser = argparse.ArgumentParser(description="LLM-Stega PPL / KLD / SS / EC evaluation")
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()
    scenes = get_scene_dirs(args.output_dir)
    if not scenes:
        parser.error("No complete scene caption files found")
    all_stego = []
    for _, scene in scenes:
        _, stego = load_paired_lines(scene)
        all_stego.extend(stego)
    ppl = PPLScorer(device=args.device)
    bert = BertEncoder(device=args.device)
    sbert = SBertEncoder(device=args.device)
    collector, results = {}, []
    for name, scene in scenes:
        result = evaluate_scene(name, scene, ppl, bert, sbert, collector)
        results.append(result)
        print(json.dumps(result, ensure_ascii=False))
    overall = {**summarize_features(collector), **compute_ec(all_stego)}
    report = {
        "method": "LLM-Stega",
        "settings": {
            "ppl_model": PPL_MODEL, "ppl_max_length": PPL_MAX_LENGTH,
            "ppl_aggregation": "mean_sentence_perplexity",
            "kld_model": BERT_MODEL, "kld_representation": "raw_cls",
            "kld_normalization": "none", "kld_epsilon": KLD_EPS,
            "kld_direction": "cover_to_stego", "kld_aggregation": "pooled_corpus",
            "ss_model": SBERT_MODEL, "ss_aggregation": "mean_paired_cosine",
        },
        "per_scene": results, "overall": overall,
    }
    path = args.output_dir / "eval_results.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    print(f"Overall: {json.dumps(overall)}")
    print(f"Report: {path}")


if __name__ == "__main__":
    main()
