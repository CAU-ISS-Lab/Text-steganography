import argparse
import concurrent.futures
import json
import random
import re
import time
from pathlib import Path

import yaml
from tqdm import tqdm

from api import call_chat, validate_api_config
from codebook_utils import (
    FileBitstream,
    build_expanded_intervals,
    load_codebook,
    lookup_word,
    sample_word_by_probability,
)


SCRIPT_DIR = Path(__file__).resolve().parent
SUBSETS = ("subjects", "predicates", "objects", "emotions")


def load_cfg(config_path=None):
    config_path = Path(config_path or SCRIPT_DIR / "config.yaml").resolve()
    with config_path.open(encoding="utf-8") as handle:
        cfg = yaml.safe_load(handle)
    for key, default in (
        ("codebook_dir", "codebooks"),
        ("output_dir", "outputs"),
    ):
        path = Path(cfg.get(key, default))
        cfg[key] = str(path if path.is_absolute() else config_path.parent / path)
    if cfg.get("secret_path"):
        path = Path(cfg["secret_path"])
        cfg["secret_path"] = str(path if path.is_absolute() else config_path.parent / path)
    else:
        cfg["secret_path"] = None
    for key, default in (
        ("embedding", "prompts/embedding.txt"),
        ("extraction", "prompts/extraction.txt"),
        ("feedback", "prompts/feedback.txt"),
    ):
        path = Path(cfg.get("prompts", {}).get(key, default))
        if not path.is_absolute():
            path = config_path.parent / path
        cfg[f"{key}_template"] = path.read_text(encoding="utf-8")
    return cfg


def build_all_intervals(cb):
    intervals = {}
    for key in SUBSETS:
        subset = cb["subsets"][key]
        if subset["expanded_size"] != 2 ** subset["bits"]:
            raise ValueError(f"{key}: expanded_size must equal 2 ** bits")
        intervals[key] = build_expanded_intervals(
            subset["words"], subset["expanded_size"]
        )
    return intervals


def select_keywords_from_bitstream(cb, intervals, bs):
    return {
        key: lookup_word(intervals[key], bs.read_int(cb["subsets"][key]["bits"]))
        for key in SUBSETS
    }


def select_keywords_by_probability(cb, rng):
    return {
        key: sample_word_by_probability(cb["subsets"][key]["words"], rng)
        for key in SUBSETS
    }


def fill_template(template, values):
    for key, value in values.items():
        template = template.replace("{" + key + "}", str(value))
    return template


def build_prompt(cfg, cb, keywords):
    return fill_template(
        cfg["embedding_template"],
        {
            "scene_description": cb.get("scene_description", ""),
            "subject": keywords["subjects"],
            "predicate": keywords["predicates"],
            "object": keywords["objects"],
            "emotions": keywords["emotions"],
            "min_len": cfg["text_min_len"],
            "max_len": cfg["text_max_len"],
        },
    )


def extract_keywords(cfg, cb, sentence):
    values = {
        key: json.dumps([entry["word"] for entry in cb["subsets"][key]["words"]])
        for key in SUBSETS
    }
    values["sentence"] = sentence
    prompt = fill_template(cfg["extraction_template"], values)
    raw = call_chat(cfg, cfg["extraction_model"], prompt).strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
        raw = re.sub(r"\s*```$", "", raw)
    extracted = json.loads(raw)
    if not isinstance(extracted, dict):
        raise ValueError("Extraction must return a JSON object")
    result = {}
    for key in SUBSETS:
        value = extracted.get(key)
        if not isinstance(value, str):
            raise ValueError(f"Extraction is missing {key}")
        candidates = {
            entry["word"].casefold(): entry["word"]
            for entry in cb["subsets"][key]["words"]
        }
        normalized = value.strip().casefold()
        if normalized not in candidates:
            raise ValueError(f"Extraction returned an unknown {key}: {value}")
        result[key] = candidates[normalized]
    return result


def check_sentence(cfg, sentence, keywords):
    length = len(sentence.split())
    errors = []
    if not cfg["text_min_len"] <= length <= cfg["text_max_len"]:
        errors.append(
            f"Use {cfg['text_min_len']} to {cfg['text_max_len']} words; received {length}"
        )
    if re.search(r"\{[A-Za-z_]+\}", sentence):
        errors.append("Replace all template placeholders with sentence text")
    subject = re.search(
        r"(?<!\w)" + re.escape(keywords["subjects"]) + r"(?!\w)",
        sentence,
        re.IGNORECASE,
    )
    if subject is None:
        errors.append(f"Include the subject phrase: {keywords['subjects']}")
    object_start = subject.end() if subject else 0
    obj = re.search(
        r"(?<!\w)" + re.escape(keywords["objects"]) + r"(?!\w)",
        sentence[object_start:],
        re.IGNORECASE,
    )
    if obj is None:
        errors.append(f"Include the object phrase after the subject: {keywords['objects']}")
    return errors


def generate_one(cfg, cb, keywords):
    base_prompt = build_prompt(cfg, cb, keywords)
    prompt = base_prompt
    error = ""
    retries = cfg.get("max_retries", 3)
    for attempt in range(1, retries + 1):
        sentence = ""
        try:
            raw = call_chat(cfg, cfg["generation_model"], prompt)
            sentence = " ".join(raw.strip().strip('\"').strip("'").split())
            errors = check_sentence(cfg, sentence, keywords)
            if not errors:
                extracted = extract_keywords(cfg, cb, sentence)
                for key in SUBSETS:
                    if extracted[key].casefold() != keywords[key].casefold():
                        errors.append(
                            f"{key}: expected {keywords[key]}, extracted {extracted[key]}"
                        )
            if not errors:
                return {"text": sentence, "attempts": attempt, "error": ""}
            error = "; ".join(errors)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        if sentence:
            prompt = fill_template(
                cfg["feedback_template"],
                {"instructions": base_prompt, "sentence": sentence, "feedback": error},
            )
        if attempt < retries:
            time.sleep(cfg.get("backoff", 2.0) * attempt)
    return {"text": "", "attempts": retries, "error": error}


def batch_generate(cfg, cb, keyword_rows, desc):
    provider = cfg["models"][cfg["generation_model"]]["provider"]
    workers = cfg["providers"][provider].get("max_concurrent", 10)
    results = [None] * len(keyword_rows)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(generate_one, cfg, cb, keywords): index
            for index, keywords in enumerate(keyword_rows)
        }
        for future in tqdm(
            concurrent.futures.as_completed(futures),
            total=len(futures),
            desc=desc,
            leave=False,
        ):
            results[futures[future]] = future.result()
    return results


def process_codebook(cfg, cb_path, bs, global_rng):
    cb = load_codebook(cb_path)
    scene = cb["scene_name"]
    intervals = build_all_intervals(cb)
    scene_dir = Path(cfg["output_dir"]) / scene
    scene_dir.mkdir(parents=True, exist_ok=True)
    keywords = {
        "stego": [
            select_keywords_from_bitstream(cb, intervals, bs)
            for _ in range(cfg["n_stego"])
        ],
        "cover": [
            select_keywords_by_probability(cb, global_rng)
            for _ in range(cfg["n_cover"])
        ],
    }
    summary = {"scene": scene}
    status = {}
    for kind in ("stego", "cover"):
        results = batch_generate(cfg, cb, keywords[kind], f"{scene} {kind}")
        text_path = scene_dir / f"{kind}.txt"
        text_path.write_text(
            "".join(row["text"] + "\n" for row in results), encoding="utf-8"
        )
        keywords_path = scene_dir / f"{kind}_keywords.json"
        keywords_path.write_text(
            json.dumps(keywords[kind], indent=2, ensure_ascii=False), encoding="utf-8"
        )
        status[kind] = [
            {
                "valid": bool(row["text"]),
                "attempts": row["attempts"],
                "error": row["error"],
            }
            for row in results
        ]
        summary[f"{kind}_path"] = str(text_path)
        summary[f"{kind}_keywords_path"] = str(keywords_path)
        summary[f"{kind}_valid"] = sum(bool(row["text"]) for row in results)
        summary[f"{kind}_failed"] = len(results) - summary[f"{kind}_valid"]
    status_path = scene_dir / "generation_status.json"
    status_path.write_text(json.dumps(status, indent=2, ensure_ascii=False), encoding="utf-8")
    summary["status_path"] = str(status_path)
    print(
        f"{scene}: stego {summary['stego_valid']}/{cfg['n_stego']}, "
        f"cover {summary['cover_valid']}/{cfg['n_cover']}"
    )
    return summary


def prepare_bitstream(cfg, codebooks):
    needed = sum(
        cfg["n_stego"] * sum(cb["subsets"][key]["bits"] for key in SUBSETS)
        for cb in codebooks
    )
    automatic = not cfg.get("secret_path")
    path = Path(cfg["output_dir"]) / "secret_message.bin" if automatic else Path(cfg["secret_path"])
    size = (needed + 7) // 8
    if not path.exists() or (automatic and path.stat().st_size < size):
        path.parent.mkdir(parents=True, exist_ok=True)
        if not automatic:
            raise FileNotFoundError(f"Secret message file not found: {path}")
        rng = random.Random(cfg.get("seed", 42))
        path.write_bytes(bytes(rng.getrandbits(8) for _ in range(size)))
    bs = FileBitstream(path)
    if bs.remaining < needed:
        raise ValueError(f"{path} contains {bs.remaining} bits; {needed} are required")
    return bs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(SCRIPT_DIR / "config.yaml"))
    parser.add_argument("--n-stego", type=int)
    parser.add_argument("--n-cover", type=int)
    parser.add_argument("--output-dir")
    parser.add_argument("--secret-path")
    args = parser.parse_args()
    cfg = load_cfg(args.config)
    for key in ("n_stego", "n_cover", "output_dir", "secret_path"):
        value = getattr(args, key)
        if value is not None:
            cfg[key] = str(Path(value).resolve()) if key.endswith(("dir", "path")) else value
    for key in ("n_stego", "n_cover", "max_retries"):
        if cfg[key] < 1:
            raise ValueError(f"{key} must be positive")
    if not 0 < cfg["text_min_len"] <= cfg["text_max_len"]:
        raise ValueError("text_min_len and text_max_len must define a positive range")
    cb_files = sorted(Path(cfg["codebook_dir"]).glob("*.json"))
    if not cb_files:
        raise ValueError(f"No codebooks found in {cfg['codebook_dir']}")
    codebooks = [load_codebook(path) for path in cb_files]
    for cb in codebooks:
        build_all_intervals(cb)
    validate_api_config(cfg)
    bs = prepare_bitstream(cfg, codebooks)
    global_rng = random.Random(cfg.get("seed", 42))
    output_dir = Path(cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Generating {len(cb_files) * cfg['n_stego']} stego and {len(cb_files) * cfg['n_cover']} cover texts")
    results = [process_codebook(cfg, path, bs, global_rng) for path in cb_files]
    (output_dir / "summary.json").write_text(
        json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    failures = [
        f"{row['scene']}: {row['stego_failed']} stego, {row['cover_failed']} cover"
        for row in results
        if row["stego_failed"] or row["cover_failed"]
    ]
    if failures:
        raise SystemExit("Generation failed for " + "; ".join(failures))
    print(f"Output: {output_dir}")


if __name__ == "__main__":
    main()
