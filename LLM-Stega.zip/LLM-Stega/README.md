# 🔐 LLM-Stega

A reproduction of LLM-Stega, a black-box text steganography method that maps message bits to keywords and uses an LLM to turn them into sentences.

**Paper:** [Generative Text Steganography with Large Language Model](https://arxiv.org/abs/2404.10229)  
**Authors:** Jiaxuan Wu, Zhengxian Wu, Yiming Xue, Juan Wen, and Wanli Peng

## How text is generated

Each codebook contains subjects, predicates, objects, and emotions. Stego generation selects keywords from a binary message stream; cover generation samples keywords from the codebook probabilities. Both use the same sentence prompt. Generated sentences are checked for length, and an extraction call checks the selected keywords. Failed checks trigger another generation attempt with feedback.

The included codebooks cover an office desk, a kitchen counter, and a bathroom vanity.

| Purpose | Default model |
|---|---|
| Sentence generation and keyword extraction | `gpt-5.1-chat-latest` |
| Perplexity (PPL) | `gpt2` |
| Distribution divergence (KLD) | `bert-base-uncased` |
| Semantic similarity (SS) | `sentence-transformers/roberta-base-nli-mean-tokens` |

## ⚙️ Installation

Use Python 3.10 or later. Run these commands from the repository folder:

```bash
pip install -r requirements.txt
```

Set your API key:

```bash
export OPENAI_API_KEY="your-api-key"
```

In PowerShell:

```powershell
$env:OPENAI_API_KEY = "your-api-key"
```

Model names, the API endpoint, sampling parameters, and concurrency are configured in `config.yaml`.

## 🚀 Quick start

Generate 10 stego and 10 cover sentences per codebook, then evaluate them:

```bash
python run.py --n-stego 10 --n-cover 10 --output-dir outputs/demo
python evaluate.py --output-dir outputs/demo
```

For the default dataset of 15,000 stego and 15,000 cover sentences:

```bash
python run.py
python evaluate.py
```

`n_stego` and `n_cover` set the count per codebook, both defaulting to 5,000. Edit `config.yaml` to adjust these counts, sentence lengths, models, and retry settings. Edit `codebooks/` and `prompts/` to change the topics and generation prompts.

The runner creates and extends `secret_message.bin` in the output directory. Use `--secret-path` to select your own binary file.

## 📁 Results

Each scene is saved under the selected output directory with `stego.txt`, `cover.txt`, and the corresponding keyword records. The evaluation report is saved as `eval_results.json`, with PPL, KLD, SS, and embedding capacity (EC) for each scene and the complete dataset.
