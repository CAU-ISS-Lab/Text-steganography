import os

import requests


def validate_api_config(cfg):
    for key in (cfg["generation_model"], cfg["extraction_model"]):
        provider = cfg["providers"][cfg["models"][key]["provider"]]
        env_name = provider["api_key_env"]
        if not os.environ.get(env_name):
            raise ValueError(f"Set the {env_name} environment variable")
        if provider.get("max_concurrent", 10) < 1:
            raise ValueError("max_concurrent must be positive")


def call_chat(cfg, model_key, prompt):
    model = cfg["models"][model_key]
    provider = cfg["providers"][model["provider"]]
    api_key = os.environ.get(provider["api_key_env"])
    if not api_key:
        raise ValueError(f"Set the {provider['api_key_env']} environment variable")
    url = os.environ.get(provider.get("url_env", "")) or provider["url"]
    body = {"model": model["name"], "messages": [{"role": "user", "content": prompt}]}
    if model.get("temperature") is not None:
        body["temperature"] = model["temperature"]
    body.update(model.get("params", {}))
    response = requests.post(
        url,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        json=body,
        timeout=provider.get("timeout", 120),
    )
    response.raise_for_status()
    content = response.json()["choices"][0]["message"].get("content")
    if isinstance(content, list):
        content = "".join(
            item.get("text", "")
            for item in content
            if isinstance(item, dict) and isinstance(item.get("text"), str)
        )
    if not isinstance(content, str) or not content.strip():
        raise ValueError("The API returned empty text")
    return content.strip()
