import os
import random
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=12345)
    parser.add_argument("--bits", type=int, default=10000000)
    parser.add_argument("--output", type=str, default=None)
    args = parser.parse_args()

    if args.output is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        out_dir = os.path.join(base_dir, "outputs")
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, "secret_message.bin")
    else:
        out_path = args.output
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)

    total_bits = args.bits
    total_bytes = (total_bits + 7) // 8

    rng = random.Random(args.seed)
    data = bytes(rng.getrandbits(8) for _ in range(total_bytes))

    with open(out_path, "wb") as f:
        f.write(data)

    print(f"Generated {total_bytes} bytes ({total_bytes * 8} bits)")
    print(f"Saved to: {out_path}")


if __name__ == "__main__":
    main()
