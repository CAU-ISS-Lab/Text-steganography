import argparse
import hashlib
import json
from pathlib import Path
import random
import time


def experiment_summary(cfg):
    scenes = len(cfg["scenes"])
    trials = cfg["n_trials_per_scene"]
    return {
        "method": "DyCo-Stega", "profile": cfg.get("profile", "custom"),
        "seed": cfg.get("seed", 42), "alpha": cfg["alpha"], "b": cfg["L_seg"],
        "sigma": cfg["sigma"], "tau": cfg["n_embed_words"],
        "scenes": list(cfg["scenes"]), "image_trials_per_scene": trials,
        "target_stego": scenes * trials * cfg["n_stego_per_trial"],
        "target_cover": scenes * trials * cfg["n_cover_per_trial"],
        "caption_length": [cfg["text_min_len"], cfg["text_max_len"]],
        "caption_max_retries": cfg.get("caption_max_retries", cfg["max_retries"]),
        "image_max_refinements": cfg["max_retries"], "models": cfg["models"],
        "protocol": "fixed Phi; SHA-512 Theta; HMAC-SHA256 ordering; Appendix E XOR",
        "serialization": "UTF-8 canonical JSON; big-endian integers",
    }


def _save_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def _validate_trials(cfg, results):
    seen = set()
    for scene in cfg["scenes"]:
        if not results.get(scene):
            raise ValueError(f"No successful images for {scene}; generate images before captions.")
        for trial in results[scene]:
            tid = trial["trial_id"]
            if tid in seen:
                raise ValueError(f"Duplicate trial ID: {tid}")
            seen.add(tid)
            if not Path(trial["image_path"]).is_file():
                raise FileNotFoundError(f"Missing image for {tid}: {trial['image_path']}")
            if len(trial["keywords"]) != cfg["n_image_keywords"]:
                raise ValueError(f"Incorrect number of image keywords for {tid}")


def _rebuild_step2_from_cache(cfg, cache_path=None):
    from step2.run import run_step2
    root = Path(cfg["paths"]["outputs"])
    path = Path(cache_path) if cache_path not in (None, "auto") else root / "step2_cache.json"
    if path.is_file():
        cached = json.loads(path.read_text(encoding="utf-8"))
    elif cache_path not in (None, "auto"):
        raise FileNotFoundError(path)
    else:
        cached = {scene: json.loads((root / scene / "step2_meta.json").read_text(encoding="utf-8"))
                  for scene in cfg["scenes"]}
    _validate_trials(cfg, cached)
    return run_step2(cfg, {scene: cached[scene] for scene in cfg["scenes"]})


def main():
    parser = argparse.ArgumentParser(description="DyCo-Stega main experiment")
    parser.add_argument("--config-dir", help="Repository root containing configs/")
    parser.add_argument("--skip-step1", metavar="CACHE_JSON")
    parser.add_argument("--skip-step2", nargs="?", const="auto", metavar="CACHE_JSON")
    parser.add_argument("--check-config", action="store_true", help="Print settings without model/API calls")
    args = parser.parse_args()
    if args.skip_step1 and args.skip_step2:
        parser.error("Choose either --skip-step1 or --skip-step2")
    from utils.config import load_config
    base_dir = str(Path(args.config_dir or Path(__file__).parent).resolve())
    cfg = load_config(base_dir)
    summary = experiment_summary(cfg)
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    if args.check_config:
        return

    from protocol import load_psk
    load_psk(cfg)
    from step1.run import run_step1
    from step2.run import run_step2
    from step3.run import run_step3

    root = Path(cfg["paths"]["outputs"])
    secret_path = root / "secret_message.bin"
    needed_bits = summary["target_stego"] * cfg["n_embed_words"] * cfg["L_seg"]
    if not secret_path.is_file() or secret_path.stat().st_size * 8 < needed_bits:
        raise ValueError(f"Generate at least {needed_bits} bits with generate_secret.py first.")
    root.mkdir(parents=True, exist_ok=True)
    random.seed(cfg.get("seed", 42))
    summary["dictionary_sha256"] = hashlib.sha256(Path(cfg["paths"]["dictionary"]).read_bytes()).hexdigest()
    summary["status"] = "running"
    summary["verification_scope"] = "sender caption checks and bit roundtrip; receiver image recognition is separate"
    manifest = root / "run_manifest.json"
    _save_json(manifest, summary)
    start = time.time()
    try:
        if args.skip_step2:
            step2_results = _rebuild_step2_from_cache(cfg, args.skip_step2)
        else:
            if args.skip_step1:
                step1_results = json.loads(Path(args.skip_step1).read_text(encoding="utf-8"))
            else:
                step1_results = run_step1(cfg)
                _save_json(root / "step1_cache.json", step1_results)
            _validate_trials(cfg, step1_results)
            step2_results = run_step2(cfg, {scene: step1_results[scene] for scene in cfg["scenes"]})
        _save_json(root / "step2_cache.json", step2_results)
        summary["successful_images"] = {scene: len(trials) for scene, trials in step2_results.items()}
        summary["unsuccessful_image_trials"] = {
            scene: max(0, cfg["n_trials_per_scene"] - len(trials))
            for scene, trials in step2_results.items()
        }
        _, stego, cover = run_step3(cfg, step2_results)
        summary["actual_stego"] = sum(bool(s.strip()) for s in stego)
        summary["actual_cover"] = sum(bool(s.strip()) for s in cover)
        if (summary["actual_stego"], summary["actual_cover"]) != (summary["target_stego"], summary["target_cover"]):
            raise RuntimeError("The run did not reach its configured caption counts.")
        for name, lines in (("stego.txt", stego), ("cover.txt", cover)):
            (Path(base_dir) / name).write_text("\n".join(lines) + "\n", encoding="utf-8")
        summary["status"] = "complete"
        print(f"DyCo-Stega complete: {len(stego)} stego + {len(cover)} cover captions.")
    except Exception as exc:
        summary["status"] = "failed"
        summary["error_type"] = type(exc).__name__
        raise
    finally:
        summary["elapsed_seconds"] = round(time.time() - start, 3)
        _save_json(manifest, summary)


if __name__ == "__main__":
    main()
