# 🔐 DyCo-Stega

DyCo-Stega is a black-box text steganography method that uses images to build dynamic codebooks and embeds messages in natural image captions.

**Paper:** [Text Steganography with Dynamic Codebook and Multimodal Large Language Model](https://arxiv.org/abs/2604.20269)  
**Authors:** Jianxin Gao, Ruohan Lei, and Wanli Peng  
**arXiv:** [2604.20269](https://arxiv.org/abs/2604.20269)

## Generation and models

The workflow generates an image from seed words, builds a dictionary-based codebook, and maps message bits to codewords. A multimodal model then writes a caption containing the selected codewords and a public anchor. Recovery reconstructs the codebook from the image and caption, using the shared key and auxiliary bits.

Cover captions sample keywords from the codebook and use the same caption template.

| Role | Default API model |
|---|---|
| Image generation and editing | `gemini-3-pro-image-preview` |
| Seed-word recognition and image feedback | `gemini-3-pro-preview` |
| Cover/stego captions and caption feedback | `gpt-5.1-chat-latest` |

Text-quality evaluation uses GPT-2, BERT and Sentence-BERT; image-caption evaluation uses CLIP ViT-B/32.

## ⚙️ Getting started

Use Python 3.10 or later and run the following commands from this folder:

```bash
pip install -r requirements.txt
python -m nltk.downloader -d nltk_data stopwords wordnet punkt punkt_tab
```

Enter your model service URLs and API keys in `configs/experiment.yaml`. The sender and receiver also need the same 64-character hexadecimal key in `DYCO_STEGA_PSK`. In PowerShell:

```powershell
$env:DYCO_STEGA_PSK = '<your shared key>'
```

## 🚀 Run the experiment

```bash
python generate_secret.py --bits 10000000
python run_all.py --check-config
python run_all.py
```

The default setup uses Gemini for images and GPT-5.1 for captions, with `alpha=24`, `L_seg=28`, `sigma=2.5` and five codewords per caption. A full run targets 15,000 stego captions and 15,000 cover captions across three scenes. Model settings are in `configs/experiment.yaml`; scenes are in `configs/scenes.yaml`.

To reuse images from a previous run:

```bash
python run_all.py --skip-step1 outputs/step1_cache.json
```

## Recover a message

```bash
python decode.py --image public.png --caption-file caption.txt --side-info-file side_bits.txt --output recovered_bits.txt
```

Provide the public image, its caption and the corresponding auxiliary bitstring. The bitstring is saved as `side_information` in the generation record. Recovery uses the same dictionary, parameters and shared key as generation.

## 📊 Evaluate

```bash
python eval/eval_text_quality.py
python eval/eval_ec.py
python eval/eval_clip.py
```

These scripts evaluate text quality, embedding capacity and image-caption consistency.

## 📁 Results

The complete text sets are saved as `stego.txt` and `cover.txt`. Images, codebooks and per-sample records are grouped by scene under `outputs/`. Each sample record includes the input bits, auxiliary bits, recovered bits and verification result.

Text-quality and capacity reports are saved in `outputs/`; the CLIP report is saved in `eval/`. Each run writes to the same output paths.
