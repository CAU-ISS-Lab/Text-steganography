import base64
import re
import time
from typing import Any, Dict, List, Optional, Tuple

import requests


def _strip_think(text: Optional[str]) -> str:
    return text or ""


def _get_provider(cfg: Dict[str, Any], provider_name: str) -> Dict[str, Any]:
    prov = cfg["providers"][provider_name]
    if "url" not in prov or "key" not in prov:
        raise AssertionError(f"provider {provider_name} missing url/key")
    prov.setdefault("api", "openai_chat")
    return prov


def _get_model_cfg(cfg: Dict[str, Any], model_key: str) -> Dict[str, Any]:
    m = cfg["models"][model_key]
    if "name" not in m or "provider" not in m:
        raise AssertionError(f"model {model_key} missing name/provider")
    return m


def _post_with_retry(
    url: str,
    headers: Dict[str, str],
    body: Dict[str, Any],
    timeout: int,
    retries: int,
    delay: float,
) -> Dict[str, Any]:
    last_err: Optional[Exception] = None
    for i in range(retries):
        try:
            resp = requests.post(url, headers=headers, json=body, timeout=timeout)
            if resp.status_code != 200:
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:1200]}")
            return resp.json()
        except Exception as e:
            last_err = e
            if i < retries - 1:
                time.sleep(delay * (1.5 ** i))
    raise RuntimeError(f"API request failed after {retries} retries: {last_err}")


def _download_image_to_file_and_b64(url: str, path: str, timeout: int = 9999) -> Tuple[str, str]:
    resp = requests.get(url, timeout=timeout)
    if resp.status_code != 200:
        raise RuntimeError(f"Download failed HTTP {resp.status_code}: {resp.text[:500]}")
    data = resp.content
    with open(path, "wb") as f:
        f.write(data)
    b64 = base64.b64encode(data).decode("utf-8")
    return path, b64


def _save_base64_to_file(b64: str, path: str) -> None:
    if b64.endswith(")"):
        b64 = b64[:-1]
    if "base64," in b64:
        b64 = b64.split("base64,", 1)[-1]
    data = base64.b64decode(b64.strip())
    with open(path, "wb") as f:
        f.write(data)


def infer_mime_from_b64(b64: str) -> str:
    try:
        head = base64.b64decode(b64[:32])
    except Exception:
        return "image/png"
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if head[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "image/webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    return "image/png"


def _extract_base64_from_text(content: str) -> Optional[str]:
    if not content:
        return None
    m = re.search(r"base64,([A-Za-z0-9+/=]+)", content)
    if m:
        return m.group(1)
    s = content.strip()
    if len(s) > 1000 and " " not in s[:80]:
        return s
    return None


def _extract_image_url_from_text(content: str) -> Optional[str]:
    if not content:
        return None
    patterns: List[str] = [
        r"!\[[^\]]*\]\((https?://[^)\s]+)\)",
        r"\[点击下载\]\((https?://[^)\s]+)\)",
        r"(https?://[^\s)]+?\.(?:png|jpg|jpeg|webp|gif)(?:\?[^\s)]+)?)",
    ]
    for pat in patterns:
        m = re.search(pat, content)
        if m:
            return m.group(1)
    return None


def _get_choices_openai(j: Dict[str, Any]) -> List[Dict[str, Any]]:
    choices = j.get("choices")
    if isinstance(choices, list) and choices:
        return choices
    out = j.get("output")
    if isinstance(out, dict):
        oc = out.get("choices")
        if isinstance(oc, list) and oc:
            return oc
    raise RuntimeError(f"Bad response: {str(j)[:1200]}")


def _content_to_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for it in content:
            if isinstance(it, dict):
                if it.get("type") == "text" and isinstance(it.get("text"), str):
                    parts.append(it["text"])
                elif isinstance(it.get("text"), str):
                    parts.append(it["text"])
        return "".join(parts)
    return str(content)


def _extract_text_from_choice(choice: Dict[str, Any]) -> str:
    msg = choice.get("message") or {}
    content = msg.get("content")
    reasoning = msg.get("reasoning_content") or msg.get("reasoning")
    text = _content_to_text(content).strip()
    if text:
        return text
    return _content_to_text(reasoning).strip()


def _as_data_url(image: str, mime: str) -> str:
    if image.startswith("http://") or image.startswith("https://"):
        return image
    if image.startswith("data:") and ";base64," in image:
        return image
    return f"data:{mime};base64,{image}"


def _dashscope_extract_first_image_url(j: Dict[str, Any]) -> str:
    out = j.get("output") or {}
    choices = out.get("choices")
    if not isinstance(choices, list) or not choices:
        raise RuntimeError(f"Bad DashScope response: {str(j)[:1200]}")
    msg = choices[0].get("message") or {}
    content = msg.get("content")
    if not isinstance(content, list) or not content:
        raise RuntimeError(f"Bad DashScope response: {str(j)[:1200]}")
    for part in content:
        if isinstance(part, dict) and isinstance(part.get("image"), str) and part["image"].strip():
            return part["image"].strip()
    raise RuntimeError(f"No image url in DashScope response: {str(j)[:1200]}")


def call_chat(cfg: Dict[str, Any], model_key: str, user_text: str, require_non_empty: bool = False) -> str:
    mcfg = _get_model_cfg(cfg, model_key)
    prov = _get_provider(cfg, mcfg["provider"])
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {prov['key']}"}
    body: Dict[str, Any] = {"model": mcfg["name"], "messages": [{"role": "user", "content": user_text}]}
    if mcfg.get("temperature") is not None:
        body["temperature"] = mcfg["temperature"]
    body.update(dict(mcfg.get("params", {})))
    j = _post_with_retry(
        prov["url"],
        headers,
        body,
        timeout=prov.get("timeout", 300),
        retries=prov.get("retry_on_failure", 3),
        delay=prov.get("retry_delay", 2.0),
    )
    choices = _get_choices_openai(j)
    text = _extract_text_from_choice(choices[0])
    if require_non_empty and not (text or "").strip():
        raise RuntimeError(f"content is empty (finish_reason={choices[0].get('finish_reason', 'unknown')})")
    return _strip_think(text)


def call_chat_with_image(
    cfg: Dict[str, Any],
    model_key: str,
    user_text: str,
    image_b64: str,
    mime: str = "image/png",
    require_non_empty: bool = False,
) -> str:
    mcfg = _get_model_cfg(cfg, model_key)
    prov = _get_provider(cfg, mcfg["provider"])
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {prov['key']}"}
    img_url = _as_data_url(image_b64, mime)
    body: Dict[str, Any] = {
        "model": mcfg["name"],
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_text},
                    {"type": "image_url", "image_url": {"url": img_url}},
                ],
            }
        ],
    }
    if mcfg.get("temperature") is not None:
        body["temperature"] = mcfg["temperature"]
    body.update(dict(mcfg.get("params", {})))
    j = _post_with_retry(
        prov["url"],
        headers,
        body,
        timeout=prov.get("timeout", 300),
        retries=prov.get("retry_on_failure", 3),
        delay=prov.get("retry_delay", 2.0),
    )
    choices = _get_choices_openai(j)
    text = _extract_text_from_choice(choices[0])
    if require_non_empty and not (text or "").strip():
        raise RuntimeError(f"content is empty (finish_reason={choices[0].get('finish_reason', 'unknown')})")
    return _strip_think(text)


def call_image_generation(cfg: Dict[str, Any], prompt: str, save_path: str) -> Tuple[str, str]:
    mcfg = _get_model_cfg(cfg, "step1_image_generation")
    prov = _get_provider(cfg, mcfg["provider"])
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {prov['key']}"}

    if prov.get("api") == "dashscope_mmgen":
        body: Dict[str, Any] = {
            "model": mcfg["name"],
            "input": {"messages": [{"role": "user", "content": [{"text": prompt}]}]},
        }
        params = dict(mcfg.get("params", {}))
        if params:
            body["parameters"] = params
        j = _post_with_retry(
            prov["url"],
            headers,
            body,
            timeout=prov.get("timeout", 300),
            retries=prov.get("retry_on_failure", 3),
            delay=prov.get("retry_delay", 2.0),
        )
        img_url = _dashscope_extract_first_image_url(j)
        return _download_image_to_file_and_b64(img_url, save_path, timeout=prov.get("timeout", 300))

    body2: Dict[str, Any] = {"model": mcfg["name"], "messages": [{"role": "user", "content": prompt}]}
    if mcfg.get("temperature") is not None:
        body2["temperature"] = mcfg["temperature"]
    body2.update(dict(mcfg.get("params", {})))
    j2 = _post_with_retry(
        prov["url"],
        headers,
        body2,
        timeout=prov.get("timeout", 300),
        retries=prov.get("retry_on_failure", 3),
        delay=prov.get("retry_delay", 2.0),
    )
    choices = _get_choices_openai(j2)
    content = _extract_text_from_choice(choices[0]) or ""
    b64 = _extract_base64_from_text(content)
    if b64:
        _save_base64_to_file(b64, save_path)
        return save_path, b64
    img_url2 = _extract_image_url_from_text(content)
    if img_url2:
        return _download_image_to_file_and_b64(img_url2, save_path, timeout=prov.get("timeout", 300))
    raise RuntimeError(f"No base64 or image url found in generation response: {str(j2)[:1200]}")


def call_image_edit(
    cfg: Dict[str, Any],
    prompt: str,
    image_b64: str,
    save_path: str,
    mime: str = "image/png",
) -> Tuple[str, str]:
    model_key = "step1_image_edit" if "step1_image_edit" in cfg.get("models", {}) else "step1_image_generation"
    mcfg = _get_model_cfg(cfg, model_key)
    prov = _get_provider(cfg, mcfg["provider"])
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {prov['key']}"}

    if prov.get("api") == "dashscope_mmgen":
        body: Dict[str, Any] = {
            "model": mcfg["name"],
            "input": {
                "messages": [
                    {"role": "user", "content": [{"image": _as_data_url(image_b64, mime)}, {"text": prompt}]}
                ]
            },
        }
        params = dict(mcfg.get("params", {}))
        if params:
            body["parameters"] = params
        j = _post_with_retry(
            prov["url"],
            headers,
            body,
            timeout=prov.get("timeout", 300),
            retries=prov.get("retry_on_failure", 3),
            delay=prov.get("retry_delay", 2.0),
        )
        img_url = _dashscope_extract_first_image_url(j)
        return _download_image_to_file_and_b64(img_url, save_path, timeout=prov.get("timeout", 300))

    img_url2 = _as_data_url(image_b64, mime)
    body2: Dict[str, Any] = {
        "model": mcfg["name"],
        "messages": [
            {"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": img_url2}}]}
        ],
    }
    if mcfg.get("temperature") is not None:
        body2["temperature"] = mcfg["temperature"]
    body2.update(dict(mcfg.get("params", {})))
    j2 = _post_with_retry(
        prov["url"],
        headers,
        body2,
        timeout=prov.get("timeout", 300),
        retries=prov.get("retry_on_failure", 3),
        delay=prov.get("retry_delay", 2.0),
    )
    choices = _get_choices_openai(j2)
    content = _extract_text_from_choice(choices[0]) or ""
    b64 = _extract_base64_from_text(content)
    if b64:
        _save_base64_to_file(b64, save_path)
        return save_path, b64
    u = _extract_image_url_from_text(content)
    if u:
        return _download_image_to_file_and_b64(u, save_path, timeout=prov.get("timeout", 300))
    raise RuntimeError(f"No base64 or image url found in edit response: {str(j2)[:1200]}")
