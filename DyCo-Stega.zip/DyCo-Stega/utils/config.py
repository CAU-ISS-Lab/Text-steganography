import os
import yaml


def load_config(base_dir: str = None) -> dict:
    if base_dir is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    exp_path = os.path.join(base_dir, "configs", "experiment.yaml")
    with open(exp_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    scenes_rel = cfg.get("scenes_file", "configs/scenes.yaml")
    scenes_path = os.path.join(base_dir, scenes_rel)
    with open(scenes_path, "r", encoding="utf-8") as f:
        all_scenes = yaml.safe_load(f)

    enabled = cfg.get("enabled_scenes", None)
    if enabled:
        all_scenes = {k: v for k, v in all_scenes.items() if k in enabled}
    cfg["scenes"] = all_scenes

    prompts_dir = os.path.join(base_dir, cfg["paths"]["prompts_dir"])
    prompt_templates = {}
    for key, filename in cfg.get("prompts", {}).items():
        fpath = os.path.join(prompts_dir, filename)
        if os.path.exists(fpath):
            with open(fpath, "r", encoding="utf-8") as f:
                prompt_templates[key] = f.read()
        else:
            prompt_templates[key] = ""
    cfg["prompt_templates"] = prompt_templates

    cfg["paths"]["dictionary"] = os.path.join(base_dir, cfg["paths"]["dictionary"])
    cfg["paths"]["outputs"] = os.path.join(base_dir, "outputs")
    cfg["paths"]["base_dir"] = base_dir

    alpha = cfg.get("alpha", 24)
    cfg["semantic_pool_size"] = alpha

    positive = ("n_trials_per_scene", "n_image_keywords", "n_embed_words",
                "n_stego_per_trial", "n_cover_per_trial", "L_seg", "alpha")
    for name in positive:
        if not isinstance(cfg.get(name), int) or cfg[name] <= 0:
            raise ValueError(f"{name} must be a positive integer")
    if cfg["alpha"] < cfg["n_image_keywords"] or cfg["L_seg"] > 52:
        raise ValueError("Invalid pool size or bit width for floating-point quantization")
    if cfg["sigma"] <= 0 or not 0 < cfg["text_min_len"] <= cfg["text_max_len"]:
        raise ValueError("Invalid shaping parameter or caption length")
    if not cfg["scenes"]:
        raise ValueError("At least one scene must be enabled")
    if cfg["n_stego_per_trial"] != cfg["n_cover_per_trial"]:
        raise ValueError("The paired main experiment requires equal stego/cover counts")
    if cfg.get("profile") == "paper_main":
        expected = (24, 28, 2.5, 5)
        actual = (cfg["alpha"], cfg["L_seg"], cfg["sigma"], cfg["n_embed_words"])
        if actual != expected:
            raise ValueError("paper_main requires alpha=24, L_seg=28, sigma=2.5, tau=5")

    return cfg
