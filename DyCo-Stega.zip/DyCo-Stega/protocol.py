import hashlib
import json
import os

from step2.codebook import build_codebook

ANCHOR_ALPHABET = ("✨", "🌿", "☀", "☕", "🌙", "🍃", "💫", "🌼",
                   "📷", "🌱", "⭐", "🪴", "🌸", "☁", "🍀", "🌻")


def canonical_bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def load_psk(cfg):
    env_name = cfg.get("psk_env", "DYCO_STEGA_PSK")
    value = os.environ.get(env_name, "").strip()
    try:
        key = bytes.fromhex(value)
    except ValueError:
        key = b""
    if len(key) != 32 or len(value) != 64:
        raise ValueError(f"Set {env_name} to a 256-bit PSK (64 hex characters).")
    return key


def anchor_for_sample(sample_id):

    tag = hashlib.sha256(str(sample_id).encode("utf-8")).digest()[:2]
    return "".join(ANCHOR_ALPHABET[n] for byte in tag for n in (byte >> 4, byte & 15))


def extract_anchor(caption):
    symbols = [c for c in caption if c in ANCHOR_ALPHABET]
    if len(symbols) != 4:
        raise ValueError("Expected exactly four public anchor symbols in the caption")
    return "".join(symbols)


def derive_session_seed(psk, ordered_seeds, anchor_sequence, alpha, b, sigma):
    if len(psk) != 32:
        raise ValueError("The PSK must contain exactly 32 bytes.")
    if not anchor_sequence or not ordered_seeds:
        raise ValueError("An anchor and ordered seed words are required.")
    public = canonical_bytes({"ordered_seeds": list(ordered_seeds),
                              "anchor_sequence": anchor_sequence})
    theta = hashlib.sha512(psk + public).digest()[32:]
    phi = canonical_bytes({"alpha": int(alpha), "b": int(b), "sigma": float(sigma)})
    return int.from_bytes(hashlib.sha256(phi + theta).digest(), "big")


def create_session(cfg, ordered_seeds, word_list, anchor_sequence):
    alpha, b, sigma = int(cfg["alpha"]), int(cfg["L_seg"]), float(cfg["sigma"])
    if len(word_list) != alpha or len(set(word_list)) != alpha:
        raise ValueError(f"Expected {alpha} distinct semantic-pool words.")
    if list(word_list[:len(ordered_seeds)]) != list(ordered_seeds):
        raise ValueError("Ordered seeds must lead the semantic pool.")
    xi = derive_session_seed(load_psk(cfg), ordered_seeds, anchor_sequence,
                             alpha, b, sigma)
    return {"session_seed": xi, "anchor_sequence": anchor_sequence,
            "codebook": build_codebook(word_list, sigma, session_seed=xi)}
