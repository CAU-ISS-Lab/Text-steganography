import importlib.util
import json
import math
from pathlib import Path
import tempfile
import unittest

import numpy as np


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


HERE = Path(__file__).resolve().parent
quality = load_module("dyco_quality", HERE / "eval_text_quality.py")
capacity = load_module("dyco_capacity", HERE / "eval_ec.py")


def write_lines(path, lines):
    Path(path).write_text("".join(line + "\n" for line in lines), encoding="utf-8")


def sample(sample_id, caption, payload="01010101", verified=True, recovered=None):
    return {
        "sample_id": sample_id, "caption": caption, "selected_words": ["apple", "mug"],
        "payload_bits": payload, "side_information": "0" * len(payload),
        "recovered_bits": payload if recovered is None else recovered, "verified": verified,
    }


def write_scene(root, name, records):
    scene = Path(root) / name
    (scene / "stego").mkdir(parents=True)
    write_lines(scene / "stego.txt", [record["caption"] for record in records])
    (scene / "stego" / "trial_records.json").write_text(json.dumps(records), encoding="utf-8")
    (scene / "step3_meta.json").write_text(json.dumps([
        {"trial_id": "trial", "stego_records_path": "stego/trial_records.json"},
    ]), encoding="utf-8")
    return scene


class MetricMathTests(unittest.TestCase):
    def test_shifted_gaussian_kld_and_identity(self):
        cover = np.array([[0., 2.], [2., 4.]])
        stego = cover + [1., -2.]
        self.assertAlmostEqual(quality.compute_kld_gaussian(cover, stego), 2.499999950000001, places=12)
        self.assertEqual(quality.compute_kld_gaussian(cover, cover), 0.)

    def test_cosines_and_rejected_broadcasting(self):
        cover = [[1., 0.], [0., 1.], [0., 0.]]
        stego = [[1., 0.], [0., -1.], [1., 0.]]
        np.testing.assert_allclose(quality.compute_pairwise_cosine_similarity(cover, stego), [1., -1., 0.])
        with self.assertRaises(ValueError):
            quality.compute_pairwise_cosine_similarity([[1., 0.]], stego)

    def test_ppl_is_mean_of_sentence_ppls_without_loss_clipping(self):
        losses = np.log([2., 8.])
        ppls = quality.perplexities_from_mean_losses(losses)
        self.assertAlmostEqual(np.mean(ppls), 5.)
        self.assertNotAlmostEqual(np.mean(ppls), np.exp(np.mean(losses)))
        self.assertGreater(quality.perplexities_from_mean_losses([101])[0], np.exp(100))
        self.assertEqual(quality.PPL_MAX_LENGTH, 1024)
        with self.assertRaises(ValueError):
            quality.perplexities_from_mean_losses([0., float("nan")])
        with self.assertRaises(ValueError):
            quality.perplexities_from_mean_losses([1000.])

    def test_overall_kld_uses_pooled_features_and_sample_weighting(self):
        cover_parts = [np.array([[0.], [2.]]), np.array([[10.]])]
        stego_parts = [np.array([[1.], [3.]]), np.array([[10.]])]
        data = {
            "cover_bert": cover_parts, "stego_bert": stego_parts,
            "cover_sbert": [np.ones((2, 2)), np.ones((1, 2))],
            "stego_sbert": [np.ones((2, 2)), np.ones((1, 2))],
            "cover_ppls": [[10., 20.], [90.]], "stego_ppls": [[10., 20.], [90.]],
        }
        result = quality.summarize_features(data)
        self.assertAlmostEqual(result["kld"], 0.028728954902286663, places=12)
        self.assertNotAlmostEqual(result["kld"], 0.2499999950000001)
        self.assertEqual(result["stego_ppl_mean"], 40.)
        self.assertEqual(result["n_stego"], 3)

    def test_finite_feature_validation(self):
        with self.assertRaises(ValueError):
            quality.compute_kld_gaussian([[float("nan")]], [[0.]])


class AlignmentTests(unittest.TestCase):
    def test_blank_caption_is_not_dropped(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "cover.txt"
            write_lines(path, ["first caption", "", "third caption"])
            with self.assertRaisesRegex(ValueError, "Blank caption"):
                quality.load_lines(path)

    def test_count_mismatch_is_an_error(self):
        with tempfile.TemporaryDirectory() as root:
            write_lines(Path(root) / "cover.txt", ["one cover", "two cover"])
            write_lines(Path(root) / "stego.txt", ["one stego"])
            with self.assertRaisesRegex(ValueError, "Unaligned"):
                quality.load_paired_lines(root)


class CapacityTests(unittest.TestCase):
    def test_actual_payload_auxiliary_and_recovery_are_separate(self):
        records = [sample("a", "apple mug"), sample("b", "apple beside mug", recovered="00000000")]
        result = capacity.summarize_records(records, [r["caption"] for r in records])
        self.assertEqual(result["total_payload_bits"], 16)
        self.assertEqual(result["total_auxiliary_bits"], 16)
        self.assertEqual(result["total_recovered_bits"], 8)
        self.assertEqual(result["EC_bpw"], 16 / 5)
        self.assertEqual(result["auxiliary_bpw"], 16 / 5)
        self.assertEqual(result["recovered_bpw"], 8 / 5)
        self.assertEqual(result["exact_recovery_rate"], .5)

    def test_failed_verification_does_not_get_full_payload_credit(self):
        records = [sample("a", "apple mug"), sample("b", "apple mug", verified=False)]
        result = capacity.summarize_records(records, [r["caption"] for r in records])
        self.assertEqual(result["total_recorded_payload_bits"], 16)
        self.assertEqual(result["total_payload_bits"], 8)
        self.assertEqual(result["n_verified"], 1)

    def test_scene_totals_are_combined_as_ratio_of_totals(self):
        with tempfile.TemporaryDirectory() as root:
            write_scene(root, "a", [sample("a-1", "apple mug")])
            write_scene(root, "b", [sample("b-1", "apple and mug sit on desk")])
            report = capacity.evaluate_capacity(root)
            self.assertEqual(report["overall"]["EC_bpw"], 16 / 8)
            scene_avg = np.mean([r["EC_bpw"] for r in report["per_scene"].values()])
            self.assertNotEqual(report["overall"]["EC_bpw"], scene_avg)

    def test_record_alignment_and_duplicate_ids_are_rejected(self):
        records = [sample("a", "apple mug"), sample("b", "mug beside apple")]
        with self.assertRaisesRegex(ValueError, "mismatch"):
            capacity.summarize_records(records, [r["caption"] for r in reversed(records)])
        records[1]["sample_id"] = "a"
        with self.assertRaisesRegex(ValueError, "duplicate"):
            capacity.summarize_records(records, [r["caption"] for r in records])

    def test_missing_or_malformed_record_fields_are_rejected(self):
        for key, value in [("payload_bits", "0123"), ("side_information", "0"), ("verified", None)]:
            record = sample("a", "apple mug")
            record[key] = value
            with self.assertRaises(ValueError):
                capacity.summarize_records([record], [record["caption"]])

    def test_legacy_is_opt_in_and_does_not_claim_verified_capacity(self):
        with tempfile.TemporaryDirectory() as root:
            scene = Path(root) / "scene"
            scene.mkdir()
            write_lines(scene / "stego.txt", ["apple mug"])
            with self.assertRaises(FileNotFoundError):
                capacity.evaluate_capacity(root)
            with self.assertRaises(ValueError):
                capacity.evaluate_capacity(root, legacy_estimate=True)
            report = capacity.evaluate_capacity(root, True, 5, 28)
            self.assertEqual(report["overall"]["estimated_EC_bpw"], 70)
            self.assertIsNone(report["overall"]["EC_bpw"])
            self.assertIsNone(report["overall"]["total_auxiliary_bits"])


class OfflineIntegrationTests(unittest.TestCase):
    def test_scene_evaluation_with_fake_features(self):
        features = {
            "cover one": [1., 2.], "cover two": [3., 4.],
            "stego one": [2., 2.], "stego two": [4., 4.],
        }

        class FakePPL:
            def score_sentences(self, sentences):
                return [10., 20.]

        class FakeEncoder:
            def encode(self, sentences):
                return np.array([features[sentence] for sentence in sentences])

        with tempfile.TemporaryDirectory() as root:
            scene = Path(root) / "method"
            scene.mkdir()
            write_lines(scene / "cover.txt", ["cover one", "cover two"])
            write_lines(scene / "stego.txt", ["stego one", "stego two"])
            result = quality.evaluate_scene("method", scene, FakePPL(), FakeEncoder(), FakeEncoder())
            self.assertEqual(result["stego_ppl_mean"], 15.)
            self.assertAlmostEqual(result["kld"], 0.4999999900000002, places=12)
            self.assertAlmostEqual(result["ss_mean"], (3 / math.sqrt(10) + 7 / (5 * math.sqrt(2))) / 2)
            self.assertEqual(result["n_stego"], 2)


if __name__ == "__main__":
    unittest.main()
