import argparse
import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
OUTPUT_DIR = PROJECT_ROOT / "outputs"


def read_lines(filepath):
    with open(filepath, encoding="utf-8") as stream:
        lines = [line.strip() for line in stream]
    if not lines or any(not line for line in lines):
        raise ValueError(f"Empty or missing caption row in {filepath}")
    return lines


def get_scene_dirs(output_dir):
    root = Path(output_dir)
    if not root.is_dir():
        raise FileNotFoundError(f"Output directory not found: {root}")
    return [
        (path.name, path) for path in sorted(root.iterdir())
        if path.is_dir() and not path.name.startswith(".") and (path / "stego.txt").is_file()
    ]


def _resolve_record_path(value, scene_path):
    if not isinstance(value, str) or not value:
        raise ValueError(f"Missing stego_records_path in {scene_path / 'step3_meta.json'}")
    path = Path(value)
    candidates = [path] if path.is_absolute() else [
        scene_path / path, scene_path.parent / path, PROJECT_ROOT / path, path,
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"Records file not found: {value}")


def load_scene_records(scene_path):
    scene_path = Path(scene_path)
    meta_path = scene_path / "step3_meta.json"
    if not meta_path.is_file():
        raise FileNotFoundError(
            f"Missing {meta_path}; historical outputs require explicit --legacy-estimate"
        )
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    if not isinstance(meta, list) or not meta:
        raise ValueError(f"Expected a nonempty trial list in {meta_path}")
    records, paths = [], set()
    for trial in meta:
        if not isinstance(trial, dict):
            raise ValueError(f"Invalid trial metadata in {meta_path}")
        path = _resolve_record_path(trial.get("stego_records_path"), scene_path).resolve()
        if path in paths:
            raise ValueError(f"Duplicate records file in metadata: {path}")
        paths.add(path)
        batch = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(batch, list) or not batch:
            raise ValueError(f"Expected nonempty records in {path}")
        records.extend(batch)
    return records


def validate_records(records, captions):
    if not records or len(records) != len(captions):
        raise ValueError(f"Records/captions count mismatch: records={len(records)}, captions={len(captions)}")
    seen = set()
    for row, (record, caption) in enumerate(zip(records, captions), 1):
        if not isinstance(record, dict):
            raise ValueError(f"Invalid sample record at row {row}")
        sample_id = record.get("sample_id")
        if not isinstance(sample_id, str) or not sample_id or sample_id in seen:
            raise ValueError(f"Missing or duplicate sample_id at row {row}")
        seen.add(sample_id)
        if not isinstance(caption, str) or not caption.strip() or record.get("caption") != caption:
            raise ValueError(f"Record/caption mismatch at {sample_id}")
        if not isinstance(record.get("verified"), bool):
            raise ValueError(f"Missing boolean verified flag at {sample_id}")
        words = record.get("selected_words")
        if not isinstance(words, list) or not words or any(not isinstance(w, str) or not w for w in words):
            raise ValueError(f"Missing selected_words at {sample_id}")
        for field in ("payload_bits", "side_information", "recovered_bits"):
            value = record.get(field)
            if not isinstance(value, str) or set(value) - {"0", "1"}:
                raise ValueError(f"Missing or non-binary {field} at {sample_id}")
        payload = record["payload_bits"]
        if not payload or len(payload) % len(words):
            raise ValueError(f"Payload must contain fixed-width codeword segments at {sample_id}")
        if len(record["side_information"]) != len(payload):
            raise ValueError(f"Side information must have tau*b bits at {sample_id}")


def summarize_records(records, captions):
    validate_records(records, captions)
    total_words = sum(len(caption.split()) for caption in captions)
    verified = [record for record in records if record["verified"]]
    recovered = [record for record in verified if record["recovered_bits"] == record["payload_bits"]]
    payload = sum(len(record["payload_bits"]) for record in verified)
    auxiliary = sum(len(record["side_information"]) for record in verified)
    recovered_bits = sum(len(record["payload_bits"]) for record in recovered)
    return {
        "mode": "records", "n_sentences": len(captions),
        "n_verified": len(verified), "n_exactly_recovered": len(recovered),
        "total_words": total_words,
        "total_recorded_payload_bits": sum(len(record["payload_bits"]) for record in records),
        "total_payload_bits": payload, "total_auxiliary_bits": auxiliary,
        "total_recorded_auxiliary_bits": sum(len(record["side_information"]) for record in records),
        "total_recovered_bits": recovered_bits,
        "EC_bpw": payload / total_words,
        "auxiliary_bpw": auxiliary / total_words,
        "recovered_bpw": recovered_bits / total_words,
        "exact_recovery_rate": len(recovered) / len(records),
    }


def estimate_legacy(captions, n_embed_words, bits_per_codeword):
    if not captions or any(not caption.strip() for caption in captions):
        raise ValueError("Legacy estimation still requires nonempty captions")
    if n_embed_words <= 0 or bits_per_codeword <= 0:
        raise ValueError("Legacy estimation requires positive embedding parameters")
    total_words = sum(len(caption.split()) for caption in captions)
    estimated_bits = len(captions) * n_embed_words * bits_per_codeword
    return {
        "mode": "legacy_estimate", "n_sentences": len(captions), "total_words": total_words,
        "n_embed_words": n_embed_words, "bits_per_codeword": bits_per_codeword,
        "estimated_payload_bits": estimated_bits, "estimated_EC_bpw": estimated_bits / total_words,
        "total_payload_bits": None, "total_auxiliary_bits": None, "total_recovered_bits": None,
        "EC_bpw": None, "auxiliary_bpw": None, "recovered_bpw": None,
        "n_verified": None, "n_exactly_recovered": None, "exact_recovery_rate": None,
    }


def evaluate_capacity(output_dir, legacy_estimate=False, n_embed_words=None, bits_per_codeword=None):
    if legacy_estimate and (not n_embed_words or not bits_per_codeword):
        raise ValueError("--legacy-estimate requires --n-embed-words and --bits-per-codeword")
    scenes = get_scene_dirs(output_dir)
    if not scenes:
        raise ValueError("No scene stego files found")
    per_scene, all_captions, all_records = {}, [], []
    for name, scene_path in scenes:
        captions = read_lines(scene_path / "stego.txt")
        if legacy_estimate:
            result = estimate_legacy(captions, n_embed_words, bits_per_codeword)
        else:
            records = load_scene_records(scene_path)
            result = summarize_records(records, captions)
            all_records.extend(records)
        all_captions.extend(captions)
        per_scene[name] = result
    overall = (
        estimate_legacy(all_captions, n_embed_words, bits_per_codeword) if legacy_estimate
        else summarize_records(all_records, all_captions)
    )
    return {
        "settings": {
            "word_counting": "whitespace_split", "aggregation": "total_bits_over_total_words",
            "capacity": "nominal verified payload; auxiliary channel is reported separately",
            "recovery": "exact payload equality for verified samples",
            "legacy_estimate": legacy_estimate,
        },
        "per_scene": per_scene, "overall": overall,
    }


def main():
    parser = argparse.ArgumentParser(description="DyCo-Stega record-based payload and auxiliary capacity")
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--legacy-estimate", action="store_true",
                        help="Explicitly estimate historical capacity; no recovery or auxiliary claim")
    parser.add_argument("--n-embed-words", type=int)
    parser.add_argument("--bits-per-codeword", type=int)
    args = parser.parse_args()
    if not args.legacy_estimate and (args.n_embed_words is not None or args.bits_per_codeword is not None):
        parser.error("Embedding parameters are only used with --legacy-estimate")
    report = evaluate_capacity(
        args.output_dir, args.legacy_estimate, args.n_embed_words, args.bits_per_codeword,
    )
    path = args.output_dir / "eval_ec.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    print(json.dumps(report["overall"], indent=2))
    print(f"Report: {path}")


if __name__ == "__main__":
    main()
