import os
import sys
import json
import numpy as np
import torch
from PIL import Image
from tqdm import tqdm

os.environ["TOKENIZERS_PARALLELISM"] = "false"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "..", "outputs")
CLIP_MODEL_NAME = "openai/clip-vit-base-patch32"


def get_scene_dirs(output_dir):
    scenes = []
    for name in sorted(os.listdir(output_dir)):
        scene_path = os.path.join(output_dir, name)
        if os.path.isdir(scene_path) and not name.startswith(".") and name != "eval":
            meta_path = os.path.join(scene_path, "step3_meta.json")
            if os.path.isfile(meta_path):
                scenes.append((name, scene_path))
    return scenes


def read_lines(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
    return lines


def load_trial_info(scene_path):
    meta_path = os.path.join(scene_path, "step3_meta.json")
    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    trials = []
    for entry in meta:
        image_path = entry["image_path"]
        stego_path = entry["stego_path"]
        cover_path = entry["cover_path"]

        if not os.path.isfile(image_path):
            continue
        if not os.path.isfile(stego_path):
            continue
        if not os.path.isfile(cover_path):
            continue

        stego_lines = read_lines(stego_path)
        cover_lines = read_lines(cover_path)

        if not stego_lines and not cover_lines:
            continue

        trials.append({
            "trial_id": entry["trial_id"],
            "image_path": image_path,
            "stego_lines": stego_lines,
            "cover_lines": cover_lines,
        })

    return trials


def compute_clip_scores_batch(image_path, sentences, model, processor, device,
                              batch_size=32):
    if not sentences:
        return []

    image = Image.open(image_path).convert("RGB")

    all_scores = []
    for start in range(0, len(sentences), batch_size):
        batch = sentences[start:start + batch_size]

        inputs = processor(
            text=batch,
            images=[image] * len(batch),
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=77,
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = model(**inputs)
            logits = outputs.logits_per_image[0]
            scores = logits.cpu().numpy().tolist()
            all_scores.extend(scores)

    return all_scores


def eval_clip(scenes):
    from transformers import CLIPModel, CLIPProcessor

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[INFO] Using device: {device}")
    print(f"[INFO] Loading CLIP model: {CLIP_MODEL_NAME}")

    model = CLIPModel.from_pretrained(CLIP_MODEL_NAME).to(device)
    processor = CLIPProcessor.from_pretrained(CLIP_MODEL_NAME)
    model.eval()

    all_results = {}

    for scene_name, scene_path in scenes:
        print(f"\n{'=' * 60}")
        print(f"  Scene: {scene_name}")
        print(f"{'=' * 60}")

        trials = load_trial_info(scene_path)
        if not trials:
            print(f"  [WARN] No valid trials found, skipping.")
            continue

        scene_cover_scores = []
        scene_stego_scores = []
        trial_results = []

        for trial in tqdm(trials, desc=f"  {scene_name} CLIP", leave=True):
            tid = trial["trial_id"]
            image_path = trial["image_path"]
            stego_lines = trial["stego_lines"]
            cover_lines = trial["cover_lines"]

            cover_scores = compute_clip_scores_batch(
                image_path, cover_lines, model, processor, device
            )
            stego_scores = compute_clip_scores_batch(
                image_path, stego_lines, model, processor, device
            )

            avg_cover = float(np.mean(cover_scores)) if cover_scores else 0.0
            avg_stego = float(np.mean(stego_scores)) if stego_scores else 0.0

            print(f"    {tid}: cover={avg_cover:.4f} ({len(cover_scores)} sents)  "
                  f"stego={avg_stego:.4f} ({len(stego_scores)} sents)  "
                  f"diff={avg_stego - avg_cover:+.4f}")

            scene_cover_scores.extend(cover_scores)
            scene_stego_scores.extend(stego_scores)

            trial_results.append({
                "trial_id": tid,
                "n_cover": len(cover_scores),
                "n_stego": len(stego_scores),
                "avg_cover_clip": round(avg_cover, 4),
                "avg_stego_clip": round(avg_stego, 4),
            })

        scene_avg_cover = float(np.mean(scene_cover_scores)) if scene_cover_scores else 0.0
        scene_avg_stego = float(np.mean(scene_stego_scores)) if scene_stego_scores else 0.0
        scene_avg_diff = scene_avg_stego - scene_avg_cover

        print(f"\n  {scene_name} AVG: cover={scene_avg_cover:.4f}  "
              f"stego={scene_avg_stego:.4f}  diff={scene_avg_diff:+.4f}")

        all_results[scene_name] = {
            "trials": trial_results,
            "n_cover_total": len(scene_cover_scores),
            "n_stego_total": len(scene_stego_scores),
            "avg_cover_clip": round(scene_avg_cover, 4),
            "avg_stego_clip": round(scene_avg_stego, 4),
            "avg_diff": round(scene_avg_diff, 4),
        }

    print(f"\n{'=' * 60}")
    print(f"  CLIP SUMMARY")
    print(f"{'=' * 60}")
    print(f"  {'Scene':<30} {'N_cover':>8} {'N_stego':>8} {'Cover':>10} {'Stego':>10} {'Diff':>10}")
    print(f"  {'-' * 78}")

    all_cover = []
    all_stego = []

    for scene_name in all_results:
        r = all_results[scene_name]
        all_cover.append(r["avg_cover_clip"])
        all_stego.append(r["avg_stego_clip"])
        print(f"  {scene_name:<30} {r['n_cover_total']:>8} {r['n_stego_total']:>8} "
              f"{r['avg_cover_clip']:>10.4f} {r['avg_stego_clip']:>10.4f} "
              f"{r['avg_diff']:>+10.4f}")

    print(f"  {'-' * 78}")
    if all_cover:
        oc = np.mean(all_cover)
        os_avg = np.mean(all_stego)
        od = os_avg - oc
        print(f"  {'OVERALL':<30} {'':>8} {'':>8} "
              f"{oc:>10.4f} {os_avg:>10.4f} {od:>+10.4f}")
    print()

    return all_results


if __name__ == "__main__":
    output_dir = os.path.normpath(OUTPUT_DIR)
    print(f"[INFO] Output directory: {output_dir}")

    scenes = get_scene_dirs(output_dir)
    if not scenes:
        print("[ERROR] No scene folders with step3_meta.json found!")
        sys.exit(1)

    print(f"[INFO] Found {len(scenes)} scenes: {[s[0] for s in scenes]}\n")

    clip_results = eval_clip(scenes)

    save_path = os.path.join(SCRIPT_DIR, "clip_results.json")
    serializable = {}
    for k, v in clip_results.items():
        serializable[k] = {
            "avg_cover_clip": float(v["avg_cover_clip"]),
            "avg_stego_clip": float(v["avg_stego_clip"]),
            "avg_diff": float(v["avg_diff"]),
            "n_cover_total": v["n_cover_total"],
            "n_stego_total": v["n_stego_total"],
            "trials": v["trials"],
        }
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(serializable, f, indent=2, ensure_ascii=False)
    print(f"[INFO] Results saved to {save_path}")
