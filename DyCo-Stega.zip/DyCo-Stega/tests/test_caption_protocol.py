import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from eval.eval_ec import evaluate_capacity
from protocol import anchor_for_sample
from step2.codebook import BitstreamRNG, encode_from_bitstream
from step3 import run
from step3.validation import extract_codewords, verify_caption


class CaptionVerificationTests(unittest.TestCase):
    def setUp(self):
        self.anchor = anchor_for_sample("fixture")
        self.words = ["mug", "pen", "lamp"]

    def test_duplicate_codewords_survive_plural_normalization(self):
        caption = f"Mugs rest beside a pen and another mug. {self.anchor}"
        self.assertEqual(extract_codewords(caption, self.words), ["mug", "pen", "mug"])
        self.assertEqual(verify_caption(caption, ["mug", "pen", "mug"], self.words, self.anchor, 1, 30), [])

    def test_rejects_order_counts_forbidden_words_and_anchor_errors(self):
        captions = [
            f"A pen lies beside a mug and another mug {self.anchor}",
            f"A mug lies beside a pen {self.anchor}",
            f"A mug lies beside a pen and another mug under a lamp {self.anchor}",
            "A mug lies beside a pen and another mug",
            f"A mug lies beside a pen and another mug {self.anchor} {self.anchor}",
        ]
        for caption in captions:
            with self.subTest(caption=caption):
                self.assertTrue(verify_caption(caption, ["mug", "pen", "mug"], self.words, self.anchor, 1, 30))

    def test_rejects_ambiguous_plural_and_multiple_sentences(self):
        with self.assertRaisesRegex(ValueError, "Ambiguous"):
            extract_codewords("glasses", ["glass", "glasses"])
        self.assertTrue(verify_caption(f"A mug rests. A pen shines. {self.anchor}", ["mug", "pen"], self.words, self.anchor, 1, 30))


class CaptionGenerationTests(unittest.TestCase):
    def make_job(self):
        anchor = anchor_for_sample("test-job")
        codebook = [{"word": "mug", "probability": 0.75}, {"word": "pen", "probability": 0.25}]
        session = {"codebook": codebook, "session_seed": 7}
        encoded = encode_from_bitstream(codebook, 4, 3, BitstreamRNG(5), 7)
        record = dict(encoded, sample_id="test-job", kind="stego", anchor_sequence=anchor)
        job = {"record": record, "session": session, "all_words": ["mug", "pen"], "prompt": "original"}
        cfg = {"L_seg": 4, "text_min_len": 1, "text_max_len": 30, "caption_max_retries": 1,
               "models": {"step3_stego_generation": {}}, "prompt_templates": {}}
        caption = " and ".join(encoded["selected_words"]) + " rest here " + anchor
        return cfg, job, caption

    def test_constraint_failure_feedback_then_real_decode(self):
        cfg, job, caption = self.make_job()
        with patch.object(run, "call_chat_with_image", side_effect=["A landscape", "Insert the required words and anchor.", caption]) as api:
            record = run._generate_one_caption(cfg, "step3_stego_generation", job, "image")
        self.assertTrue(record["verified"])
        self.assertEqual(record["recovered_bits"], record["payload_bits"])
        self.assertEqual(len(record["attempts"]), 2)
        self.assertEqual(api.call_count, 3)

    def test_api_exhaustion_is_never_a_success(self):
        cfg, job, _ = self.make_job()
        with patch.object(run, "call_chat_with_image", side_effect=RuntimeError("offline fixture")):
            record = run._generate_one_caption(cfg, "step3_stego_generation", job, "image")
        self.assertFalse(record["verified"])
        self.assertEqual(len(record["attempts"]), 2)
        self.assertEqual(record["recovered_bits"], "")

    def test_sample_allocation_preserves_scene_total(self):
        counts = run._allocate_counts(5000, 97)
        self.assertEqual(sum(counts), 5000)
        self.assertEqual(max(counts) - min(counts), 1)

    def test_failed_caption_record_is_saved_and_run_is_incomplete(self):
        with tempfile.TemporaryDirectory() as directory:
            with open(os.path.join(directory, "secret_message.bin"), "wb") as stream:
                stream.write(b"\0" * 4)
            image = os.path.join(directory, "fixture.png")
            with open(image, "wb") as stream:
                stream.write(b"fixture")
            cfg = {"paths": {"outputs": directory}, "n_trials_per_scene": 1, "n_stego_per_trial": 1,
                   "n_cover_per_trial": 1, "n_embed_words": 1, "L_seg": 4, "seed": 42,
                   "scenes": {"scene": {"description": "desk"}}, "text_min_len": 1, "text_max_len": 30,
                   "prompt_templates": {}}
            trial = {"trial_id": "scene_0001", "ordered_seeds": ["mug"], "word_list": ["mug"], "image_path": image}
            session = {"session_seed": 7, "codebook": [{"word": "mug", "probability": 1.0}]}
            def failed_batch(_cfg, _model, jobs, *_args):
                return [dict(job["record"], caption="", verified=False, recovered_bits="", attempts=[]) for job in jobs]
            with patch.object(run, "create_session", return_value=session), patch.object(run, "_batch_generate", side_effect=failed_batch):
                with self.assertRaisesRegex(RuntimeError, "incomplete"):
                    run.run_step3(cfg, {"scene": [trial]})
            with open(os.path.join(directory, "step3_summary.json"), encoding="utf-8") as stream:
                self.assertFalse(json.load(stream)["complete"])
            with open(os.path.join(directory, "scene", "stego", "scene_0001_records.json"), encoding="utf-8") as stream:
                self.assertFalse(json.load(stream)[0]["verified"])

    def test_complete_offline_run_redistributes_after_an_image_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            with open(os.path.join(directory, "secret_message.bin"), "wb") as stream:
                stream.write(bytes(range(16)))
            image = os.path.join(directory, "fixture.png")
            with open(image, "wb") as stream:
                stream.write(b"fixture")
            cfg = {"paths": {"outputs": directory}, "n_trials_per_scene": 3, "n_stego_per_trial": 2,
                   "n_cover_per_trial": 2, "n_embed_words": 3, "L_seg": 4, "seed": 42,
                   "alpha": 2, "sigma": 2.5, "psk_env": "DYCO_TEST_PSK",
                   "scenes": {"scene": {"description": "desk"}}, "text_min_len": 1, "text_max_len": 30,
                   "caption_max_retries": 0, "prompt_templates": {},
                   "models": {"step3_stego_generation": {}, "step3_cover_generation": {}}}
            trials = [{"trial_id": f"scene_{index}", "ordered_seeds": ["mug"], "word_list": ["mug", "pen"],
                       "image_path": image} for index in range(2)]
            def accepted_batch(current_cfg, model, jobs, image_b64, _desc):
                records = []
                for job in jobs:
                    caption = " and ".join(job["record"]["selected_words"]) + " rest here " + job["record"]["anchor_sequence"]
                    with patch.object(run, "call_chat_with_image", return_value=caption):
                        records.append(run._generate_one_caption(current_cfg, model, job, image_b64))
                return records
            with patch.dict(os.environ, {"DYCO_TEST_PSK": "01" * 32}), \
                 patch.object(run, "_batch_generate", side_effect=accepted_batch):
                results, stego, cover = run.run_step3(cfg, {"scene": trials})
            self.assertEqual((len(stego), len(cover)), (6, 6))
            self.assertEqual(len(results["scene"]), 2)
            for trial in results["scene"]:
                with open(trial["stego_records_path"], encoding="utf-8") as stream:
                    records = json.load(stream)
                self.assertEqual(len(records), 3)
                self.assertTrue(all(r["verified"] and r["recovered_bits"] == r["payload_bits"] for r in records))
            with open(os.path.join(directory, "step3_summary.json"), encoding="utf-8") as stream:
                self.assertTrue(json.load(stream)["complete"])
            report = evaluate_capacity(directory)
            overall = report["overall"]
            self.assertEqual(overall["n_sentences"], 6)
            self.assertEqual(overall["n_verified"], 6)
            self.assertEqual(overall["n_exactly_recovered"], 6)
            self.assertEqual(overall["total_payload_bits"], 6 * 3 * 4)
            self.assertEqual(overall["total_auxiliary_bits"], 6 * 3 * 4)
            self.assertEqual(overall["total_recovered_bits"], 6 * 3 * 4)
            self.assertEqual(overall["exact_recovery_rate"], 1.0)
            self.assertEqual(overall["total_words"], sum(len(caption.split()) for caption in stego))
            self.assertAlmostEqual(overall["EC_bpw"], 72 / overall["total_words"])


if __name__ == "__main__":
    unittest.main()
