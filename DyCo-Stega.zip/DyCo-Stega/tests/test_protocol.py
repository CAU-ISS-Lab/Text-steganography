import importlib.util
import os
from pathlib import Path
import random
import sys
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from protocol import (anchor_for_sample, create_session, derive_session_seed,
                      extract_anchor, load_psk)
from step2.codebook import (build_codebook, build_quantized_intervals,
                            encode_from_bitstream, decode_words, _seed_mask)
from run_all import experiment_summary


class Bits:
    def __init__(self, bits):
        self.bits, self.pos = bits, 0

    @property
    def remaining(self):
        return len(self.bits) - self.pos

    def read_bits(self, n):
        result = self.bits[self.pos:self.pos + n]
        self.pos += n
        return result


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.key = bytes(range(32))
        self.words = ["apple", "bowl", "fork", "knife", "mug"] + [f"word{i}" for i in range(19)]
        self.cfg = {"alpha": 24, "L_seg": 28, "sigma": 2.5, "n_embed_words": 5,
                    "n_image_keywords": 5, "psk_env": "DYCO_TEST_PSK"}

    def test_main_parameter_session_is_deterministic(self):
        with patch.dict(os.environ, {"DYCO_TEST_PSK": self.key.hex()}):
            anchor = anchor_for_sample("office_desk_0001:stego:0")
            a = create_session(self.cfg, self.words[:5], self.words, anchor)
            b = create_session(self.cfg, self.words[:5], self.words, anchor)
            self.assertEqual(a, b)
            self.assertEqual(extract_anchor("A caption. " + anchor), anchor)
            changed = derive_session_seed(self.key, self.words[:5], anchor + "!", 24, 28, 2.5)
            self.assertNotEqual(a["session_seed"], changed)
            with self.assertRaises(ValueError):
                extract_anchor("A caption. " + anchor + "✨")

    def test_psk_validation_does_not_echo_value(self):
        with patch.dict(os.environ, {"DYCO_TEST_PSK": "bad-secret-value"}):
            with self.assertRaises(ValueError) as result:
                load_psk(self.cfg)
            self.assertNotIn("bad-secret-value", str(result.exception))

    def test_exhaustive_small_codebook_recovers_all_messages(self):
        cb = build_codebook(["apple", "bowl", "fork", "mug"], 2.5, session_seed=42)
        for value in range(256):
            bits = format(value, "08b")
            encoded = encode_from_bitstream(cb, 8, 1, Bits(bits), 42)
            decoded = decode_words(cb, 8, encoded["selected_words"], encoded["side_information"], 42)
            self.assertEqual(decoded, bits)

    def test_main_boundaries_and_repeated_words(self):
        xi = derive_session_seed(self.key, self.words[:5], "✨🌿☀☕", 24, 28, 2.5)
        cb = build_codebook(self.words, 2.5, session_seed=xi)
        intervals = build_quantized_intervals(cb, 28)
        self.assertEqual(sum(iv["slots"] for iv in intervals), 1 << 28)
        for iv in intervals:
            if iv["slots"] == 0:
                continue
            values = [iv["start"], iv["end"] - 1, iv["start"], iv["start"], iv["end"] - 1]
            message = "".join(format(v, "028b") for v in values)
            record = encode_from_bitstream(cb, 28, 5, Bits(message), xi)
            self.assertEqual(record["selected_words"], [iv["word"]] * 5)
            self.assertEqual(len(record["side_information"]), 140)
            self.assertEqual(decode_words(cb, 28, record["selected_words"], record["side_information"], xi), message)

    def test_rejects_out_of_interval_offset_and_truncated_side_info(self):
        cb = build_codebook(["apple", "bowl"], 2.5, session_seed=7)
        iv = build_quantized_intervals(cb, 8)[0]
        invalid = format(iv["slots"] ^ _seed_mask(7, 8), "08b")
        with self.assertRaises(ValueError):
            decode_words(cb, 8, [iv["word"]], invalid, 7)
        with self.assertRaises(ValueError):
            decode_words(cb, 8, [iv["word"]], "01", 7)
        reader = Bits("01")
        with self.assertRaises(ValueError):
            encode_from_bitstream(cb, 8, 1, reader, 7)
        self.assertEqual(reader.pos, 0)

    def test_hmac_order_preserves_word_probability(self):
        a = build_codebook(self.words, 2.5, session_seed=11)
        b = build_codebook(self.words, 2.5, session_seed=12)
        self.assertNotEqual([x["word"] for x in a], [x["word"] for x in b])
        self.assertEqual({x["word"]: x["probability"] for x in a},
                         {x["word"]: x["probability"] for x in b})

    def test_receiver_reconstructs_without_sender_codebook_or_selected_words(self):
        from decode import recover_caption
        cfg = dict(self.cfg, text_min_len=5, text_max_len=30,
                   paths={"dictionary": "fixture.csv"})
        words = ["apple", "bowl", "fork", "knife", "mug", "lamp", "desk", "brush",
                 "comb", "mirror", "soap", "towel", "cup", "plate", "lemon", "banana",
                 "pan", "spoon", "kettle", "bread", "mouse", "pen", "laptop", "book"]
        fake_scoring = types.ModuleType("step2.scoring")
        fake_scoring.build_semantic_pool = lambda seeds, path, size: (words, list(range(24, 0, -1)))
        with patch.dict(os.environ, {"DYCO_TEST_PSK": self.key.hex()}):
            session = create_session(cfg, words[:5], words, anchor_for_sample("test:0"))
            payload = "0" * 140
            record = encode_from_bitstream(session["codebook"], 28, 5, Bits(payload), session["session_seed"])
            caption = "Here are " + ", ".join(record["selected_words"]) + ". " + session["anchor_sequence"]
            with patch.dict(sys.modules, {"step2.scoring": fake_scoring}):
                recovered = recover_caption(cfg, words[:5], caption, record["side_information"])
            self.assertEqual(recovered, payload)

    def test_main_experiment_has_15000_captions_per_class(self):
        cfg = dict(self.cfg, seed=42, n_trials_per_scene=100,
                   n_stego_per_trial=50, n_cover_per_trial=50,
                   text_min_len=12, text_max_len=28, max_retries=3,
                   scenes={"office": {}, "kitchen": {}, "bathroom": {}}, models={})
        summary = experiment_summary(cfg)
        self.assertEqual(summary["target_stego"], 15000)
        self.assertEqual(summary["target_cover"], 15000)


if __name__ == "__main__":
    unittest.main()
