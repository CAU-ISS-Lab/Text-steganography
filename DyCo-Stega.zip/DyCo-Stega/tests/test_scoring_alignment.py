import csv
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from step2 import scoring


class SemanticPoolTests(unittest.TestCase):
    def pool(self, rows, seeds, size):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "dict.csv")
            with open(path, "w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=["Word", "Frequency", "Definition", "Synonyms", "Example"])
                writer.writeheader()
                writer.writerows(rows)
            with patch.object(scoring, "_get_lemma", side_effect=lambda word: word.lower()), \
                 patch.object(scoring, "_get_stopwords", return_value=set()), \
                 patch.object(scoring, "_extract_lemma_set", side_effect=lambda text: set(str(text).split())):
                return scoring.build_semantic_pool(seeds, path, size)

    def test_forward_fields_use_precedence_not_sum(self):
        rows = [
            {"Word": "seed", "Frequency": 1, "Synonyms": "alpha", "Definition": "alpha", "Example": "alpha"},
            {"Word": "alpha", "Frequency": 10},
            {"Word": "seedling", "Frequency": 1, "Definition": "seed"},
        ]
        words, _ = self.pool(rows, ["seed"], 2)
        self.assertEqual(words, ["seed", "seedling"])

    def test_missing_seed_is_kept_with_zero_frequency(self):
        words, frequencies = self.pool([], ["missing"], 1)
        self.assertEqual(words, ["missing"])
        self.assertEqual(frequencies, [0.0])

    def test_selection_does_not_round_scores_into_a_false_tie(self):
        rows = [
            {"Word": "seed", "Frequency": 1, "Synonyms": "alpha zeta"},
            {"Word": "alpha", "Frequency": 1},
            {"Word": "zeta", "Frequency": 1.000001},
        ]
        words, _ = self.pool(rows, ["seed"], 2)
        self.assertEqual(words, ["seed", "zeta"])

    def test_fixed_alpha_rejects_a_short_pool(self):
        with self.assertRaisesRegex(ValueError, "required alpha=2"):
            self.pool([], ["missing"], 2)


if __name__ == "__main__":
    unittest.main()
