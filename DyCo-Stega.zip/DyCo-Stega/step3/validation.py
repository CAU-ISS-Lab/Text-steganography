import re
from collections import Counter, defaultdict

from protocol import extract_anchor


_TOKEN = re.compile(r"[A-Za-z]+(?:['’][A-Za-z]+)?")


def _plural_forms(word):
    forms = {word, word + "s"}
    if word.endswith(("s", "x", "z", "ch", "sh")):
        forms.add(word + "es")
    if len(word) > 1 and word.endswith("y") and word[-2] not in "aeiou":
        forms.add(word[:-1] + "ies")
    return forms


def extract_codewords(caption, all_words):

    canonical = {word.lower() for word in all_words}
    aliases = defaultdict(set)
    for word in canonical:
        for form in _plural_forms(word):
            aliases[form].add(word)
    words = []
    for match in _TOKEN.finditer(caption):
        surface = match.group().lower()
        if surface.endswith(("'s", "’s")):
            surface = surface[:-2]
        matches = aliases.get(surface, set())
        if len(matches) > 1:
            raise ValueError(f"Ambiguous codeword form {surface!r}: {sorted(matches)}")
        if matches:
            words.append(next(iter(matches)))
    return words


def verify_caption(caption, selected_words, all_words, anchor_sequence, min_len, max_len):

    errors = []
    if not isinstance(caption, str) or not caption.strip():
        return ["Caption is empty"]
    expected = [word.lower() for word in selected_words]
    try:
        observed = extract_codewords(caption, all_words)
    except ValueError as exc:
        observed = None
        errors.append(str(exc))
    if observed is not None and observed != expected:
        missing = Counter(expected) - Counter(observed)
        extra = Counter(observed) - Counter(expected)
        if missing:
            errors.append(f"Missing required codeword occurrences: {dict(missing)}")
        if extra:
            errors.append(f"Forbidden or redundant codeword occurrences: {dict(extra)}")
        if not missing and not extra:
            errors.append(f"Codeword order must be {expected}; observed {observed}")
    try:
        observed_anchor = extract_anchor(caption)
    except ValueError:
        observed_anchor = None
    if not anchor_sequence or caption.count(anchor_sequence) != 1 or observed_anchor != anchor_sequence:
        errors.append("The exact public anchor sequence must appear once, in its specified order")
    word_count = len(caption.split())
    if not min_len <= word_count <= max_len:
        errors.append(f"Length is {word_count} whitespace-delimited words; expected {min_len}–{max_len}")
    prose = caption.replace(anchor_sequence, "") if anchor_sequence else caption
    if "\n" in caption or re.search(r"[.!?]\s+(?=\S)", prose):
        errors.append("Caption must contain one sentence on one line")
    return errors
