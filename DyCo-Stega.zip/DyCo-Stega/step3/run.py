import base64
import concurrent.futures
import json
import os
import random
from collections import Counter

from protocol import anchor_for_sample, create_session
from step2.codebook import (
    FileBitstream,
    decode_words,
    encode_from_bitstream,
    get_all_codebook_words,
    sample_words_from_codebook,
)
from step3.validation import extract_codewords, verify_caption
from utils import stable_hash


def call_chat_with_image(*args, **kwargs):
    from utils.api import call_chat_with_image as api_call
    return api_call(*args, **kwargs)


def _progress(iterable, **kwargs):
    try:
        from tqdm import tqdm
    except ImportError:
        return iterable
    return tqdm(iterable, **kwargs)


def _fill_template(template, values):
    for key, value in values.items():
        template = template.replace("{" + key + "}", str(value))
    return template


def _build_stego_prompt(cfg, scene_desc, selected_words, all_codebook_words, anchor_sequence):
    counts = Counter(word.lower() for word in selected_words)
    required = ", ".join(f"{word} (exactly {count} occurrence(s))" for word, count in counts.items())
    forbidden = [word for word in all_codebook_words if word.lower() not in counts]
    template = cfg["prompt_templates"].get("stego_embedding", "") or (
        "Write one natural English photo caption for the image. Scene: {scene_description}.\n"
        "Use codewords in exactly this order, preserving repeated occurrences: {required_sequence}.\n"
        "Required counts: {required_words}. Forbidden codewords: {forbidden_words}.\n"
        "Include this exact public anchor once: {anchor_sequence}.\n"
        "Length: {min_len}–{max_len} whitespace-delimited words. Output only the caption."
    )
    return _fill_template(template, {
        "scene_description": scene_desc,
        "required_words": required,
        "required_sequence": json.dumps(selected_words, ensure_ascii=False),
        "raw_required_words": ", ".join(selected_words),
        "forbidden_words": ", ".join(forbidden),
        "anchor_sequence": anchor_sequence,
        "min_len": cfg["text_min_len"],
        "max_len": cfg["text_max_len"],
    })


def _build_feedback_prompt(cfg, caption, job, errors):
    template = cfg["prompt_templates"].get("caption_feedback", "") or (
        "Give concise edit instructions for this caption: {current_caption}\n"
        "Required ordered codewords: {required_sequence}\n"
        "Exact public anchor: {anchor_sequence}\nSemantic pool: {semantic_pool}\n"
        "Validation errors: {validation_errors}\n"
        "Preserve repeated codewords with their exact counts. Remove other pool words. "
        "Output only edit instructions, not a rewritten caption."
    )
    return _fill_template(template, {
        "current_caption": caption,
        "required_sequence": json.dumps(job["record"]["selected_words"], ensure_ascii=False),
        "anchor_sequence": job["record"]["anchor_sequence"],
        "semantic_pool": json.dumps(job["all_words"], ensure_ascii=False),
        "validation_errors": "; ".join(errors),
    })


def _generate_one_caption(cfg, model_key, job, image_b64):
    record = dict(job["record"])
    record.update(caption="", recovered_bits="", verified=False, attempts=[])
    prompt = job["prompt"]
    max_revisions = int(cfg.get("caption_max_retries", cfg.get("max_retries", 3)))
    feedback_key = "step3_caption_feedback" if "step3_caption_feedback" in cfg["models"] else model_key

    for attempt in range(max_revisions + 1):
        attempt_record = {"attempt": attempt + 1}
        try:
            raw = call_chat_with_image(cfg, model_key, prompt, image_b64=image_b64, require_non_empty=True)
            caption = (raw or "").strip().strip('"').strip("'").strip()
            record["caption"] = caption
            errors = verify_caption(
                caption, record["selected_words"], job["all_words"], record["anchor_sequence"],
                cfg["text_min_len"], cfg["text_max_len"],
            )
            if not errors:
                observed = extract_codewords(caption, job["all_words"])
                record["extracted_words"] = observed
                if record["kind"] == "stego":
                    recovered = decode_words(
                        job["session"]["codebook"], cfg["L_seg"], observed,
                        record["side_information"], job["session"]["session_seed"],
                    )
                    record["recovered_bits"] = recovered
                    if recovered != record["payload_bits"]:
                        errors.append("Decoded payload does not equal the source message bits")
            attempt_record.update(caption=caption, errors=errors)
        except Exception as exc:
            errors = [f"{type(exc).__name__}: {exc}"]
            attempt_record.update(errors=errors, api_or_decode_error=True)

        record["attempts"].append(attempt_record)
        if not errors:
            record["verified"] = True
            record.pop("errors", None)
            return record
        record["errors"] = errors
        if attempt == max_revisions:
            break

        if record["caption"]:
            feedback_prompt = _build_feedback_prompt(cfg, record["caption"], job, errors)
            try:
                instruction = call_chat_with_image(
                    cfg, feedback_key, feedback_prompt, image_b64=image_b64, require_non_empty=True,
                )
                attempt_record["feedback"] = instruction
            except Exception as exc:
                attempt_record["feedback_error"] = f"{type(exc).__name__}: {exc}"
                instruction = "; ".join(errors)
            prompt = (
                job["prompt"] + "\nRevise the following rejected caption with minimal edits:\n"
                + record["caption"] + "\nEdit instructions:\n" + instruction
                + "\nOutput only the revised caption."
            )
    return record


def _batch_generate(cfg, model_key, jobs, image_b64, desc):
    if not jobs:
        return []
    provider = cfg["models"][model_key]["provider"]
    max_workers = int(cfg["providers"][provider].get("max_concurrent", 10))
    records = [None] * len(jobs)
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(_generate_one_caption, cfg, model_key, job, image_b64): i
            for i, job in enumerate(jobs)
        }
        for future in _progress(concurrent.futures.as_completed(future_map), total=len(jobs), desc=desc, leave=False):
            index = future_map[future]
            try:
                records[index] = future.result()
            except Exception as exc:
                records[index] = dict(jobs[index]["record"], caption="", recovered_bits="", verified=False,
                                      errors=[f"{type(exc).__name__}: {exc}"], attempts=[])
    return records


def _write_json(path, data):
    with open(path, "w", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False)


def _write_lines(path, records):
    with open(path, "w", encoding="utf-8") as stream:
        for record in records:
            stream.write((record["caption"] if record["verified"] else "") + "\n")


def _allocate_counts(total, trial_count):
    quotient, remainder = divmod(total, trial_count)
    return [quotient + int(index < remainder) for index in range(trial_count)]


def run_step3(cfg, step2_results):
    outputs_root = cfg["paths"]["outputs"]
    secret_path = os.path.join(outputs_root, "secret_message.bin")
    if not os.path.isfile(secret_path):
        raise FileNotFoundError(f"Secret message file missing: {secret_path}. Run generate_secret.py first.")
    empty_scenes = [scene for scene in cfg["scenes"] if not step2_results.get(scene)]
    if empty_scenes:
        raise RuntimeError("No successful image trials for scenes: " + ", ".join(empty_scenes))
    bitstream = FileBitstream(secret_path)
    targets = {"stego": int(cfg["n_trials_per_scene"]) * int(cfg["n_stego_per_trial"]),
               "cover": int(cfg["n_trials_per_scene"]) * int(cfg["n_cover_per_trial"])}
    n_embed = int(cfg["n_embed_words"])
    needed = len(cfg["scenes"]) * targets["stego"] * n_embed * cfg["L_seg"]
    if bitstream.remaining < needed:
        raise ValueError(f"Secret message has {bitstream.remaining} bits; this run needs {needed}")

    results, global_stego_lines, global_cover_lines = {}, [], []
    failures = []
    for scene_name in cfg["scenes"]:
        trials = sorted(step2_results[scene_name], key=lambda trial: trial["trial_id"])
        allocation = {kind: _allocate_counts(total, len(trials)) for kind, total in targets.items()}
        scene_dir = os.path.join(outputs_root, scene_name)
        os.makedirs(scene_dir, exist_ok=True)
        scene_results, scene_records = [], {"stego": [], "cover": []}
        metadata = []
        for trial_index, trial in enumerate(trials):
            tid = trial["trial_id"]
            with open(trial["image_path"], "rb") as stream:
                image_b64 = base64.b64encode(stream.read()).decode("ascii")
            extended = dict(trial)
            for kind in ("stego", "cover"):
                count = allocation[kind][trial_index]
                kind_dir = os.path.join(scene_dir, kind)
                os.makedirs(kind_dir, exist_ok=True)
                jobs = []
                for index in range(count):
                    sample_id = f"{tid}:{kind}:{index}"
                    anchor = anchor_for_sample(sample_id)
                    session = create_session(cfg, trial["ordered_seeds"], trial["word_list"], anchor)
                    if kind == "stego":
                        encoded = encode_from_bitstream(
                            session["codebook"], cfg["L_seg"], n_embed, bitstream, session["session_seed"],
                        )
                    else:
                        cover_rng = random.Random(cfg.get("seed", 42) + stable_hash(sample_id))
                        encoded = {"selected_words": sample_words_from_codebook(session["codebook"], n_embed, cover_rng),
                                   "payload_bits": "", "side_information": ""}
                    record = dict(encoded, sample_id=sample_id, kind=kind, anchor_sequence=anchor)
                    all_words = get_all_codebook_words(session["codebook"])
                    jobs.append({"record": record, "session": session, "all_words": all_words,
                                 "prompt": _build_stego_prompt(cfg, cfg["scenes"][scene_name]["description"],
                                                               record["selected_words"], all_words, anchor)})
                records = _batch_generate(cfg, f"step3_{kind}_generation", jobs, image_b64, f"{tid} {kind}")
                text_path = os.path.join(kind_dir, f"{tid}.txt")
                words_path = os.path.join(kind_dir, f"{tid}_words.json")
                records_path = os.path.join(kind_dir, f"{tid}_records.json")
                _write_lines(text_path, records)
                _write_json(words_path, [record["selected_words"] for record in records])
                _write_json(records_path, records)
                extended.update({f"{kind}_path": text_path, f"{kind}_words_path": words_path,
                                 f"{kind}_records_path": records_path,
                                 f"{kind}_words": [record["selected_words"] for record in records]})
                scene_records[kind].extend(records)
                valid = sum(record["verified"] for record in records)
                print(f"  [{tid}] {kind}: {valid}/{count} verified")
                if valid != count:
                    failures.append(f"{tid} {kind}: {valid}/{count} verified captions")
            scene_results.append(extended)
            metadata.append({key: extended[key] for key in (
                "trial_id", "keywords", "ordered_seeds", "word_list", "image_path", "codebook_path",
                "stego_path", "cover_path", "stego_words_path", "cover_words_path",
                "stego_records_path", "cover_records_path",
            ) if key in extended})
            _write_json(os.path.join(scene_dir, "step3_meta.json"), metadata)
        for kind in ("stego", "cover"):
            _write_lines(os.path.join(scene_dir, f"{kind}.txt"), scene_records[kind])
        global_stego_lines.extend(record["caption"] for record in scene_records["stego"] if record["verified"])
        global_cover_lines.extend(record["caption"] for record in scene_records["cover"] if record["verified"])
        results[scene_name] = scene_results

    summary = {"complete": not failures, "expected_stego": len(cfg["scenes"]) * targets["stego"],
               "expected_cover": len(cfg["scenes"]) * targets["cover"],
               "verified_stego": len(global_stego_lines), "verified_cover": len(global_cover_lines), "failures": failures}
    _write_json(os.path.join(outputs_root, "step3_summary.json"), summary)
    if failures:
        raise RuntimeError("DyCo-Stega generation is incomplete; inspect step3_summary.json: " + "; ".join(failures))
    return results, global_stego_lines, global_cover_lines
