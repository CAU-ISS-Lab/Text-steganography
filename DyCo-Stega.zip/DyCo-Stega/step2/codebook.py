import json
import math
import os
import random as stdlib_random
import hashlib
import hmac
from bisect import bisect_right


def build_codebook(word_list, sigma, rng=None, session_seed=None):
    if not math.isfinite(sigma) or sigma <= 0:
        raise ValueError("sigma must be finite and positive")
    if len(set(word_list)) != len(word_list):
        raise ValueError("Codebook words must be distinct")
    N = len(word_list)
    if N == 0:
        return []

    weights = []
    for j in range(N):
        r = math.exp(-((j) ** 2) / (2.0 * sigma ** 2))
        weights.append(r)

    total = sum(weights)
    if total == 0:
        weights = [1.0] * N
        total = float(N)

    codebook = []
    for i, word in enumerate(word_list):
        codebook.append({
            "word": word,
            "probability": weights[i] / total,
        })

    if session_seed is not None:
        key = int(session_seed).to_bytes(32, "big")
        order = sorted(range(N), key=lambda j: (
            hmac.new(key, (j + 1).to_bytes(8, "big"), hashlib.sha256).digest(), j))
        codebook = [codebook[j] for j in order]
    elif rng is not None:
        rng.shuffle(codebook)
    else:
        raise ValueError("A session seed or an explicit legacy RNG is required")
    return codebook


def format_codebook(codebook):
    lines = []
    lines.append(f"{'Word':<20} {'Probability':>12}")
    lines.append("-" * 34)
    for entry in codebook:
        lines.append(f"{entry['word']:<20} {entry['probability']:>12.6f}")
    return "\n".join(lines)


def save_codebook_json(codebook, L_seg, keywords, sigma, path):
    intervals = build_quantized_intervals(codebook, L_seg)

    data = {
        "L_seg": L_seg,
        "total": 1 << L_seg,
        "keywords": keywords,
        "sigma": sigma,
        "codebook": codebook,
        "quantized_intervals": intervals,
    }

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    return path


def load_codebook_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_all_codebook_words(codebook):
    return [entry["word"] for entry in codebook]


def build_quantized_intervals(codebook, L_seg):
    if not isinstance(L_seg, int) or not 1 <= L_seg <= 87:
        raise ValueError("L_seg must be an integer from 1 to 87")
    if not codebook or len({e["word"] for e in codebook}) != len(codebook):
        raise ValueError("A nonempty, unique-word codebook is required")
    probs = [entry["probability"] for entry in codebook]
    if any(not math.isfinite(p) or p < 0 for p in probs):
        raise ValueError("Invalid codebook probability")
    if not math.isclose(sum(probs), 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise ValueError("Codebook probabilities must sum to one")
    total = 1 << L_seg
    N = len(codebook)

    slots = []
    for entry in codebook:
        s = int(math.floor(entry["probability"] * total))
        slots.append(s)

    allocated = sum(slots)
    deficit = total - allocated

    if not 0 <= deficit < N:
        raise ValueError("Probability quantization exceeds floating-point precision")

    for i in range(deficit):
        slots[i] += 1

    assert sum(slots) == total, f"Slot sum {sum(slots)} != {total}"

    intervals = []
    cursor = 0
    for i, entry in enumerate(codebook):
        intervals.append({
            "word": entry["word"],
            "start": cursor,
            "end": cursor + slots[i],
            "slots": slots[i],
        })
        cursor += slots[i]

    assert cursor == total
    return intervals


def _lookup_interval(intervals, idx):
    if not 0 <= idx < intervals[-1]["end"]:
        raise ValueError("Message index is outside the codebook")
    starts = [iv["start"] for iv in intervals]
    pos = bisect_right(starts, idx) - 1
    return intervals[pos]["word"]


class BitstreamRNG:

    def __init__(self, seed):
        self._rng = stdlib_random.Random(seed)
        self._buffer = ""
        self._consumed = 0

    def read_bits(self, n):
        while len(self._buffer) < n:
            chunk = "".join(
                format(self._rng.getrandbits(8), "08b")
                for _ in range(16)
            )
            self._buffer += chunk

        bits = self._buffer[:n]
        self._buffer = self._buffer[n:]
        self._consumed += n
        return bits

    def read_int(self, L):
        return int(self.read_bits(L), 2)

    @property
    def consumed(self):
        return self._consumed

    def __repr__(self):
        return (f"BitstreamRNG(consumed={self._consumed}, "
                f"buffer_len={len(self._buffer)})")


class FileBitstream:

    def __init__(self, filepath):
        with open(filepath, "rb") as f:
            raw = f.read()
        self._bits = "".join(format(b, "08b") for b in raw)
        self._pos = 0
        self._total = len(self._bits)

    def read_bits(self, n):
        if self._pos + n > self._total:
            raise RuntimeError(
                f"Bitstream exhausted: pos={self._pos}, "
                f"need={n}, total={self._total}"
            )
        bits = self._bits[self._pos:self._pos + n]
        self._pos += n
        return bits

    def read_int(self, L):
        return int(self.read_bits(L), 2)

    @property
    def consumed(self):
        return self._pos

    @property
    def remaining(self):
        return self._total - self._pos

    def __repr__(self):
        return (f"FileBitstream(consumed={self._pos}, "
                f"remaining={self.remaining}, "
                f"total={self._total})")


def select_words_from_bitstream(codebook, L_seg, n_words, bs):
    intervals = build_quantized_intervals(codebook, L_seg)

    words = []
    for _ in range(n_words):
        idx = bs.read_int(L_seg)
        word = _lookup_interval(intervals, idx)
        words.append(word)

    return words


def _seed_mask(session_seed, b):

    if session_seed < 0:
        raise ValueError("The session seed must be nonnegative")
    bits = format(session_seed, "b")
    return int(bits[:b] if len(bits) >= b else bits.zfill(b), 2)


def encode_from_bitstream(codebook, L_seg, n_words, bs, session_seed):
    if n_words <= 0:
        raise ValueError("n_words must be positive")
    intervals = build_quantized_intervals(codebook, L_seg)
    starts = [iv["start"] for iv in intervals]
    selected, payload, side = [], [], []
    mask = _seed_mask(session_seed, L_seg)
    if getattr(bs, "remaining", n_words * L_seg) < n_words * L_seg:
        raise ValueError("Insufficient message bits for a complete caption")
    for _ in range(n_words):
        bits = bs.read_bits(L_seg)
        if len(bits) != L_seg or any(c not in "01" for c in bits):
            raise ValueError("The bitstream returned an invalid message block")
        idx = int(bits, 2)
        iv = intervals[bisect_right(starts, idx) - 1]
        selected.append(iv["word"])
        payload.append(bits)
        side.append(format((idx - iv["start"]) ^ mask, f"0{L_seg}b"))
    return {"selected_words": selected, "payload_bits": "".join(payload),
            "side_information": "".join(side)}


def decode_words(codebook, L_seg, words, side_information, session_seed):
    intervals = {iv["word"]: iv for iv in build_quantized_intervals(codebook, L_seg)}
    if not words or len(side_information) != len(words) * L_seg:
        raise ValueError("Side information must contain one b-bit block per codeword")
    if any(c not in "01" for c in side_information):
        raise ValueError("Side information must be binary")
    mask = _seed_mask(session_seed, L_seg)
    result = []
    for i, word in enumerate(words):
        if word not in intervals:
            raise ValueError(f"Unknown codeword: {word}")
        iv = intervals[word]
        offset = int(side_information[i * L_seg:(i + 1) * L_seg], 2) ^ mask
        if not 0 <= offset < iv["slots"]:
            raise ValueError("Recovered offset is outside the selected interval")
        result.append(format(iv["start"] + offset, f"0{L_seg}b"))
    return "".join(result)


def sample_words_from_codebook(codebook, n_words, rng):
    words_list = [e["word"] for e in codebook]
    probs = [e["probability"] for e in codebook]

    cumulative = []
    acc = 0.0
    for p in probs:
        acc += p
        cumulative.append(acc)
    cumulative[-1] = 1.0

    selected = []
    for _ in range(n_words):
        r = rng.random()
        idx = bisect_right(cumulative, r)
        idx = min(idx, len(words_list) - 1)
        selected.append(words_list[idx])

    return selected


def sample_words_by_probability(codebook, n_words, rng):
    return sample_words_from_codebook(codebook, n_words, rng)
