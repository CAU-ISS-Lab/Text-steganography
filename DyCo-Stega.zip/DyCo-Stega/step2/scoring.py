import math
import os
import pandas as pd
from collections import defaultdict
from functools import lru_cache


@lru_cache(maxsize=1)
def _nlp_resources():
    import nltk
    from nltk.stem import WordNetLemmatizer
    from nltk.corpus import stopwords
    nltk.data.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "nltk_data"))
    return nltk, WordNetLemmatizer(), set(stopwords.words("english"))


def _get_stopwords():
    return _nlp_resources()[2]


_WEIGHTS = {
    "REV_DEF": 30.0,
    "FWD_SYN": 15.0,
    "FWD_DEF": 12.0,
    "FWD_EX":  2.5,
    "MORPH":   4.0,
}
def _get_lemma(w: str) -> str:
    if not w:
        return ""
    clean = "".join(c for c in w if c.isalpha()).lower().strip()
    return _nlp_resources()[1].lemmatize(clean, pos='n')
def _extract_lemma_set(text) -> set:
    if not text or pd.isna(text):
        return set()
    tokens = _nlp_resources()[0].word_tokenize(str(text))
    valid = {_get_lemma(t) for t in tokens}
    return {t for t in valid if t and len(t) > 1 and t not in _get_stopwords()}
def build_semantic_pool(seeds: list, csv_path: str, N: int) -> tuple:
    seeds = sorted(set(s.strip().lower() for s in seeds))
    m = len(seeds)
    if N < m:
        raise ValueError(f"Semantic pool size {N} is smaller than the {m} distinct seeds")
    exact_seeds = set(s.strip().lower() for s in seeds)
    seed_lemma_map = defaultdict(list)
    for s in seeds:
        s_lower = s.strip().lower()
        s_lemma = _get_lemma(s_lower)
        seed_lemma_map[s_lemma].append(s_lower)
    target_seed_lemmas = set(seed_lemma_map.keys())
    database = {}
    df = pd.read_csv(csv_path).fillna("")
    for _, row in df.iterrows():
        raw_w = str(row['Word']).strip()
        word_lower = raw_w.lower()
        if not word_lower or len(word_lower) < 2:
            continue
        if word_lower not in exact_seeds and word_lower in _get_stopwords():
            continue
        word_lemma = _get_lemma(word_lower)
        if word_lower in exact_seeds:
            db_key = word_lower
            display_name = raw_w
        else:
            db_key = word_lemma
            display_name = word_lemma
        freq = float(row.get('Frequency', 0))
        if db_key not in database:
            database[db_key] = {
                "display": display_name,
                "lemma": word_lemma,
                "freq": freq,
                "def": set(), "syn": set(), "ex": set(),
            }
        else:
            database[db_key]["freq"] = max(database[db_key]["freq"], freq)
        entry = database[db_key]
        entry["def"] |= _extract_lemma_set(row.get('Definition', ''))
        entry["syn"] |= _extract_lemma_set(row.get('Synonyms', ''))
        entry["ex"]  |= _extract_lemma_set(row.get('Example', ''))
    for s_lower in exact_seeds:
        if s_lower not in database:
            s_lemma = _get_lemma(s_lower)
            database[s_lower] = {
                "display": s_lower,
                "lemma": s_lemma,
                "freq": 0.0,
                "def": set(), "syn": set(), "ex": set(),
            }
    fwd_links = defaultdict(dict)
    for s_key in sorted(exact_seeds):
        if s_key in database:
            info = database[s_key]
            s_disp = info['display']
            for field, kind in (("syn", "SYN"), ("def", "DEF"), ("ex", "EX")):
                for w in info[field]:
                    fwd_links[w].setdefault(s_disp.lower(), kind)
    results = []
    for key, info in database.items():
        w_lemma = info['lemma']
        if key in exact_seeds:
            results.append({
                "word": info['display'],
                "is_seed": True,
                "freq": info['freq'],
            })
            continue
        per_seed_data = defaultdict(lambda: {"score": 0.0, "types": set()})
        matches = info["def"] & target_seed_lemmas
        if matches:
            def_decay = 1.0 / math.log2(len(info["def"]) + 4)
            for m_lemma in sorted(matches):
                for orig_seed in seed_lemma_map[m_lemma]:
                    per_seed_data[orig_seed]["score"] += _WEIGHTS["REV_DEF"] * def_decay
                    per_seed_data[orig_seed]["types"].add("REV_IN_DEF")
        if w_lemma in fwd_links:
            for s_seed_lower, type_ in sorted(fwd_links[w_lemma].items()):
                if type_ == "SYN":
                    per_seed_data[s_seed_lower]["score"] += _WEIGHTS["FWD_SYN"]
                elif type_ == "DEF":
                    per_seed_data[s_seed_lower]["score"] += _WEIGHTS["FWD_DEF"]
                elif type_ == "EX":
                    per_seed_data[s_seed_lower]["score"] += _WEIGHTS["FWD_EX"]
                per_seed_data[s_seed_lower]["types"].add(f"FWD_{type_}")
        for s_raw in sorted(exact_seeds):
            seed_lemma = _get_lemma(s_raw)
            if w_lemma.startswith(seed_lemma) and len(w_lemma) > len(seed_lemma):
                per_seed_data[s_raw]["score"] += _WEIGHTS["MORPH"]
                per_seed_data[s_raw]["types"].add("MORPH")
        if not per_seed_data:
            continue
        aggregated_score = 0.0
        for s_lower, data in sorted(per_seed_data.items()):
            types = data["types"]
            has_rev = "REV_IN_DEF" in types
            has_other = any(t for t in types if t != "REV_IN_DEF")
            mu = 2.0 if (has_rev and has_other) else 1.0
            aggregated_score += data["score"] * mu
        n_links = len(per_seed_data)
        gamma = 1.0 + 1.5 * (n_links - 1)
        phi = 1.0 + 0.8 * math.log10(info['freq'] + 2)
        final_score = aggregated_score * gamma * phi
        results.append({
            "word": info['display'],
            "score": final_score,
            "is_seed": False,
            "freq": info['freq'],
        })
    top_candidates = sorted(
        [x for x in results if not x["is_seed"]],
        key=lambda x: (-x["score"], x["word"].lower()),
    )[:N - m]
    seed_tier = sorted(
        [x for x in results if x["is_seed"]],
        key=lambda x: (-x["freq"], x["word"].lower())
    )
    expand_tier = sorted(
        top_candidates,
        key=lambda x: (-x["freq"], x["word"].lower())
    )
    final_list = seed_tier + expand_tier
    actual_n = len(final_list)
    if actual_n < N:
        raise ValueError(f"Dictionary only yields {actual_n} semantic words (required alpha={N})")
    word_list = [item['word'].lower() for item in final_list]
    freq_list = [item['freq'] for item in final_list]
    return word_list, freq_list
