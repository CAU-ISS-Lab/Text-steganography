import os
import json
from tqdm import tqdm
from protocol import anchor_for_sample, create_session
from step2.scoring import build_semantic_pool
from step2.codebook import format_codebook, save_codebook_json


def run_step2(cfg: dict, step1_results: dict) -> dict:
    csv_path = cfg["paths"]["dictionary"]
    N = cfg["semantic_pool_size"]
    sigma = cfg["sigma"]
    L_seg = cfg["L_seg"]
    outputs_root = cfg["paths"]["outputs"]

    results = {}

    for scene_name, trials in step1_results.items():
        print(f"\n{'='*60}", flush=True)
        print(f"Step2 | {scene_name}  ({len(trials)} trials)", flush=True)
        print(f"{'='*60}", flush=True)

        codebook_dir = os.path.join(outputs_root, scene_name, "codebook")
        os.makedirs(codebook_dir, exist_ok=True)

        scene_results = []

        for trial in tqdm(trials, desc=f"  {scene_name} codebook", leave=True):
            tid = trial["trial_id"]
            keywords = trial["keywords"]

            word_list, freq_list = build_semantic_pool(keywords, csv_path, N)

            ordered_seeds = word_list[:len(keywords)]
            anchor = anchor_for_sample(f"{tid}:stego:0")
            session = create_session(cfg, ordered_seeds, word_list, anchor)
            codebook = session["codebook"]

            cb_path = os.path.join(codebook_dir, f"{tid}.txt")
            with open(cb_path, "w", encoding="utf-8") as f:
                f.write(f"# Trial: {tid}\n")
                f.write(f"# Seeds: {keywords}\n")
                f.write(f"# N={len(word_list)}, sigma={sigma}\n\n")
                f.write(format_codebook(codebook))

            cb_json_path = os.path.join(codebook_dir, f"{tid}.json")
            save_codebook_json(codebook, L_seg, keywords, sigma, cb_json_path)

            trial_ext = dict(trial)
            trial_ext["word_list"] = word_list
            trial_ext["ordered_seeds"] = ordered_seeds
            trial_ext["anchor_sequence"] = anchor
            trial_ext["freq_list"] = freq_list
            trial_ext["codebook"] = codebook
            trial_ext["codebook_path"] = cb_path
            trial_ext["codebook_json_path"] = cb_json_path
            scene_results.append(trial_ext)

        results[scene_name] = scene_results
        print(f"  -> {scene_name}: {len(scene_results)} codebooks built",
              flush=True)

        meta = []
        for t in scene_results:
            meta.append({
                "trial_id": t["trial_id"],
                "keywords": t["keywords"],
                "image_path": t["image_path"],
                "word_list": t["word_list"],
                "ordered_seeds": t["ordered_seeds"],
                "codebook_path": t["codebook_path"],
                "codebook_json_path": t["codebook_json_path"],
            })
        meta_path = os.path.join(outputs_root, scene_name, "step2_meta.json")
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)

    return results
