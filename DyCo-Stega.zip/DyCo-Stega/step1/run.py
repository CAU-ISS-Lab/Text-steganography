import os
import json
import random
import re
import time
import concurrent.futures
from typing import Any, Dict, List, Tuple

import pandas as pd
from tqdm import tqdm

from utils import stable_hash
from utils.api import (
    call_image_generation,
    call_image_edit,
    call_chat_with_image,
    infer_mime_from_b64,
)


def _parse_extracted(raw_text: str) -> List[str]:

    raw = (raw_text or "").strip()

    def norm(x: Any) -> str:
        s = str(x).strip().lower().strip('"\'')

        s2 = "".join(c for c in s if c.isalpha())
        return s2

    try:
        obj = json.loads(raw)
        if isinstance(obj, list):
            out = [norm(v) for v in obj]
            out = [w for w in out if w]
            return out
    except Exception:
        pass


    chunks = re.findall(r"\[[\s\S]*?\]", raw)
    for c in reversed(chunks):
        try:
            obj = json.loads(c)
            if isinstance(obj, list):
                out = [norm(v) for v in obj]
                out = [w for w in out if w]
                return out
        except Exception:
            continue

    return []


def _match_keywords(target: List[str], extracted: List[str]) -> Tuple[bool, List[str], List[str]]:
    tset = set(w.lower().strip() for w in target)
    eset = set(w.lower().strip() for w in extracted)
    missing = sorted(tset - eset)
    extra = sorted(eset - tset)
    matched = (len(missing) == 0 and len(extra) == 0 and len(extracted) == len(target))
    return matched, missing, extra


def _degraded(prev_missing: List[str], prev_extra: List[str], missing: List[str], extra: List[str]) -> int:
    return int((len(missing) > len(prev_missing)) or (len(extra) > len(prev_extra)))


def _looks_truncated(raw: str) -> bool:

    s = (raw or "").strip()
    if not s:
        return True

    if s.startswith("[") and ("]" not in s):
        return True

    if s.count("[") > s.count("]"):
        return True

    if s.count("```") % 2 == 1:
        return True

    tail = s[-1]
    if tail in [",", '"', "\\"]:
        return True

    return False


def _extract_with_retry(
    cfg: Dict[str, Any],
    image_b64: str,
    mime: str,
    extract_prompt: str,
    tries: int = 8,
    base_sleep: float = 0.6,
) -> Tuple[List[str], str, int]:

    last_raw = ""
    last_list: List[str] = []

    for i in range(tries):
        raw = call_chat_with_image(
            cfg,
            "step1_image_extraction",
            extract_prompt,
            image_b64=image_b64,
            mime=mime,
        )
        last_raw = raw
        last_list = _parse_extracted(raw)

        if last_list:
            return last_list, last_raw, i + 1

        if _looks_truncated(raw):
            time.sleep(base_sleep * (1.0 + i))
        else:
            time.sleep(base_sleep * 0.35)           

    return last_list, last_raw, tries


def _ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)


def _write_json(path: str, obj: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def _save_xlsx(path: str, rows: List[Dict[str, Any]]) -> None:
    pd.DataFrame(rows).to_excel(path, index=False, engine="openpyxl")


def _build_gen_prompt(cfg: Dict[str, Any], scene_desc: str, items: List[str]) -> str:
    tpl = cfg["prompt_templates"].get("image_generation", "")
    return tpl.replace("{scene_description}", scene_desc).replace("{items_list}", json.dumps(items))


def _build_feedback_prompt(cfg: Dict[str, Any], items: List[str], extracted: List[str]) -> str:

    tpl = cfg["prompt_templates"].get("feedback", "")
    return tpl.replace("{items_list}", json.dumps(items)).replace("{extracted_list}", json.dumps(extracted))


def _run_single_trial(
    cfg: Dict[str, Any],
    scene_name: str,
    scene_info: Dict[str, Any],
    trial_idx: int,
    scene_dir: str,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    desc = scene_info["description"]
    pool = list(scene_info["keywords"])

    m = int(cfg["n_image_keywords"])
    max_rounds = int(cfg.get("max_retries", 5))

    trial_rng = random.Random(cfg.get("seed", 42) * 100000 + stable_hash(scene_name) + trial_idx)
    items = sorted(trial_rng.sample(pool, m))

    trial_id = f"{scene_name}_{trial_idx:04d}"
    pic_dir = os.path.join(scene_dir, "pic")
    _ensure_dir(pic_dir)

    extract_prompt = cfg["prompt_templates"]["image_extraction"]
    gen_prompt = _build_gen_prompt(cfg, desc, items)

    row: Dict[str, Any] = {"trial_id": trial_id, "target": json.dumps(items)}

    try:
        r0_path = os.path.join(pic_dir, f"{trial_id}_r0.png")
        _, current_b64 = call_image_generation(cfg, gen_prompt, r0_path)
        current_mime = infer_mime_from_b64(current_b64)

        extracted, raw_extract, used_tries = _extract_with_retry(
            cfg, current_b64, current_mime, extract_prompt, tries=8, base_sleep=0.6
        )
        matched, missing, extra = _match_keywords(items, extracted)

        row.update({
            "R0_image": os.path.basename(r0_path),
            "R0_extracted": json.dumps(extracted),
            "R0_missing": json.dumps(missing),
            "R0_extra": json.dumps(extra),
            "R0_matched": int(matched),
            "R0_extract_tries": used_tries,
        })
        if not extracted:
            row["R0_raw_extract"] = raw_extract[:2000]

        prev_missing, prev_extra = missing, extra
        prev_extracted = extracted

        final_round = 0
        final_image_path = r0_path

        for r in range(1, max_rounds + 1):
            if matched:
                break

            fb_prompt = _build_feedback_prompt(cfg, items, prev_extracted)

            edit_instruction = call_chat_with_image(
                cfg,
                "step1_feedback",
                fb_prompt,
                image_b64=current_b64,
                mime=current_mime,
            )

            r_path = os.path.join(pic_dir, f"{trial_id}_r{r}.png")
            _, new_b64 = call_image_edit(
                cfg,
                edit_instruction,
                current_b64,
                r_path,
                mime=current_mime,   
            )

            current_b64 = new_b64
            current_mime = infer_mime_from_b64(current_b64)

            extracted, raw_extract, used_tries = _extract_with_retry(
                cfg, current_b64, current_mime, extract_prompt, tries=8, base_sleep=0.6
            )
            matched, missing, extra = _match_keywords(items, extracted)

            row.update({
                f"R{r}_image": os.path.basename(r_path),
                f"R{r}_extracted": json.dumps(extracted),
                f"R{r}_missing": json.dumps(missing),
                f"R{r}_extra": json.dumps(extra),
                f"R{r}_matched": int(matched),
                f"R{r}_edit": edit_instruction,
                f"R{r}_degraded": _degraded(prev_missing, prev_extra, missing, extra),
                f"R{r}_extract_tries": used_tries,
            })
            if not extracted:
                row[f"R{r}_raw_extract"] = raw_extract[:2000]

            prev_missing, prev_extra = missing, extra
            prev_extracted = extracted
            final_round = r
            final_image_path = r_path

        row["success"] = int(matched)
        row["rounds_used"] = final_round + 1

        if matched:
            canonical = os.path.join(pic_dir, f"{trial_id}.png")
            if final_image_path != canonical:
                try:
                    os.replace(final_image_path, canonical)
                    final_image_path = canonical
                except Exception:
                    pass

            return {
                "trial_id": trial_id,
                "keywords": items,
                "image_path": final_image_path,
                "rounds": final_round + 1,
            }, row

        return {}, row

    except Exception as e:
        row["success"] = 0
        row["rounds_used"] = int(cfg.get("max_retries", 5)) + 1
        row["error"] = f"{type(e).__name__}: {e}"
        return {}, row


def run_step1(cfg: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    outputs_root = cfg["paths"]["outputs"]
    _ensure_dir(outputs_root)

    gen_prov = cfg["providers"][cfg["models"]["step1_image_generation"]["provider"]]
    vis_prov = cfg["providers"][cfg["models"]["step1_image_extraction"]["provider"]]
    max_workers = min(int(gen_prov.get("max_concurrent", 4)), int(vis_prov.get("max_concurrent", 4)))
    max_workers = max(1, max_workers)

    all_scene_results: Dict[str, List[Dict[str, Any]]] = {}

    overall_total = 0
    overall_success = 0
    overall_one_shot = 0
    overall_success_rounds_sum = 0

    for scene_name, scene_info in cfg["scenes"].items():
        scene_dir = os.path.join(outputs_root, scene_name)
        _ensure_dir(scene_dir)

        n_trials = int(cfg["n_trials_per_scene"])
        results_rows: List[Dict[str, Any]] = []
        details_rows: List[Dict[str, Any]] = []
        trials_out: List[Dict[str, Any]] = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
            futs = [
                ex.submit(_run_single_trial, cfg, scene_name, scene_info, i, scene_dir)
                for i in range(1, n_trials + 1)
            ]

            for fut in tqdm(concurrent.futures.as_completed(futs), total=len(futs), desc=f"step1 {scene_name}"):
                try:
                    trial_out, detail_row = fut.result()
                except Exception as e:
                    trial_out = {}
                    detail_row = {
                        "trial_id": f"{scene_name}_unknown",
                        "target": "",
                        "success": 0,
                        "rounds_used": int(cfg.get("max_retries", 5)) + 1,
                        "error": f"{type(e).__name__}: {e}",
                    }

                details_rows.append(detail_row)

                if trial_out:
                    trials_out.append(trial_out)
                    results_rows.append({
                        "trial_id": trial_out["trial_id"],
                        "keywords": json.dumps(trial_out["keywords"]),
                        "is_success": True,
                        "rounds_used": trial_out["rounds"],
                        "final_image": os.path.basename(trial_out["image_path"]),
                    })
                else:
                    results_rows.append({
                        "trial_id": detail_row.get("trial_id", ""),
                        "keywords": detail_row.get("target", ""),
                        "is_success": False,
                        "rounds_used": int(detail_row.get("rounds_used", cfg.get("max_retries", 5) + 1)),
                        "final_image": "",
                    })

        trials_out = sorted(trials_out, key=lambda x: x["trial_id"])
        all_scene_results[scene_name] = trials_out

        _write_json(os.path.join(scene_dir, "step1_meta.json"), trials_out)
        _save_xlsx(os.path.join(scene_dir, "step1_results.xlsx"), results_rows)
        _save_xlsx(os.path.join(scene_dir, "step1_rejection_details.xlsx"), details_rows)

        total = len(details_rows)
        succ = sum(1 for r in details_rows if int(r.get("success", 0)) == 1)
        one_shot = sum(1 for r in details_rows if int(r.get("success", 0)) == 1 and int(r.get("rounds_used", 0)) == 1)
        succ_rounds = [int(r.get("rounds_used", 0)) for r in details_rows if int(r.get("success", 0)) == 1]
        avg_rounds = (sum(succ_rounds) / len(succ_rounds)) if succ_rounds else None

        success_rate = (succ / total) if total else 0.0
        one_shot_rate = (one_shot / total) if total else 0.0

        print(f"\n[STEP1][{scene_name}] total={total}  success={succ}  success_rate={success_rate:.3f}")
        print(f"[STEP1][{scene_name}] one_shot_success={one_shot}  one_shot_rate={one_shot_rate:.3f}")
        if avg_rounds is None:
            print(f"[STEP1][{scene_name}] avg_rounds_given_success=N/A (no success)\n")
        else:
            print(f"[STEP1][{scene_name}] avg_rounds_given_success={avg_rounds:.3f}\n")

        overall_total += total
        overall_success += succ
        overall_one_shot += one_shot
        overall_success_rounds_sum += sum(succ_rounds)

    overall_success_rate = (overall_success / overall_total) if overall_total else 0.0
    overall_one_shot_rate = (overall_one_shot / overall_total) if overall_total else 0.0
    overall_avg_rounds = (overall_success_rounds_sum / overall_success) if overall_success else None

    print("\n========== STEP1 OVERALL ==========")
    print(f"[STEP1][OVERALL] total={overall_total}  success={overall_success}  success_rate={overall_success_rate:.3f}")
    print(f"[STEP1][OVERALL] one_shot_success={overall_one_shot}  one_shot_rate={overall_one_shot_rate:.3f}")
    if overall_avg_rounds is None:
        print(f"[STEP1][OVERALL] avg_rounds_given_success=N/A (no success)")
    else:
        print(f"[STEP1][OVERALL] avg_rounds_given_success={overall_avg_rounds:.3f}")
    print("==================================\n")

    return all_scene_results
