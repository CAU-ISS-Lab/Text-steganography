import argparse
import base64
from pathlib import Path

from protocol import create_session, extract_anchor
from step2.codebook import decode_words


def recover_caption(cfg, keywords, caption, side_information):
    from step2.scoring import build_semantic_pool
    from step3.validation import extract_codewords, verify_caption
    pool, _ = build_semantic_pool(keywords, cfg["paths"]["dictionary"], cfg["alpha"])
    anchor = extract_anchor(caption)
    session = create_session(cfg, pool[:len(keywords)], pool, anchor)
    words = extract_codewords(caption, pool)
    if len(words) != cfg["n_embed_words"]:
        raise ValueError("Incorrect number of codewords in the caption")
    errors = verify_caption(caption, words, pool, anchor,
                            cfg["text_min_len"], cfg["text_max_len"])
    if errors:
        raise ValueError("Invalid caption: " + "; ".join(errors))
    return decode_words(session["codebook"], cfg["L_seg"], words,
                        side_information, session["session_seed"])


def main():
    parser = argparse.ArgumentParser(description="Decode a DyCo-Stega image-caption message")
    parser.add_argument("--image", required=True)
    parser.add_argument("--caption-file", required=True, help="One public caption in UTF-8")
    parser.add_argument("--side-info-file", required=True, help="Auxiliary binary string S")
    parser.add_argument("--output", required=True, help="Recovered bits as text")
    parser.add_argument("--config-dir")
    args = parser.parse_args()
    from utils.config import load_config
    from protocol import load_psk
    from step1.run import _parse_extracted
    from utils.api import call_chat_with_image, infer_mime_from_b64
    cfg = load_config(args.config_dir)
    load_psk(cfg)
    caption = Path(args.caption_file).read_text(encoding="utf-8").strip()
    side = Path(args.side_info_file).read_text(encoding="utf-8").strip()
    image_b64 = base64.b64encode(Path(args.image).read_bytes()).decode("ascii")
    errors = []
    for _ in range(cfg.get("receiver_max_attempts", 3)):
        try:
            raw = call_chat_with_image(cfg, "step1_image_extraction",
                                       cfg["prompt_templates"]["image_extraction"],
                                       image_b64=image_b64, mime=infer_mime_from_b64(image_b64))
            keywords = _parse_extracted(raw)
            if len(set(keywords)) != cfg["n_image_keywords"] or len(keywords) != cfg["n_image_keywords"]:
                raise ValueError("Could not recover the required distinct image seed words")
            bits = recover_caption(cfg, keywords, caption, side)
            output = Path(args.output)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(bits + "\n", encoding="utf-8")
            print(f"Recovered {len(bits)} bits to {output}")
            return
        except ValueError as exc:
            errors.append(str(exc))
    raise RuntimeError("Receiver reconstruction failed after bounded retries: " + errors[-1])


if __name__ == "__main__":
    main()
