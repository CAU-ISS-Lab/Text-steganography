# 🔬 White-box Text Steganography

Reproductions of six white-box text steganography methods: AC, ADG, Discop, iMEC, Meteor, and SparSamp.

## How text is generated

1. Prepare short prompts from the included IMDB corpus and generate a binary message stream.
2. Load a local language model and compute the next-token probabilities for each prompt.
3. Generate cover text by sampling tokens, or generate stego text by letting the selected method map message bits to tokens.
4. Continue token by token, then save the texts and the bits embedded in each stego sentence for evaluation.

| Method | How message bits guide generation | Paper |
|---|---|---|
| [AC](methods/ac.py) | Uses message bits to select and update arithmetic-coding intervals built from token probabilities. | [Neural Linguistic Steganography](https://aclanthology.org/D19-1115/) |
| [ADG](methods/adg.py) | Divides candidates into approximately balanced groups, selects groups using message bits, then samples a token. | [Provably Secure Generative Linguistic Steganography](https://aclanthology.org/2021.findings-acl.268/) |
| [Discop](methods/discop.py) | Traverses a Huffman tree with rotated distribution copies, embedding bits when the copies choose different branches. | [Discop: Provably Secure Steganography in Practice Based on “Distribution Copies”](https://doi.org/10.1109/SP46215.2023.10179287) |
| [iMEC](methods/imec.py) | Couples message-block beliefs with token probabilities and updates those beliefs after each token choice. | [Perfectly Secure Steganography Using Minimum Entropy Coupling](https://openreview.net/forum?id=HQ67mj5rJdR) |
| [Meteor](methods/meteor.py) | Masks message bits with a pseudorandom stream and maps them to token probability intervals. | [Meteor: Cryptographically Secure Steganography for Realistic Distributions](https://dl.acm.org/doi/10.1145/3460120.3484550) |
| [SparSamp](methods/sparsamp.py) | Uses randomized sparse sampling to narrow the candidates for a message block until its bits are resolved. | [SparSamp: Efficient Provably Secure Steganography Based on Sparse Sampling](https://www.usenix.org/conference/usenixsecurity25/presentation/wang-yaofei) |

## Models

| Purpose | Default model |
|---|---|
| Text generation | `gpt2`, `Qwen/Qwen2.5-0.5B` |
| Perplexity (PPL) | `gpt2` |
| Distribution divergence (KLD) | `bert-base-uncased` |
| Semantic similarity (SS) | `sentence-transformers/roberta-base-nli-mean-tokens` |
| Optional steganalysis classifier | Fine-tuned `bert-base-uncased` |

The experiment runner uses both generation models by default. Individual generation scripts default to Qwen2.5-0.5B, configurable through `MODEL_PATH`.

## ⚙️ Installation

Use Python 3.10 or newer. From the repository root, install the dependencies and extract the included IMDB corpus:

```bash
pip install -r requirements.txt
python -m zipfile -e data/IMDB2020.zip data
```

## 🚀 Quick start

Preview the experiment matrix:

```bash
python scripts/run_main_experiments.py --dry-run --run-id preview
```

Run the full matrix with the included IMDB corpus:

```bash
python scripts/run_main_experiments.py --run-id main-001
```

This runs all six methods on GPT-2 and Qwen2.5, producing 10,000 cover and 10,000
stego sentences for each of the 12 groups with `top-p=0.99`.

To select a model and a few methods:

```bash
python scripts/run_main_experiments.py --models gpt2 --methods ac,adg --run-id selected-001
```

The default temperature is `1.0`.
Use `--gpt2-model` or `--qwen-model` to select a model ID or local model path, and `--temperature` or `--source` to change the generation settings or corpus.

## 📁 Results

Each model and method gets its own folder:

```text
outputs/main_experiment/main-001/<model>/<method>/
├── cover.txt
├── stego.txt
├── stego_bits.txt
└── eval_result.json
```

Evaluation reports perplexity (PPL), distribution divergence (KLD), semantic
similarity (SS), and embedding capacity in bits per word (EC). Use `--no-eval` to
run generation only. The run's settings are saved in `run_manifest.json`.

## Run a single method

```bash
python scripts/prepare_data.py --method adg --source data/IMDB2020.txt
python scripts/run_gen_cover.py --method adg
python scripts/run_gen_stego.py --method adg
python scripts/run_eval.py --method adg
```

These commands save results to `outputs/adg/` and use `config/global_config.py`.
