from __future__ import annotations

import os
import numpy as np
import torch


AC_K = int(os.getenv("AC_K", "100"))
AC_PRECISION = int(os.getenv("AC_PRECISION", "20"))

_PRINT_ONCE = False


def _print_once():
    global _PRINT_ONCE
    if not _PRINT_ONCE:
        print(f"[AC] AC_K={AC_K}, AC_PRECISION={AC_PRECISION}")
        _PRINT_ONCE = True


def _quantize_probs_to_counts(probs: np.ndarray, total: int) -> np.ndarray:

    if total <= 0:
        return np.zeros_like(probs, dtype=np.int64)

    probs = np.maximum(probs, 0.0)
    s = float(probs.sum())
    if not (s > 0.0):
        probs = np.ones_like(probs, dtype=np.float64) / probs.size
    else:
        probs = probs / s

    raw = probs * float(total)
    base = np.floor(raw).astype(np.int64)
    frac = raw - base

    current = int(base.sum())
    rem = int(total - current)

    if rem > 0:
        order = np.lexsort((np.arange(frac.size), -frac))
        base[order[:rem]] += 1
    elif rem < 0:
        need = -rem
        mask = base > 0
        if mask.any():
            frac2 = frac.copy()
            frac2[~mask] = np.inf
            order = np.lexsort((np.arange(frac2.size), frac2))
            taken = 0
            for idx in order:
                if base[idx] > 0:
                    base[idx] -= 1
                    taken += 1
                    if taken >= need:
                        break
        base = np.maximum(base, 0)

    diff = int(total - base.sum())
    if diff > 0:
        for i in range(diff):
            base[i % base.size] += 1
    elif diff < 0:
        need = -diff
        i = 0
        while need > 0:
            j = i % base.size
            if base[j] > 0:
                base[j] -= 1
                need -= 1
            i += 1

    return base.astype(np.int64)


def _common_prefix_len_msb(a: int, b: int, precision: int) -> int:

    sa = format(int(a), f"0{precision}b")
    sb = format(int(b), f"0{precision}b")
    n = 0
    for ca, cb in zip(sa, sb):
        if ca != cb:
            break
        n += 1
    return n


class _ACState:
    __slots__ = ("precision", "max_val", "low", "high")

    def __init__(self, precision: int):
        self.precision = int(precision)
        self.max_val = 1 << self.precision
        self.low = 0
        self.high = self.max_val

    def reset(self):
        self.low = 0
        self.high = self.max_val

    @property
    def int_range(self) -> int:
        return int(self.high - self.low)


_STATE = _ACState(AC_PRECISION)


def step(sorted_probs: torch.Tensor,
         sorted_indices: torch.Tensor,
         bit_reader,
         device=None):

    _print_once()

    precision = int(AC_PRECISION)
    k = min(int(AC_K), int(sorted_probs.numel()))
    if k <= 0:
        return int(sorted_indices[0].item()), ""

    probs = sorted_probs[:k].detach().to("cpu", dtype=torch.float64).numpy()
    indices = sorted_indices[:k].detach().to("cpu").numpy()

    if _STATE.int_range <= 1:
        _STATE.reset()

    cur_low = int(_STATE.low)
    cur_high = int(_STATE.high)
    cur_int_range = int(cur_high - cur_low)
    if cur_int_range <= 1:
        _STATE.reset()
        cur_low = int(_STATE.low)
        cur_high = int(_STATE.high)
        cur_int_range = int(cur_high - cur_low)

    counts = _quantize_probs_to_counts(probs, cur_int_range)

    cum = np.cumsum(counts, dtype=np.int64)
    if cum.size == 0:
        token_id = int(indices[0])
        return token_id, ""

    cum[-1] = cur_int_range
    cum = cum + cur_low

    snap = bit_reader.snapshot()
    peek_bits = bit_reader.read_bits(precision)
    bit_reader.restore(snap)

    if peek_bits is None:
        peek_bits = ""
    if len(peek_bits) < precision:
        peek_bits = peek_bits + ("0" * (precision - len(peek_bits)))

    message_idx = int(peek_bits, 2)

    pos = int(np.searchsorted(cum, message_idx + 1, side="left"))
    if pos >= cum.size:
        pos = int(cum.size - 1)

    new_low = int(cum[pos - 1]) if pos > 0 else cur_low
    new_high = int(cum[pos])

    if new_high <= new_low:
        token_id = int(indices[pos])
        return token_id, ""

    num_bits_encoded = _common_prefix_len_msb(new_low, new_high - 1, precision)

    consumed_bits = bit_reader.read_bits(num_bits_encoded) if num_bits_encoded > 0 else ""
    if consumed_bits is None:
        consumed_bits = ""

    low_bin = format(int(new_low), f"0{precision}b")
    high_bin = format(int(new_high - 1), f"0{precision}b")

    low_bin2 = low_bin[num_bits_encoded:] + ("0" * num_bits_encoded)
    high_bin2 = high_bin[num_bits_encoded:] + ("1" * num_bits_encoded)

    _STATE.low = int(low_bin2, 2)
    _STATE.high = int(high_bin2, 2) + 1

    token_id = int(indices[pos])
    return token_id, consumed_bits


class StegoMethod:

    def __init__(self, config, tokenizer):
        self.config = config
        self.tokenizer = tokenizer
        _print_once()
        global _STATE
        _STATE = _ACState(int(AC_PRECISION))

    def reset_sentence(self):
        _STATE.reset()

    def step(self, sorted_probs, sorted_indices, bit_reader):
        return step(sorted_probs, sorted_indices, bit_reader, self.config.DEVICE)
