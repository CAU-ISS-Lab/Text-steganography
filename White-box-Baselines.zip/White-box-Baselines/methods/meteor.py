from __future__ import annotations

import os
import hashlib
import hmac
import numpy as np
import torch

METEOR_PRECISION = int(os.getenv("METEOR_PRECISION", "16"))

METEOR_KEY_HEX = os.getenv("METEOR_KEY_HEX", "")

METEOR_NONCE_HEX = os.getenv("METEOR_NONCE_HEX", "")

METEOR_ALLOW_ANY_PRECISION = int(os.getenv("METEOR_ALLOW_ANY_PRECISION", "0"))

_PRINT_ONCE = False


def _print_once():
    global _PRINT_ONCE
    if not _PRINT_ONCE:
        print(
            f"[Meteor] METEOR_PRECISION={METEOR_PRECISION}, "
            f"KEY={'env' if METEOR_KEY_HEX else 'derived'}, "
            f"NONCE={'env' if METEOR_NONCE_HEX else 'default'}"
        )
        _PRINT_ONCE = True


def _xor_bitstrings(a: str, b: str) -> str:
    return "".join("1" if (ca != cb) else "0" for ca, cb in zip(a, b))


def _common_prefix_len_msb(a: int, b: int, precision: int) -> int:

    sa = format(int(a), f"0{precision}b")
    sb = format(int(b), f"0{precision}b")
    n = 0
    for ca, cb in zip(sa, sb):
        if ca != cb:
            break
        n += 1
    return n


def _quantize_probs_to_counts(probs: np.ndarray, total: int) -> np.ndarray:

    if total <= 0 or probs.size == 0:
        return np.zeros_like(probs, dtype=np.int64)

    probs = np.maximum(probs.astype(np.float64, copy=False), 0.0)
    s = float(probs.sum())
    if not (s > 0.0):
        probs = np.ones_like(probs, dtype=np.float64) / float(probs.size)
    else:
        probs /= s

    raw = probs * float(total)
    base = np.floor(raw).astype(np.int64)
    frac = raw - base

    rem = int(total - int(base.sum()))
    if rem > 0:
        order = np.lexsort((np.arange(frac.size), -frac))
        base[order[:rem]] += 1
    elif rem < 0:
        need = -rem
        mask = base > 0
        if mask.any():
            frac2 = frac.copy()
            frac2[~mask] = np.inf
            order = np.lexsort((np.arange(frac2.size), frac2))
            taken = 0
            for idx in order:
                if base[idx] > 0:
                    base[idx] -= 1
                    taken += 1
                    if taken >= need:
                        break
        base = np.maximum(base, 0)

    diff = int(total - int(base.sum()))
    if diff != 0:
        base[-1] = max(0, int(base[-1] + diff))

    return base.astype(np.int64)


class _HMACDRBG:


    __slots__ = ("key", "val", "byte_index", "bit_index")

    def __init__(self, key: bytes, seed: bytes):
        if not isinstance(key, (bytes, bytearray)) or len(key) == 0:
            raise ValueError("DRBG key must be non-empty bytes.")
        self.key = bytes(key)
        self.val = b"\x01" * 64
        self.byte_index = 0
        self.bit_index = 0
        self.reseed(seed)

    @staticmethod
    def _hmac(key: bytes, data: bytes) -> bytes:
        return hmac.new(key, data, hashlib.sha512).digest()

    def reseed(self, data: bytes = b""):
        self.key = self._hmac(self.key, self.val + b"\x00" + data)
        self.val = self._hmac(self.key, self.val)
        if data:
            self.key = self._hmac(self.key, self.val + b"\x01" + data)
            self.val = self._hmac(self.key, self.val)

    def generate_bits_str(self, n: int) -> str:

        if n <= 0:
            return ""
        out = []
        for _ in range(n):
            byte = self.val[self.byte_index]
            bit = (byte >> (7 - self.bit_index)) & 1
            out.append("1" if bit else "0")

            self.bit_index += 1
            if self.bit_index >= 8:
                self.bit_index = 0
                self.byte_index += 1

            if self.byte_index >= len(self.val):
                self.byte_index = 0
                self.val = self._hmac(self.key, self.val)

        self.reseed(b"")
        return "".join(out)


def _meteor_step(sorted_probs: torch.Tensor,
                 sorted_indices: torch.Tensor,
                 bit_reader,
                 precision: int,
                 drbg: _HMACDRBG):

    if precision <= 0 or sorted_probs.numel() == 0:
        return int(sorted_indices[0].item()), ""

    total = 1 << int(precision)

    probs = sorted_probs.detach().to("cpu", dtype=torch.float64).numpy()
    indices = sorted_indices.detach().to("cpu").numpy()

    counts = _quantize_probs_to_counts(probs, total)
    cum = np.cumsum(counts, dtype=np.int64)
    if cum.size == 0:
        return int(indices[0]), ""
    cum[-1] = total

    snap = bit_reader.snapshot()
    msg_peek = bit_reader.read_bits(precision)
    bit_reader.restore(snap)

    if msg_peek is None:
        msg_peek = ""
    if len(msg_peek) < precision:
        msg_peek = msg_peek + ("0" * (precision - len(msg_peek)))
    else:
        msg_peek = msg_peek[:precision]

    mask_bits = drbg.generate_bits_str(precision)
    r_bits = _xor_bitstrings(msg_peek, mask_bits)
    r = int(r_bits, 2)

    pos = int(np.searchsorted(cum, r + 1, side="left"))
    if pos >= cum.size:
        pos = int(cum.size - 1)

    low = int(cum[pos - 1]) if pos > 0 else 0
    high = int(cum[pos])

    if high <= low:
        token_id = int(indices[pos])
        return token_id, ""

    num_bits = _common_prefix_len_msb(low, high - 1, precision)

    consumed = bit_reader.read_bits(num_bits) if num_bits > 0 else ""
    if consumed is None:
        consumed = ""

    token_id = int(indices[pos])
    return token_id, consumed


class StegoMethod:


    def __init__(self, config, tokenizer):
        self.config = config
        self.tokenizer = tokenizer
        _print_once()

        self.precision = int(METEOR_PRECISION)
        if (self.precision < 1 or self.precision > 24) and not METEOR_ALLOW_ANY_PRECISION:
            raise ValueError(
                f"METEOR_PRECISION={self.precision} is unusual for truncated candidate sets. "
                f"Use 1~24 (default 16), or set METEOR_ALLOW_ANY_PRECISION=1 to override."
            )

        if METEOR_KEY_HEX:
            key = bytes.fromhex(METEOR_KEY_HEX)
        else:
            seed_bytes = str(getattr(config, "SEED", 0)).encode("utf-8")
            key = hashlib.sha512(b"meteor-key-derive:" + seed_bytes).digest()

        if METEOR_NONCE_HEX:
            nonce = bytes.fromhex(METEOR_NONCE_HEX)
        else:
            nonce = b"\x00" * 16

        self._drbg = _HMACDRBG(key=key, seed=b"meteor-sample:" + nonce)

    def reset_sentence(self):

        pass

    def step(self, sorted_probs, sorted_indices, bit_reader):
        token_id, bits = _meteor_step(
            sorted_probs=sorted_probs,
            sorted_indices=sorted_indices,
            bit_reader=bit_reader,
            precision=self.precision,
            drbg=self._drbg,
        )
        return token_id, bits
