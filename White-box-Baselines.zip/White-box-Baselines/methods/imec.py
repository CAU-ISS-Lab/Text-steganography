from __future__ import annotations

import os
from typing import List

import numpy as np
import torch


IMEC_BLOCK_SIZE = int(os.getenv("IMEC_BLOCK_SIZE", "8"))
IMEC_BELIEF_ENTROPY_THRESHOLD = float(os.getenv("IMEC_BELIEF_ENTROPY_THRESHOLD", "0.10"))
IMEC_MAX_CHUNKS_PER_SENTENCE = int(os.getenv("IMEC_MAX_CHUNKS_PER_SENTENCE", "16"))

IMEC_MAX_STATES = int(os.getenv("IMEC_MAX_STATES", "16384"))

_PRINT_ONCE = False


def _print_once():
    global _PRINT_ONCE
    if not _PRINT_ONCE:
        print(
            f"[iMEC] IMEC_BLOCK_SIZE={IMEC_BLOCK_SIZE}, "
            f"IMEC_BELIEF_ENTROPY_THRESHOLD={IMEC_BELIEF_ENTROPY_THRESHOLD}, "
            f"IMEC_MAX_CHUNKS_PER_SENTENCE={IMEC_MAX_CHUNKS_PER_SENTENCE}, "
            f"IMEC_MAX_STATES={IMEC_MAX_STATES}"
        )
        _PRINT_ONCE = True


def _entropy2(p: np.ndarray) -> float:

    p = np.asarray(p, dtype=np.float64)
    s = float(p.sum())
    if not (s > 0.0):
        return 0.0
    p = p / s
    eps = 1e-300
    return float(-(p * np.log2(p + eps)).sum())


def _stable_argsort_desc(x: np.ndarray) -> np.ndarray:
    return np.argsort(-x, kind="mergesort")


def _greedy_coupling_row_masses(p: np.ndarray, q: np.ndarray, row_idx: int) -> np.ndarray:

    p = np.asarray(p, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)

    n = int(p.size)
    m = int(q.size)
    out = np.zeros(m, dtype=np.float64)

    ps = float(p.sum())
    qs = float(q.sum())
    if not (ps > 0.0) or not (qs > 0.0):
        return out

    p = p / ps
    q = q / qs

    p_order = _stable_argsort_desc(p)
    q_order = _stable_argsort_desc(q)

    i = 0
    j = 0
    p_rem = float(p[p_order[i]])
    q_rem = float(q[q_order[j]])
    eps = 1e-18

    while i < n and j < m:
        mass = p_rem if p_rem <= q_rem else q_rem
        i_orig = int(p_order[i])
        j_orig = int(q_order[j])

        if i_orig == int(row_idx):
            out[j_orig] += mass

        p_rem -= mass
        q_rem -= mass

        if p_rem <= eps:
            i += 1
            if i >= n:
                break
            p_rem = float(p[p_order[i]])
        if q_rem <= eps:
            j += 1
            if j >= m:
                break
            q_rem = float(q[q_order[j]])

    out = np.maximum(out, 0.0)
    return out


def _greedy_coupling_col_masses(p: np.ndarray, q: np.ndarray, col_idx: int) -> np.ndarray:

    p = np.asarray(p, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)

    n = int(p.size)
    m = int(q.size)
    out = np.zeros(n, dtype=np.float64)

    ps = float(p.sum())
    qs = float(q.sum())
    if not (ps > 0.0) or not (qs > 0.0):
        return out

    p = p / ps
    q = q / qs

    p_order = _stable_argsort_desc(p)
    q_order = _stable_argsort_desc(q)

    i = 0
    j = 0
    p_rem = float(p[p_order[i]])
    q_rem = float(q[q_order[j]])
    eps = 1e-18

    while i < n and j < m:
        mass = p_rem if p_rem <= q_rem else q_rem
        i_orig = int(p_order[i])
        j_orig = int(q_order[j])

        if j_orig == int(col_idx):
            out[i_orig] += mass

        p_rem -= mass
        q_rem -= mass

        if p_rem <= eps:
            i += 1
            if i >= n:
                break
            p_rem = float(p[p_order[i]])
        if q_rem <= eps:
            j += 1
            if j >= m:
                break
            q_rem = float(q[q_order[j]])

    out = np.maximum(out, 0.0)
    return out


class StegoMethod:


    def __init__(self, config, tokenizer):
        self.config = config
        self.tokenizer = tokenizer

        _print_once()

        self.block_size = int(IMEC_BLOCK_SIZE)
        self.n_states = 1 << self.block_size
        if self.n_states > int(IMEC_MAX_STATES):
            raise ValueError(
                f"[iMEC] 2^IMEC_BLOCK_SIZE too large for this Python implementation: "
                f"IMEC_BLOCK_SIZE={self.block_size} -> {self.n_states} states. "
                f"Increase IMEC_MAX_STATES or reduce IMEC_BLOCK_SIZE."
            )

        self.entropy_threshold = float(IMEC_BELIEF_ENTROPY_THRESHOLD)
        self.max_chunks = int(IMEC_MAX_CHUNKS_PER_SENTENCE)

        self._uniform_belief = (np.ones(self.n_states, dtype=np.float64) / float(self.n_states))

        self._bank_size = int(getattr(self.config, "BATCH_SIZE", 1) or 1)
        self._cursor = 0

        self._beliefs_bank: List[List[np.ndarray]] = [[] for _ in range(self._bank_size)]
        self._chunks_bank: List[List[int]] = [[] for _ in range(self._bank_size)]

    def reset_sentence(self):
        self._cursor = 0
        for i in range(self._bank_size):
            self._beliefs_bank[i] = []
            self._chunks_bank[i] = []

    def _select_slot(self) -> int:

        slot = int(self._cursor % self._bank_size)
        self._cursor += 1
        return slot

    def _maybe_add_new_chunk(self, beliefs: List[np.ndarray], chunks: List[int], bit_reader) -> str:

        if len(beliefs) >= self.max_chunks:
            return ""

        if not beliefs:
            need_new = True
        else:
            ents = [(_entropy2(b) if b is not None else 0.0) for b in beliefs]
            need_new = (max(ents) <= self.entropy_threshold)

        if not need_new:
            return ""

        bits = bit_reader.read_bits(self.block_size)
        if bits is None:
            bits = ""
        if len(bits) < self.block_size:
            bits = bits + ("0" * (self.block_size - len(bits)))

        x = int(bits, 2) if bits else 0
        chunks.append(int(x))
        beliefs.append(self._uniform_belief.copy())
        return bits

    def step(self, sorted_probs: torch.Tensor, sorted_indices: torch.Tensor, bit_reader):

        if sorted_probs is None or sorted_indices is None or sorted_probs.numel() == 0:
            return 0, ""

        slot = self._select_slot()
        beliefs = self._beliefs_bank[slot]
        chunks = self._chunks_bank[slot]

        consumed_bits = self._maybe_add_new_chunk(beliefs, chunks, bit_reader)

        if not beliefs:
            pos = torch.multinomial(sorted_probs, 1).item()
            return int(sorted_indices[pos].item()), ""

        entropies = np.array([_entropy2(b) for b in beliefs], dtype=np.float64)
        active = int(entropies.argmax())

        p = beliefs[active]
        ps = float(p.sum())
        if not (ps > 0.0):
            p = self._uniform_belief.copy()
        else:
            p = (p / ps).astype(np.float64, copy=False)

        q = sorted_probs.detach().to("cpu", dtype=torch.float64).numpy()
        qs = float(q.sum())
        if not (qs > 0.0):
            q = np.ones_like(q, dtype=np.float64) / float(q.size)
        else:
            q = q / qs

        x = int(chunks[active])
        x = max(0, min(x, self.n_states - 1))

        row_masses = _greedy_coupling_row_masses(p, q, row_idx=x)
        row_sum = float(row_masses.sum())
        if not (row_sum > 0.0):
            a = int(torch.multinomial(sorted_probs, 1).item())
            token_id = int(sorted_indices[a].item())
            return token_id, consumed_bits

        row_probs = (row_masses / row_sum).astype(np.float32, copy=False)
        a = int(torch.multinomial(torch.from_numpy(row_probs), 1).item())
        token_id = int(sorted_indices[a].item())

        col_masses = _greedy_coupling_col_masses(p, q, col_idx=a)
        col_sum = float(col_masses.sum())
        if col_sum > 0.0:
            beliefs[active] = (col_masses / col_sum).astype(np.float64, copy=False)
        else:
            beliefs[active] = p

        return token_id, consumed_bits
