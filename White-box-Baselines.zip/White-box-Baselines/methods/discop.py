from __future__ import annotations

import os
import random
from collections import deque
from typing import List, Tuple

import torch

DISCOP_RESEED_EACH_SENTENCE = bool(int(os.getenv("DISCOP_RESEED_EACH_SENTENCE", "1")))

_PRINT_ONCE = False


def _print_once():
    global _PRINT_ONCE
    if not _PRINT_ONCE:
        print(f"[Discop] DISCOP_RESEED_EACH_SENTENCE={int(DISCOP_RESEED_EACH_SENTENCE)}")
        _PRINT_ONCE = True


def _rotate_right(a: float, d: float, e: float) -> float:

    b = a + d
    if b >= e:
        b -= e
    return b


def _build_huffman_arrays_from_desc_probs(
    probs_desc: List[float],
    token_ids_desc: List[int],
) -> Tuple[List[float], List[int], List[int], int, int]:

    n = int(len(probs_desc))
    if n <= 0:
        return [1.0], [-1], [-1], 0, 0
    if n == 1:
        return [float(probs_desc[0])], [-1], [-1], 0, 1

    probs_asc = list(reversed(probs_desc))
    token_ids_asc = list(reversed(token_ids_desc))

    total_nodes = 2 * n - 1
    prob = [0.0] * total_nodes
    left_child = [-1] * total_nodes
    right_child = [-1] * total_nodes

    for i in range(n):
        p = float(probs_asc[i])
        if not (p >= 0.0) or not (p == p):
            p = 0.0
        prob[i] = p

    q1 = deque(range(n))
    q2: deque[int] = deque()

    def get_min() -> int:
        if q1 and q2:
            if prob[q1[0]] <= prob[q2[0]]:
                return q1.popleft()
            return q2.popleft()
        if q1:
            return q1.popleft()
        return q2.popleft()

    for new_idx in range(n, total_nodes):
        a = get_min()
        b = get_min()
        left_child[new_idx] = a
        right_child[new_idx] = b
        prob[new_idx] = prob[a] + prob[b]
        q2.append(new_idx)

    root_idx = total_nodes - 1
    return prob, left_child, right_child, token_ids_asc, root_idx, n


def _discop_sample_one_token(
    sorted_probs: torch.Tensor,
    sorted_indices: torch.Tensor,
    bit_reader,
    rng: random.Random,
) -> Tuple[int, str]:

    probs_desc = sorted_probs.detach().to("cpu", dtype=torch.float32).tolist()
    token_ids_desc = sorted_indices.detach().to("cpu").tolist()

    if not probs_desc or not token_ids_desc:
        return int(sorted_indices[0].item()), ""

    if len(probs_desc) == 1:
        return int(token_ids_desc[0]), ""

    prob, left_child, right_child, leaf_token_ids_asc, root_idx, n_leaves = _build_huffman_arrays_from_desc_probs(
        probs_desc, token_ids_desc
    )

    consumed_bits: List[str] = []

    node = int(root_idx)
    while node >= n_leaves:
        e = float(prob[node])
        if not (e > 0.0):
            return int(token_ids_desc[0]), "".join(consumed_bits)

        l = int(left_child[node])
        r = int(right_child[node])
        sep = float(prob[l])

        r0 = rng.random() * e
        r1 = _rotate_right(r0, 0.5 * e, e)

        next0 = l if r0 < sep else r
        next1 = l if r1 < sep else r

        if next0 != next1:
            b = bit_reader.read_bits(1)
            if b is None or len(b) == 0:
                b = "0"
            else:
                b = b[0]

            consumed_bits.append(b)
            node = next0 if b == "0" else next1
        else:
            node = next0

    token_id = int(leaf_token_ids_asc[node])
    return token_id, "".join(consumed_bits)


class StegoMethod:


    def __init__(self, config, tokenizer):
        self.config = config
        self.tokenizer = tokenizer
        _print_once()

        self._base_seed = int(getattr(config, "SEED", 0) or 0)
        self._sent_nonce = 0

        self._rng = random.Random(self._base_seed)

    def reset_sentence(self):
        if not DISCOP_RESEED_EACH_SENTENCE:
            return
        self._sent_nonce += 1
        seed64 = (self._base_seed ^ (self._sent_nonce * 0x9E3779B97F4A7C15)) & 0xFFFFFFFFFFFFFFFF
        self._rng.seed(seed64)

    def step(self, sorted_probs, sorted_indices, bit_reader):
        return _discop_sample_one_token(sorted_probs, sorted_indices, bit_reader, self._rng)
