import hashlib


def stable_seed(base_seed: int, namespace: str) -> int:

    payload = f"{int(base_seed)}:{namespace}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:4], "big")
