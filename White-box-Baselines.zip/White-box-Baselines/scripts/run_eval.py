import argparse
import json
import os
from pathlib import Path
import numpy as np

PPL_MAX_LENGTH = 1024
KLD_EPS = 1e-8
COSINE_EPS = 1e-12
SBERT_MODEL = "sentence-transformers/roberta-base-nli-mean-tokens"


def load_lines(path, allow_empty=False):
    with open(path, encoding="utf-8") as stream:
        lines = [line.strip() for line in stream]
    if not lines:
        raise ValueError(f"Empty file: {path}")
    if not allow_empty:
        for row, line in enumerate(lines, 1):
            if not line:
                raise ValueError(f"Blank caption at {path}:{row}")
    return lines


def load_method_inputs(method_dir):
    method_dir = Path(method_dir)
    cover = load_lines(method_dir / "cover.txt")
    stego = load_lines(method_dir / "stego.txt")
    bits = load_lines(method_dir / "stego_bits.txt", allow_empty=True)
    if len(cover) != len(stego) or len(stego) != len(bits):
        raise ValueError(f"Unaligned files in {method_dir}: cover={len(cover)}, stego={len(stego)}, bits={len(bits)}")
    for row, value in enumerate(bits, 1):
        if set(value) - {"0", "1"}:
            raise ValueError(f"Non-binary payload at {method_dir / 'stego_bits.txt'}:{row}")
    return cover, stego, bits


_ppl_models = {}
_embed_models = {}
_bert_models = {}


def _load_ppl_model(model_name, device):
    key = (model_name, str(device))
    if key not in _ppl_models:
        from transformers import GPT2LMHeadModel, GPT2TokenizerFast
        tokenizer = GPT2TokenizerFast.from_pretrained(model_name)
        tokenizer.pad_token = tokenizer.eos_token
        tokenizer.padding_side = "right"
        model = GPT2LMHeadModel.from_pretrained(model_name).to(device)
        model.config.pad_token_id = tokenizer.eos_token_id
        model.eval()
        _ppl_models[key] = model, tokenizer
    return _ppl_models[key]


def compute_ppl(sentences, model_name="gpt2", device="cuda"):
    import torch
    model, tokenizer = _load_ppl_model(model_name, device)
    losses = []
    with torch.no_grad():
        for sentence in sentences:
            enc = tokenizer(sentence, return_tensors="pt", truncation=True, max_length=PPL_MAX_LENGTH)
            input_ids = enc.input_ids.to(device)
            if input_ids.size(1) < 2:
                raise ValueError("PPL is undefined for captions with fewer than two GPT-2 tokens")
            losses.append(model(input_ids, labels=input_ids).loss.item())
    ppls = perplexities_from_mean_losses(losses)
    return ppls, float(np.mean(ppls))


def _load_embed_model(model_name, device):
    key = (model_name, str(device))
    if key not in _embed_models:
        from sentence_transformers import SentenceTransformer
        _embed_models[key] = SentenceTransformer(model_name, device=device)
    return _embed_models[key]


def get_embeddings(sentences, model_name, device, batch_size=64):
    return _load_embed_model(model_name, device).encode(
        sentences, batch_size=batch_size, show_progress_bar=False, convert_to_numpy=True,
    )


def _load_bert_model(model_name, device):
    key = (model_name, str(device))
    if key not in _bert_models:
        from transformers import BertModel, BertTokenizerFast
        tokenizer = BertTokenizerFast.from_pretrained(model_name)
        model = BertModel.from_pretrained(model_name).to(device)
        model.eval()
        _bert_models[key] = model, tokenizer
    return _bert_models[key]


def get_bert_embeddings(sentences, model_name="bert-base-uncased", device="cuda", batch_size=64):
    import torch
    model, tokenizer = _load_bert_model(model_name, device)
    embeddings = []
    with torch.no_grad():
        for start in range(0, len(sentences), batch_size):
            enc = tokenizer(
                sentences[start:start + batch_size], return_tensors="pt", padding=True,
                truncation=True, max_length=512,
            ).to(device)
            embeddings.append(model(**enc).last_hidden_state[:, 0, :].cpu().numpy())
    return np.concatenate(embeddings, axis=0)


def perplexities_from_mean_losses(losses):

    values = np.asarray(losses, dtype=np.float64)
    if values.ndim != 1 or not len(values) or not np.isfinite(values).all():
        raise ValueError("PPL requires finite mean losses for every sentence")
    with np.errstate(over="ignore"):
        ppls = np.exp(values)
    if not np.isfinite(ppls).all():
        raise ValueError("Non-finite PPL; no sentence was silently discarded")
    return ppls.tolist()


def _feature_pair(cover, stego, paired=False):
    cover, stego = np.asarray(cover, dtype=np.float64), np.asarray(stego, dtype=np.float64)
    if cover.ndim != 2 or stego.ndim != 2 or not len(cover) or not len(stego):
        raise ValueError("Expected nonempty two-dimensional feature arrays")
    if cover.shape[1] != stego.shape[1] or (paired and cover.shape != stego.shape):
        raise ValueError(f"Feature shape mismatch: {cover.shape} vs {stego.shape}")
    if not np.isfinite(cover).all() or not np.isfinite(stego).all():
        raise ValueError("Features must be finite")
    return cover, stego


def compute_kld_gaussian(cover_embeds, stego_embeds):
    cover, stego = _feature_pair(cover_embeds, stego_embeds)
    mu_x, mu_y = cover.mean(axis=0), stego.mean(axis=0)
    sigma_x, sigma_y = cover.std(axis=0) + KLD_EPS, stego.std(axis=0) + KLD_EPS
    return float(np.sum(np.log(sigma_y / sigma_x) + (
        sigma_x ** 2 + (mu_x - mu_y) ** 2
    ) / (2.0 * sigma_y ** 2) - 0.5))


def compute_pairwise_cosine_similarity(a, b, eps=COSINE_EPS):
    a, b = _feature_pair(a, b, paired=True)
    a = a / np.maximum(np.linalg.norm(a, axis=1, keepdims=True), eps)
    b = b / np.maximum(np.linalg.norm(b, axis=1, keepdims=True), eps)
    return np.sum(a * b, axis=1)


def compute_kld2(cover_embs, stego_embs):

    return compute_kld_gaussian(cover_embs, stego_embs)


def compute_ss(cover_embs, stego_embs):
    sims = compute_pairwise_cosine_similarity(cover_embs, stego_embs)
    return sims.tolist(), float(np.mean(sims))


def compute_ec(bits_lines, stego_lines):
    if not stego_lines or len(bits_lines) != len(stego_lines):
        raise ValueError("Capacity requires one payload row per nonempty stego caption")
    if any(not sentence.strip() for sentence in stego_lines):
        raise ValueError("Empty stego caption in capacity input")
    if any(not isinstance(bits, str) or set(bits) - {"0", "1"} for bits in bits_lines):
        raise ValueError("Payloads must be binary strings (zero-bit rows are allowed)")
    total_bits = sum(len(bits) for bits in bits_lines)
    total_words = sum(len(sentence.split()) for sentence in stego_lines)
    return total_bits / total_words, total_bits, total_words


def eval_method(method, output_dir, device, ppl_model, kld_model, ss_model):
    method_dir = Path(output_dir) / method
    cover, stego, bits = load_method_inputs(method_dir)
    ppls, avg_ppl = compute_ppl(stego, model_name=ppl_model, device=device)
    cover_kld = get_bert_embeddings(cover, model_name=kld_model, device=device)
    stego_kld = get_bert_embeddings(stego, model_name=kld_model, device=device)
    cover_ss = get_embeddings(cover, model_name=ss_model, device=device)
    stego_ss = get_embeddings(stego, model_name=ss_model, device=device)
    if any(len(values) != len(stego) for values in [ppls, cover_kld, stego_kld, cover_ss, stego_ss]):
        raise ValueError(f"Missing metric outputs for {method}")
    _, avg_ss = compute_ss(cover_ss, stego_ss)
    ec, total_bits, total_words = compute_ec(bits, stego)
    result = {
        "method": method, "n": len(stego), "PPL": avg_ppl,
        "KLD": compute_kld2(cover_kld, stego_kld), "SS": avg_ss, "EC(bpw)": ec,
        "total_bits": total_bits, "total_words": total_words,
        "ppl_model": ppl_model, "ppl_max_length": PPL_MAX_LENGTH,
        "ppl_aggregation": "mean_sentence_perplexity",
        "kld_model": kld_model, "kld_representation": "raw_cls", "kld_normalization": "none",
        "kld_epsilon": KLD_EPS, "kld_direction": "cover_to_stego",
        "kld_aggregation": "pooled_corpus", "ss_model": ss_model,
        "ss_aggregation": "mean_paired_cosine",
    }
    (method_dir / "eval_result.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8",
    )
    return result


def main():
    parser = argparse.ArgumentParser(description="Evaluate PPL / KLD / SS / EC")
    parser.add_argument("--method", required=True, help="Comma-separated method names or 'all'")
    parser.add_argument("--output-dir", type=Path, default=Path(os.getenv("OUTPUT_DIR", "outputs")))
    parser.add_argument("--ppl_model", default="gpt2")
    parser.add_argument("--kld_model", default="bert-base-uncased")
    parser.add_argument("--ss_model", default=SBERT_MODEL)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()
    if args.method.strip().lower() == "all":
        methods = sorted(
            path.name for path in args.output_dir.iterdir()
            if path.is_dir() and ((path / "stego.txt").exists() or (path / "cover.txt").exists())
        )
    else:
        methods = [name.strip() for name in args.method.split(",") if name.strip()]
    if not methods:
        parser.error("No method outputs found")
    for method in methods:
        load_method_inputs(args.output_dir / method)
    import torch
    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    for method in methods:
        result = eval_method(method, args.output_dir, device, args.ppl_model, args.kld_model, args.ss_model)
        print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
