import os
import sys
import json
import argparse
import random
from pathlib import Path
from typing import List, Dict

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.reproducibility import stable_seed


def read_lines(p: Path) -> List[str]:
    if not p.exists():
        return []
    out = []
    with p.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if s:
                out.append(s)
    return out


def write_lines(p: Path, lines: List[str]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        for s in lines:
            f.write(s.replace("\n", " ").replace("\r", " ") + "\n")


def split_lines(lines: List[str], n_train: int, n_val: int, n_test: int,
                rng: random.Random):

    idx = list(range(len(lines)))
    rng.shuffle(idx)
    selected = idx[:n_train + n_val + n_test]

    train_idx = selected[:n_train]
    val_idx = selected[n_train:n_train + n_val]
    test_idx = selected[n_train + n_val:n_train + n_val + n_test]

    return (
        [lines[i] for i in train_idx],
        [lines[i] for i in val_idx],
        [lines[i] for i in test_idx],
    )


def main():
    ap = argparse.ArgumentParser(
        description="Split outputs/ into per-method train/val/test for steganalysis"
    )
    ap.add_argument("--outputs_dir", type=str, default=os.getenv("OUTPUT_DIR", "outputs"))
    ap.add_argument("--out_data_dir", type=str, default="steganalysis/data")
    ap.add_argument("--methods", type=str, default="all",
                    help="Comma-separated method names, or 'all'")
    ap.add_argument("--train_ratio", type=float, default=0.6,
                    help="Fraction of data for training")
    ap.add_argument("--val_ratio", type=float, default=0.2,
                    help="Fraction of data for validation")
    ap.add_argument("--seed", type=int, default=1234)
    args = ap.parse_args()

    test_ratio = 1.0 - args.train_ratio - args.val_ratio
    if test_ratio < 0.05:
        raise ValueError(
            f"test_ratio={test_ratio:.2f} too small. "
            f"Adjust --train_ratio ({args.train_ratio}) and --val_ratio ({args.val_ratio})"
        )

    outputs_dir = Path(args.outputs_dir)
    out_data_dir = Path(args.out_data_dir)

    if args.methods.lower() == "all":
        method_dirs = [
            d for d in sorted(outputs_dir.iterdir())
            if d.is_dir()
            and d.name != "cover"
            and (d / "stego.txt").exists()
            and (d / "cover.txt").exists()
        ]
    else:
        names = [m.strip() for m in args.methods.split(",") if m.strip()]
        method_dirs = [
            outputs_dir / n for n in names
            if (outputs_dir / n / "stego.txt").exists()
            and (outputs_dir / n / "cover.txt").exists()
        ]

    if not method_dirs:
        raise FileNotFoundError(
            "No method directory found with both cover.txt and stego.txt under outputs/. "
            "Make sure each method folder has its own cover.txt."
        )

    method_names = [d.name for d in method_dirs]
    print(f"[info] methods: {method_names}")

    split_info = {
        "seed": args.seed,
        "seed_algorithm": "sha256-first-32-bits-v1",
        "train_ratio": args.train_ratio,
        "val_ratio": args.val_ratio,
        "test_ratio": round(test_ratio, 4),
        "methods": {},
    }

    for d in method_dirs:
        method_name = d.name

        cover_lines = read_lines(d / "cover.txt")
        stego_lines = read_lines(d / "stego.txt")

        if not cover_lines:
            raise FileNotFoundError(f"Empty cover.txt: {d / 'cover.txt'}")
        if not stego_lines:
            raise FileNotFoundError(f"Empty stego.txt: {d / 'stego.txt'}")

        n_per_class = min(len(cover_lines), len(stego_lines))

        n_train = int(n_per_class * args.train_ratio)
        n_val = int(n_per_class * args.val_ratio)
        n_test = n_per_class - n_train - n_val

        if n_test <= 0:
            raise ValueError(
                f"[{method_name}] n_test={n_test} <= 0. "
                f"Reduce ratios or increase data (cover={len(cover_lines)}, stego={len(stego_lines)})."
            )

        print(f"\n[{method_name}] cover={len(cover_lines)}  stego={len(stego_lines)}  "
              f"n_per_class={n_per_class}")
        print(f"  split: train={n_train}  val={n_val}  test={n_test}  (per class)")

        cover_seed = stable_seed(args.seed, method_name + "_cover")
        stego_seed = stable_seed(args.seed, method_name + "_stego")
        rng_cover = random.Random(cover_seed)
        rng_stego = random.Random(stego_seed)

        train_cover, val_cover, test_cover = split_lines(
            cover_lines, n_train, n_val, n_test, rng_cover
        )
        train_stego, val_stego, test_stego = split_lines(
            stego_lines, n_train, n_val, n_test, rng_stego
        )

        mdir = out_data_dir / method_name
        write_lines(mdir / "train_cover.txt", train_cover)
        write_lines(mdir / "train_stego.txt", train_stego)
        write_lines(mdir / "val_cover.txt", val_cover)
        write_lines(mdir / "val_stego.txt", val_stego)
        write_lines(mdir / "test_cover.txt", test_cover)
        write_lines(mdir / "test_stego.txt", test_stego)

        split_info["methods"][method_name] = {
            "cover_source": str(d / "cover.txt"),
            "stego_source": str(d / "stego.txt"),
            "total_cover_lines": len(cover_lines),
            "total_stego_lines": len(stego_lines),
            "n_per_class": n_per_class,
            "n_train": n_train,
            "n_val": n_val,
            "n_test": n_test,
            "cover_seed": cover_seed,
            "stego_seed": stego_seed,
        }

        print(f"  → {mdir}")

    info_path = out_data_dir / "split_info.json"
    with info_path.open("w", encoding="utf-8") as f:
        json.dump(split_info, f, indent=2, ensure_ascii=False)

    print(f"\n[done] Split info saved to: {info_path.resolve()}")
    print(f"       Data root: {out_data_dir.resolve()}")
    print()
    print("Next steps:")
    print(f"  1. Train:  python -m steganalysis.bert_detector.train_detector --data_dir {out_data_dir}")
    print(f"  2. Eval:   python scripts/run_steganalysis_bert_eval.py --data_dir {out_data_dir}")


if __name__ == "__main__":
    main()
