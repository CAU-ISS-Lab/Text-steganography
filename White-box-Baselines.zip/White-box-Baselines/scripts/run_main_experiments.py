import argparse
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import math
import os
from pathlib import Path
import platform
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
METHODS = ("ac", "adg", "discop", "imec", "meteor", "sparsamp")
MODEL_KEYS = ("gpt2", "qwen2.5")
SERIAL_METHODS = frozenset(("ac", "imec", "sparsamp"))
NUM_SENTENCES = 10000
TOP_P = "0.99"

ENV_DEFAULTS = {
    "EXPECTED_MESSAGE_BITS": "1000000",
    "MAX_NEW_TOKENS": "200",
    "MIN_NEW_TOKENS": "10",
    "TOP_K": "0",
    "CANDIDATE_TOP_K": "4096",
    "EMBED_SKIP_PROB": "0",
    "SKIP_FLATTEN_ALPHA": "1",
    "SKIP_DROP_TOP_N": "0",
    "COVER_MAX_ATTEMPTS": "30",
    "STEGO_MAX_ATTEMPTS": "30",
    "DETERMINISTIC": "0",
    "HF_ENDPOINT": "https://hf-mirror.com",
    "AC_K": "100",
    "AC_PRECISION": "20",
    "ADG_R_MAX": "5",
    "DISCOP_RESEED_EACH_SENTENCE": "1",
    "IMEC_BLOCK_SIZE": "8",
    "IMEC_BELIEF_ENTROPY_THRESHOLD": "0.10",
    "IMEC_MAX_CHUNKS_PER_SENTENCE": "16",
    "IMEC_MAX_STATES": "16384",
    "METEOR_PRECISION": "16",
    "METEOR_KEY_HEX": "",
    "METEOR_NONCE_HEX": "",
    "METEOR_ALLOW_ANY_PRECISION": "0",
    "SPARSAMP_LM": "32",
    "SPARSAMP_PRNG_SEED": "",
    "SPARSAMP_CARRY_ACROSS_SENTENCE": "0",
}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def make_parser():
    parser = argparse.ArgumentParser(description="Run white-box text steganography experiments")
    parser.add_argument("--models", default=",".join(MODEL_KEYS),
                        help="Comma-separated model keys: gpt2,qwen2.5")
    parser.add_argument("--methods", default=",".join(METHODS),
                        help="Comma-separated baseline methods, or all")
    parser.add_argument("--gpt2-model", default="gpt2",
                        help="GPT-2 model ID or local model path")
    parser.add_argument("--qwen-model", default="Qwen/Qwen2.5-0.5B",
                        help="Qwen model ID or local model path (default: Qwen/Qwen2.5-0.5B)")
    parser.add_argument("--temperature", type=float, default=1.0,
                        help="Sampling temperature (default: 1.0)")
    parser.add_argument("--batch-size", type=int, default=64,
                        help="Batch for ADG/Discop/Meteor; AC/iMEC/SparSamp use 1")
    parser.add_argument("--seed", type=int, default=1234,
                        help="Random seed used by all groups")
    parser.add_argument("--source", type=Path, default=ROOT / "data" / "IMDB2020.txt")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs" / "main_experiment")
    parser.add_argument("--run-id", default=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"),
                        help="Name of a new run directory")
    parser.add_argument("--no-eval", action="store_true",
                        help="Prepare and generate only; omit PPL/KLD2/SS/EC evaluation")
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview the experiment settings and commands as JSON")
    return parser


def select_names(value, allowed):
    names = list(allowed) if value.strip().lower() == "all" else [
        part.strip().lower() for part in value.split(",") if part.strip()
    ]
    if not names or len(names) != len(set(names)) or any(n not in allowed for n in names):
        raise ValueError(f"Choose unique entries from {', '.join(allowed)}: {value!r}")
    return names


def public_environment(values):

    result = dict(values)
    for key in ("METEOR_KEY_HEX", "METEOR_NONCE_HEX"):
        value = result[key]
        if value:
            result[key] = {"set": True, "sha256": hashlib.sha256(value.encode()).hexdigest()}
    return result


def package_versions():
    versions = {}
    for name in ("torch", "transformers", "numpy", "tqdm", "sentence-transformers", "accelerate"):
        try:
            versions[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            versions[name] = None
    return versions


def build_plan(args, environ=None):
    environ = os.environ if environ is None else environ
    if not math.isfinite(args.temperature) or args.temperature <= 0:
        raise ValueError("--temperature must be finite and greater than zero")
    if args.batch_size < 1 or not 0 <= args.seed < 2 ** 32:
        raise ValueError("--batch-size must be positive and --seed must be a 32-bit unsigned integer")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", args.run_id):
        raise ValueError("--run-id must be a directory name using letters, numbers, _, -, or .")
    models = select_names(args.models, MODEL_KEYS)
    methods = select_names(args.methods, METHODS)
    model_ids = {"gpt2": args.gpt2_model, "qwen2.5": args.qwen_model}
    if any(not str(model_ids[key]).strip() for key in models):
        raise ValueError("Model IDs must not be empty")
    run_dir = args.output_dir.expanduser().resolve() / args.run_id
    source = args.source.expanduser().resolve()
    shared = {key: environ.get(key, default) for key, default in ENV_DEFAULTS.items()}
    manifest = {
        "project": "White-box Text Steganography",
        "experiment": "white_box_main",
        "schema_version": 1,
        "status": "planned",
        "created_at": utc_now(),
        "run_dir": str(run_dir),
        "source": str(source),
        "settings": {
            "num_sentences_per_group": NUM_SENTENCES,
            "top_p": float(TOP_P),
            "qwen_model": args.qwen_model,
            "temperature": args.temperature,
            "seed": args.seed,
            "serial_methods": sorted(SERIAL_METHODS),
        },
        "runtime": {"python": sys.version, "executable": sys.executable,
                    "platform": platform.platform(), "packages": package_versions()},
        "groups": [],
    }
    jobs = []
    for model_key in models:
        for method in methods:
            model_dir = run_dir / model_key
            group_dir = model_dir / method
            batch_size = 1 if method in SERIAL_METHODS else args.batch_size
            controls = dict(shared)
            controls.update({
                "MODEL_PATH": model_ids[model_key], "OUTPUT_DIR": str(model_dir),
                "CONTEXT_FILE": str(group_dir / "contexts.txt"),
                "MESSAGE_FILE": str(group_dir / "message_bits.txt"),
                "NUM_SENTENCES": str(NUM_SENTENCES), "TOP_P": TOP_P,
                "TEMPERATURE": str(args.temperature), "BATCH_SIZE": str(batch_size),
                "SEED": str(args.seed),
            })
            commands = [
                ("prepare", [sys.executable, str(ROOT / "scripts" / "prepare_data.py"),
                             "--method", method, "--source", str(source)]),
                ("cover", [sys.executable, str(ROOT / "scripts" / "run_gen_cover.py"), "--method", method]),
                ("stego", [sys.executable, str(ROOT / "scripts" / "run_gen_stego.py"), "--method", method]),
            ]
            if not args.no_eval:
                commands.append(("evaluate", [sys.executable, str(ROOT / "scripts" / "run_eval.py"),
                                              "--method", method]))
            group = {
                "id": f"{model_key}/{method}", "model_key": model_key,
                "model_id": model_ids[model_key], "method": method,
                "output_dir": str(group_dir), "status": "planned",
                "environment": public_environment(controls),
                "fixed_config": {"force_candidate_cap": False, "use_internal_prompt": False,
                                 "stop_punct": ".?!", "cuda_dtype": "bfloat16", "cpu_dtype": "float32"},
                "steganalysis": {
                    "data_dir": str(run_dir / "steganalysis" / model_key / "data"),
                    "checkpoint_dir": str(run_dir / "steganalysis" / model_key / "checkpoints"),
                },
                "stages": [{"name": name, "command": command, "status": "planned"}
                           for name, command in commands],
            }
            manifest["groups"].append(group)
            jobs.append((group, controls))
    return manifest, jobs


def write_manifest(path, manifest):
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def file_fingerprint(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def run_plan(manifest, jobs):
    source = Path(manifest["source"])
    if not source.is_file():
        raise FileNotFoundError(f"Source corpus not found: {source}")
    run_dir = Path(manifest["run_dir"])
    run_dir.mkdir(parents=True, exist_ok=False)
    manifest_path = run_dir / "run_manifest.json"
    manifest["source_fingerprint"] = file_fingerprint(source)
    manifest["status"] = "running"
    write_manifest(manifest_path, manifest)
    try:
        import torch
        device = "cuda" if torch.cuda.is_available() else "cpu"
        manifest["runtime"].update({"device": device, "dtype": "bfloat16" if device == "cuda" else "float32",
                                     "cuda_version": torch.version.cuda,
                                     "cuda_visible_devices": os.getenv("CUDA_VISIBLE_DEVICES")})
        for group, controls in jobs:
            group["status"] = "running"
            env = os.environ.copy()
            env.update(controls)
            for stage in group["stages"]:
                stage["status"] = "running"
                stage["started_at"] = utc_now()
                write_manifest(manifest_path, manifest)
                print(f"\n[{group['id']}] {stage['name']}", flush=True)
                result = subprocess.run(stage["command"], cwd=ROOT, env=env, check=False)
                stage["finished_at"] = utc_now()
                stage["returncode"] = result.returncode
                stage["status"] = "completed" if result.returncode == 0 else "failed"
                write_manifest(manifest_path, manifest)
                if result.returncode:
                    group["status"] = "failed"
                    raise RuntimeError(f"{group['id']} / {stage['name']} exited with {result.returncode}")
            group["artifacts"] = {
                name: file_fingerprint(Path(group["output_dir"]) / name)
                for name in ("contexts.txt", "message_bits.txt", "cover.txt", "stego.txt", "stego_bits.txt", "eval_result.json")
                if (Path(group["output_dir"]) / name).is_file()
            }
            group["status"] = "completed"
            write_manifest(manifest_path, manifest)
        manifest["status"] = "completed"
    except BaseException as exc:
        manifest["status"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
        manifest["error"] = f"{type(exc).__name__}: {exc}"
        for group, _ in jobs:
            if group["status"] == "running":
                group["status"] = manifest["status"]
                for stage in group["stages"]:
                    if stage["status"] == "running":
                        stage["status"] = manifest["status"]
        raise
    finally:
        manifest["finished_at"] = utc_now()
        write_manifest(manifest_path, manifest)
    print(f"\nManifest: {manifest_path}")


def main(argv=None):
    parser = make_parser()
    args = parser.parse_args(argv)
    try:
        manifest, jobs = build_plan(args)
    except ValueError as exc:
        parser.error(str(exc))
    if args.dry_run:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        return 0
    try:
        run_plan(manifest, jobs)
    except (OSError, RuntimeError, ImportError) as exc:
        print(f"[error] {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
