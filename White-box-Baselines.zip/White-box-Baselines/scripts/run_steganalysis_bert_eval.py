import os
import sys
import argparse
from pathlib import Path
from typing import List, Dict

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.global_config import GlobalConfig

import torch

from steganalysis.bert_detector.detector import BertSteganalysisDetector


def read_lines(p: Path) -> List[str]:
    if not p.exists():
        return []
    out = []
    with p.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if s:
                out.append(s)
    return out


def safe_metrics(tp: int, tn: int, fp: int, fn: int) -> Dict[str, float]:
    total = tp + tn + fp + fn
    acc = (tp + tn) / max(total, 1)
    prec = tp / max(tp + fp, 1)
    rec = tp / max(tp + fn, 1)
    f1 = (2 * prec * rec) / max(prec + rec, 1e-12)
    return {"acc": acc, "precision": prec, "recall": rec, "f1": f1}


def main():
    ap = argparse.ArgumentParser(description="Evaluate per-method BERT steganalysis on test split")
    ap.add_argument("--data_dir", type=str, default="steganalysis/data",
                    help="Root data dir with per-method subdirs (must contain test_*.txt)")
    ap.add_argument("--ckpt_dir", type=str, default="steganalysis/checkpoints",
                    help="Root checkpoint dir with per-method subdirs")
    ap.add_argument("--method", type=str, default="all",
                    help="Method name, or 'all'")
    ap.add_argument("--max_length", type=int, default=256)
    ap.add_argument("--batch_size", type=int, default=64)
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--output_file", type=str, default=None,
                    help="Path to save summary TSV (default: {data_dir}/eval_results.tsv)")
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    ckpt_dir = Path(args.ckpt_dir)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    if args.method.lower() == "all":
        methods = []
        for d in sorted(data_dir.iterdir()):
            if d.is_dir() and (d / "test_cover.txt").exists() and (d / "test_stego.txt").exists():
                if (ckpt_dir / d.name).exists():
                    methods.append(d.name)
                else:
                    print(f"[skip] {d.name}: no checkpoint at {ckpt_dir / d.name}")
    else:
        methods = [m.strip() for m in args.method.split(",") if m.strip()]

    if not methods:
        print("[error] No methods found with both test data and checkpoints.")
        print(f"  data_dir: {data_dir}")
        print(f"  ckpt_dir: {ckpt_dir}")
        sys.exit(1)

    print(f"[eval] methods={methods}")
    print(f"  max_length={args.max_length}  threshold={args.threshold}  device={device}")
    print()

    results = []
    header = f"{'method':20s} {'acc':>8s} {'prec':>8s} {'rec':>8s} {'f1':>8s} {'TP':>6s} {'TN':>6s} {'FP':>6s} {'FN':>6s} {'n':>6s}"
    print(header)
    print("-" * len(header))

    for method in methods:
        test_cover = read_lines(data_dir / method / "test_cover.txt")
        test_stego = read_lines(data_dir / method / "test_stego.txt")

        if not test_cover or not test_stego:
            print(f"[skip] {method}: empty test files")
            continue

        n = min(len(test_cover), len(test_stego))
        test_cover = test_cover[:n]
        test_stego = test_stego[:n]

        ckpt_path = ckpt_dir / method
        try:
            detector = BertSteganalysisDetector.load(
                ckpt_path, max_length=args.max_length, device=device,
            )
        except Exception as e:
            print(f"[skip] {method}: failed to load checkpoint: {e}")
            continue

        texts = test_cover + test_stego
        y_true = [0] * n + [1] * n
        y_pred = detector.predict(texts, batch_size=args.batch_size, threshold=args.threshold)

        cm = detector.confusion_from_preds(y_true, y_pred)
        m = safe_metrics(cm["TP"], cm["TN"], cm["FP"], cm["FN"])

        line = (
            f"{method:20s} "
            f"{m['acc']:8.4f} "
            f"{m['precision']:8.4f} "
            f"{m['recall']:8.4f} "
            f"{m['f1']:8.4f} "
            f"{cm['TP']:6d} "
            f"{cm['TN']:6d} "
            f"{cm['FP']:6d} "
            f"{cm['FN']:6d} "
            f"{n:6d}"
        )
        print(line)

        results.append({
            "method": method,
            **m,
            **cm,
            "n_per_class": n,
            "threshold": args.threshold,
            "checkpoint": str(ckpt_path),
        })

        del detector
        torch.cuda.empty_cache() if device.type == "cuda" else None

    out_path = Path(args.output_file) if args.output_file else data_dir / "eval_results.tsv"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with out_path.open("w", encoding="utf-8") as f:
        cols = ["method", "acc", "precision", "recall", "f1", "TP", "TN", "FP", "FN", "n_per_class", "threshold", "checkpoint"]
        f.write("\t".join(cols) + "\n")
        for r in results:
            vals = [str(r.get(c, "")) for c in cols]
            f.write("\t".join(vals) + "\n")

    print()
    print(f"[done] Results saved to: {out_path.resolve()}")


if __name__ == "__main__":
    main()
