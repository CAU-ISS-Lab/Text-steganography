import importlib.util
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


ROOT = Path(__file__).resolve().parent.parent
metrics = load_module("baseline_metrics", ROOT / "scripts" / "run_eval.py")


def write_lines(path, lines):
    Path(path).write_text("".join(line + "\n" for line in lines), encoding="utf-8")


class MetricMathTests(unittest.TestCase):
    def test_shifted_gaussian_kld_and_identity(self):
        cover = np.array([[0., 2.], [2., 4.]])
        stego = cover + [1., -2.]
        self.assertAlmostEqual(metrics.compute_kld2(cover, stego), 2.499999950000001, places=12)
        self.assertEqual(metrics.compute_kld2(cover, cover), 0.)

    def test_cosines_and_rejected_broadcasting(self):
        cover = [[1., 0.], [0., 1.], [0., 0.]]
        stego = [[1., 0.], [0., -1.], [1., 0.]]
        self.assertEqual(metrics.compute_ss(cover, stego), ([1., -1., 0.], 0.))
        with self.assertRaises(ValueError):
            metrics.compute_ss([[1., 0.]], stego)

    def test_ppl_is_mean_of_sentence_ppls_without_loss_clipping(self):
        losses = np.log([2., 8.])
        ppls = metrics.perplexities_from_mean_losses(losses)
        self.assertAlmostEqual(np.mean(ppls), 5.)
        self.assertNotAlmostEqual(np.mean(ppls), np.exp(np.mean(losses)))
        self.assertGreater(metrics.perplexities_from_mean_losses([101])[0], np.exp(100))
        self.assertEqual(metrics.PPL_MAX_LENGTH, 1024)
        with self.assertRaises(ValueError):
            metrics.perplexities_from_mean_losses([0., float("nan")])
        with self.assertRaises(ValueError):
            metrics.perplexities_from_mean_losses([1000.])

    def test_finite_feature_validation(self):
        with self.assertRaises(ValueError):
            metrics.compute_kld2([[float("nan")]], [[0.]])


class AlignmentTests(unittest.TestCase):
    def test_blank_caption_is_not_dropped(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "cover.txt"
            write_lines(path, ["first caption", "", "third caption"])
            with self.assertRaisesRegex(ValueError, "Blank caption"):
                metrics.load_lines(path)

    def test_zero_bit_rows_keep_positions_and_count_zero(self):
        with tempfile.TemporaryDirectory() as root:
            for name in ["cover.txt", "stego.txt"]:
                write_lines(Path(root) / name, ["first caption", "second caption", "third caption"])
            write_lines(Path(root) / "stego_bits.txt", ["101", "", "0"])
            _, captions, bits = metrics.load_method_inputs(root)
            self.assertEqual(bits, ["101", "", "0"])
            self.assertEqual(metrics.compute_ec(bits, captions), (4 / 6, 4, 6))

    def test_count_mismatch_is_an_error(self):
        with tempfile.TemporaryDirectory() as root:
            write_lines(Path(root) / "cover.txt", ["one cover", "two cover"])
            write_lines(Path(root) / "stego.txt", ["one stego"])
            write_lines(Path(root) / "stego_bits.txt", ["01"])
            with self.assertRaisesRegex(ValueError, "Unaligned"):
                metrics.load_method_inputs(root)

    def test_invalid_bits_are_rejected(self):
        with self.assertRaises(ValueError):
            metrics.compute_ec(["102"], ["one caption"])
        with self.assertRaises(ValueError):
            metrics.compute_ec(["01", ""], ["one caption"])


class OfflineIntegrationTests(unittest.TestCase):
    def test_method_evaluation_with_fake_features(self):
        features = {
            "cover one": [1., 2.], "cover two": [3., 4.],
            "stego one": [2., 2.], "stego two": [4., 4.],
        }

        def embed(sentences, **kwargs):
            return np.array([features[sentence] for sentence in sentences])

        with tempfile.TemporaryDirectory() as root:
            method = Path(root) / "method"
            method.mkdir()
            write_lines(method / "cover.txt", ["cover one", "cover two"])
            write_lines(method / "stego.txt", ["stego one", "stego two"])
            write_lines(method / "stego_bits.txt", ["01", ""])
            with patch.object(metrics, "compute_ppl", return_value=([10., 20.], 15.)), \
                 patch.object(metrics, "get_bert_embeddings", side_effect=embed), \
                 patch.object(metrics, "get_embeddings", side_effect=embed):
                result = metrics.eval_method("method", root, "cpu", "gpt2", "bert", "sbert")
            self.assertEqual(result["PPL"], 15.)
            self.assertAlmostEqual(result["KLD"], 0.4999999900000002, places=12)
            self.assertAlmostEqual(result["SS"], (3 / math.sqrt(10) + 7 / (5 * math.sqrt(2))) / 2)
            self.assertEqual(result["total_bits"], 2)
            self.assertEqual(result["total_words"], 4)
            self.assertEqual(result["EC(bpw)"], .5)


if __name__ == "__main__":
    unittest.main()
