import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import run_main_experiments as runner


class MainExperimentTests(unittest.TestCase):
    def test_dry_run_builds_twelve_isolated_groups_without_writes(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "not-created"
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env.update({"MODEL_PATH": "wrong-model", "NUM_SENTENCES": "7", "TOP_P": "0.2",
                        "OUTPUT_DIR": str(Path(temporary) / "wrong-output"), "BATCH_SIZE": "9"})
            completed = subprocess.run(
                [sys.executable, "-B", str(ROOT / "scripts" / "run_main_experiments.py"),
                 "--dry-run", "--run-id", "check", "--output-dir", str(output)],
                env=env, capture_output=True, text=True, encoding="utf-8", check=True)
            plan = json.loads(completed.stdout)
            self.assertEqual(len(plan["groups"]), 12)
            self.assertEqual(len({g["output_dir"] for g in plan["groups"]}), 12)
            for group in plan["groups"]:
                controls = group["environment"]
                self.assertEqual(controls["NUM_SENTENCES"], "10000")
                self.assertEqual(controls["TOP_P"], "0.99")
                self.assertEqual(float(controls["TEMPERATURE"]), 1.0)
                self.assertEqual(controls["MODEL_PATH"], group["model_id"])
                self.assertEqual(Path(controls["MESSAGE_FILE"]).parent, Path(group["output_dir"]))
                expected = 1 if group["method"] in ("ac", "imec", "sparsamp") else 64
                self.assertEqual(int(controls["BATCH_SIZE"]), expected)
                self.assertEqual(len(group["stages"]), 4)
            self.assertFalse(output.exists())
            self.assertFalse((Path(temporary) / "wrong-output").exists())

    def test_overrides_are_recorded_without_disclosing_keys(self):
        args = runner.make_parser().parse_args([
            "--models", "qwen2.5", "--methods", "ac,meteor", "--qwen-model", "Qwen/custom",
            "--temperature", "0.8", "--batch-size", "8", "--seed", "42", "--no-eval"])
        plan, jobs = runner.build_plan(args, {"AC_PRECISION": "24", "METEOR_KEY_HEX": "ab" * 64})
        self.assertEqual(len(jobs), 2)
        for group in plan["groups"]:
            controls = group["environment"]
            self.assertEqual(controls["MODEL_PATH"], "Qwen/custom")
            self.assertEqual(controls["TEMPERATURE"], "0.8")
            self.assertEqual(controls["SEED"], "42")
            self.assertEqual(controls["AC_PRECISION"], "24")
            self.assertTrue(controls["METEOR_KEY_HEX"]["set"])
            self.assertEqual(len(group["stages"]), 3)
        self.assertNotIn("ab" * 64, json.dumps(plan))
        self.assertEqual(jobs[1][1]["METEOR_KEY_HEX"], "ab" * 64)
        self.assertEqual(jobs[1][1]["BATCH_SIZE"], "8")

    def test_invalid_selection_and_path_escape_are_rejected(self):
        for argv in (["--run-id", "../escape"], ["--methods", "ac,ac"],
                     ["--models", "unknown"], ["--temperature", "nan"]):
            with self.subTest(argv=argv):
                with self.assertRaises(ValueError):
                    runner.build_plan(runner.make_parser().parse_args(argv), {})

    def test_failed_stage_is_saved_and_stops_following_stages(self):
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "corpus.txt"
            source.write_text("A short source corpus for a mock run.\n", encoding="utf-8")
            args = runner.make_parser().parse_args([
                "--models", "gpt2", "--methods", "ac", "--run-id", "failure",
                "--source", str(source), "--output-dir", temporary])
            plan, jobs = runner.build_plan(args, {})
            fake_torch = SimpleNamespace(cuda=SimpleNamespace(is_available=lambda: False),
                                         version=SimpleNamespace(cuda=None))
            with mock.patch.dict(sys.modules, {"torch": fake_torch}):
                with mock.patch.object(runner.subprocess, "run", side_effect=[
                    SimpleNamespace(returncode=0), SimpleNamespace(returncode=5)
                ]) as run:
                    with self.assertRaises(RuntimeError):
                        runner.run_plan(plan, jobs)
                    self.assertEqual(run.call_count, 2)
            saved = json.loads((Path(temporary) / "failure" / "run_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(saved["status"], "failed")
            self.assertEqual(saved["groups"][0]["status"], "failed")
            self.assertEqual([s["status"] for s in saved["groups"][0]["stages"]],
                             ["completed", "failed", "planned", "planned"])
            self.assertEqual(saved["runtime"]["device"], "cpu")


class StableSplitTests(unittest.TestCase):
    def test_dataset_splits_are_identical_across_python_hash_seeds(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            inputs = root / "outputs" / "ac"
            inputs.mkdir(parents=True)
            for label in ("cover", "stego"):
                (inputs / f"{label}.txt").write_text(
                    "".join(f"{label} example {i}\n" for i in range(30)), encoding="utf-8")
            for hash_seed in ("1", "98765"):
                env = os.environ.copy()
                env["PYTHONIOENCODING"] = "utf-8"
                env["PYTHONHASHSEED"] = hash_seed
                subprocess.run([
                    sys.executable, "-B", str(ROOT / "scripts" / "prepare_steganalysis_dataset.py"),
                    "--outputs_dir", str(root / "outputs"), "--out_data_dir", str(root / hash_seed),
                    "--methods", "ac", "--seed", "1234",
                ], env=env, capture_output=True, text=True, encoding="utf-8", check=True)
            for split, count in (("train", 18), ("val", 6), ("test", 6)):
                for label in ("cover", "stego"):
                    filename = f"{split}_{label}.txt"
                    first = (root / "1" / "ac" / filename).read_text(encoding="utf-8")
                    second = (root / "98765" / "ac" / filename).read_text(encoding="utf-8")
                    self.assertEqual(first, second)
                    self.assertEqual(len(first.splitlines()), count)
            info = json.loads((root / "1" / "split_info.json").read_text(encoding="utf-8"))
            self.assertEqual(info["seed_algorithm"], "sha256-first-32-bits-v1")
            self.assertNotEqual(info["methods"]["ac"]["cover_seed"], info["methods"]["ac"]["stego_seed"])


if __name__ == "__main__":
    unittest.main()
